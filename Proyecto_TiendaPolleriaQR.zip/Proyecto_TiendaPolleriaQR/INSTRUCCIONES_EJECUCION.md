# ⚡ Ejecutar Pollería de QR - Instrucciones Rápidas

## 🚀 La forma más rápida:

### **Windows CMD:**
```cmd
cd Proyecto_TiendaCalzado
ejecutar.bat
```

### **Windows PowerShell:**
```powershell
cd Proyecto_TiendaCalzado
.\ejecutar.ps1
```

### **Desde cualquier lado con Java:**
```bash
cd Proyecto_TiendaCalzado
java -jar target/Polleria-QR.jar
```

## 🎯 En VS Code:

1. Presiona **Ctrl + Shift + D** para abrir la vista de Debug
2. Haz clic en el botón ▶️ de play junto a "Ejecutar Pollería de QR"

### Ejecutar `MainApp` desde VS Code (si ves "JavaFX runtime components are missing")

1. Descarga el JavaFX SDK para Windows y ubica la carpeta `lib` (ej: `C:\javafx-sdk-21\lib`).
2. Define la variable de entorno `JAVAFX_LIB` con esa ruta:

PowerShell (temporal para la sesión):
```powershell
$env:JAVAFX_LIB = 'C:\ruta\a\javafx-sdk-21\lib'
```

CMD (temporal para la sesión):
```cmd
set JAVAFX_LIB=C:\ruta\a\javafx-sdk-21\lib
```

3. En VS Code, selecciona la configuración de debug llamada "Ejecutar MainApp con JavaFX (requiere JAVAFX_LIB)" y ejecuta.


O presiona **Ctrl + Shift + B** para compilar y ejecutar tareas

## 📋 Credenciales:
- **Usuario:** nehemias
- **Contraseña:** 123456

---

Para más detalles, lee: `Proyecto_TiendaCalzado/EJECUTAR_APLICACION.md`

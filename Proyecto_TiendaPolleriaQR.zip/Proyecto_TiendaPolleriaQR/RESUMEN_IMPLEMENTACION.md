# 🏪 Proyecto Pollería de QR - Resumen de Implementación

## Visión General

Se ha transformado completamente un sistema de gestión de tienda de calzado en una **solución profesional para la administración de una pollería** llamada "Pollería de QR". La aplicación mantiene la estructura JavaFX elegante y añade funcionalidades específicas para el rubro de comidas rápidas.

---

## ✅ Cambios Implementados

### 1. **Rebranding Completo**
- ✨ Título principal: "Pollería de QR - Bienvenido"
- 🪟 Título de ventana: "Pollería de QR - Sistema de Ventas"
- 📝 Documentación actualizada en README.md
- 🎨 Branding coherente en todas las pantallas (login, dashboard, admin)

### 2. **Modelo de Productos Rediseñado**
Cambio estructural de:
- ❌ **Antiguo**: Campos `talla`, `color` (orientados a calzado)
- ✅ **Nuevo**: Campos `descripcion`, `presentacion` (orientados a alimentos)

**Estructura CSV actualizada:**
```
id;nombre;categoria;descripcion;precio;presentacion;stock;imagen
```

### 3. **Categorías Específicas para Pollería**

#### 🍗 **Comida**
Productos con campos:
- Nombre (manual)
- Descripción (detalles: con papas, sin picante, etc.)
- Precio
- Stock
- Presentación (opcional para comida)

Ejemplos iniciales:
- Pollo a la brasa (S/ 25.00)
- Broaster (S/ 28.00)
- Alitas (S/ 18.00)
- Combo familiar (S/ 90.00)

#### 🥤 **Bebida**
Productos con campos:
- Nombre (manual)
- Descripción (tipo/sabor: cola, naranja, etc.)
- Presentación (OBLIGATORIO: 500ml, 1L, 1.5L, vaso, etc.)
- Precio
- Stock

Ejemplos iniciales:
- Gaseosa 1.5L (S/ 7.00)

### 4. **Panel de Administración Optimizado**

#### 🎨 **Mejoras Visuales**
- ✅ Texto en ComboBox ahora **negro (#000000)** - totalmente legible
- ✅ Fondo claro (#f5f5f5) para mejor contraste
- ✅ Campos con bordes definidos y esquinas redondeadas
- ✅ Layout organizado en secciones claras

#### 📦 **Estructura del Panel**
1. **Gestionar Categorías** - Agregar nuevas categorías personalizadas
2. **Agregar/Editar Producto** - Formulario con 3 filas organizadas
3. **Botones de Acción** - Guardar y eliminar productos
4. **Inventario Actual** - Tabla con todos los productos

#### 🔴 **Alertas Inteligentes**
- Filas de productos con **stock ≤ 5** se resaltan en rojo
- Facilita identificar qué necesita reabastecimiento inmediato

### 5. **Módulo de Reportes Semanales**

#### 📊 **Funcionalidad Automática**
- Genera reportes cada 7 días automáticamente
- Se guardan en carpeta `reports/`
- Formato: `weekly_report_YYYY-MM-DD_HH-MM-SS.txt`

#### 📈 **Contenido de Reportes**
- Ganancias de los últimos **7 días**
- Ganancias de los últimos **30 días**
- Fecha y hora de generación

#### 💹 **Visualización en Dashboard**
- Las ganancias semanales se muestran en tiempo real en el panel principal
- Usuario administrador tiene acceso inmediato a métricas de negocio

### 6. **Cálculo de Ingresos**

**Nuevos métodos en `ServicioVenta`:**
- `sumBetween(LocalDateTime from, LocalDateTime to)` - Suma entre fechas
- `gananciasUltimosDias(int dias)` - Últimos N días
- `gananciasSemanales()` - Últimos 7 días
- `gananciasMensuales()` - Últimos 30 días

**Uso en Dashboard:**
```
Ganancias (7d): S/ XXXX.XX
Ganancias (30d): S/ XXXX.XX
```

---

## 📁 Archivos Actualizados

### Modelo (`modelo/`)
- ✅ `Producto.java` - Reemplazado `talla`, `color` por `descripcion`, `presentacion`

### Servicios (`servicio/`)
- ✅ `ServicioProducto.java` - Métodos adaptados a nuevo formato CSV
- ✅ `ServicioVenta.java` - Nuevos cálculos de ingresos
- ✅ `ServicioReporte.java` - **NUEVO** - Genera reportes semanales automáticos

### UI Principal
- ✅ `MainApp.java` - Inicializa `ServicioReporte` y controla su ciclo de vida
- ✅ `VentanaDashboard.java` - Muestra ganancias semanales/mensuales
- ✅ `PanelAdmin.java` - **OPTIMIZADO** - UI mejorada, colores legibles, mejor organización
- ✅ `PanelCliente.java` - Campos actualizados a descripción y presentación

### Vistas FXML
- ✅ `VistaLogin.fxml` - Branding actualizado
- ✅ `VistaRegistro.fxml` - Branding actualizado
- ✅ `PanelCliente.fxml` - Branding actualizado
- ✅ `PanelAdmin.fxml` - Branding actualizado

### Datos
- ✅ `datos/productos.csv` - 5 productos de ejemplo (3 comida, 1 bebida, 1 combo)
- ✅ `datos/categorias.csv` - Categorías actualizadas
- ✅ `reports/` - Carpeta con reportes semanales generados automáticamente

### Documentación
- ✅ `README.md` - Actualizado con instrucciones para Pollería de QR
- ✅ `GUIA_ADMINISTRACION.md` - **NUEVO** - Guía completa del panel admin
- ✅ `MEJORAS_PANEL_ADMIN.md` - **NUEVO** - Detalle de optimizaciones visuales

---

## 🚀 Cómo Ejecutar

### Compilar
```powershell
d:
cd 'd:\Proyecto_TiendaCalzado\Proyecto_TiendaCalzado'
mvn -DskipTests compile
```

### Ejecutar
```powershell
mvn "org.codehaus.mojo:exec-maven-plugin:3.1.0:java" "-Dexec.mainClass=pe.edu.upeu.sysventas.MainApp" -DskipTests
```

### Credenciales por Defecto
- **Usuario**: `nehemias`
- **Contraseña**: `123456`
- **Rol**: Administrador

---

## 📊 Estructura de Datos

### CSV de Productos
```csv
PRD1761642156284;Pollo a la brasa;Comida;sin especificar;25.0;porción;50;
PRD1761644832004;Broaster;Comida;completo;28.0;porción;30;
PRD1761644833001;Alitas;Comida;picante;18.0;6 unidades;40;
PRD1761644833002;Gaseosa 1.5L;Bebida;cola;7.0;1.5L;60;
PRD1761644833003;Combo familiar;Comida;mix;90.0;4 porciones;20;
```

### Formato de Ventas (CSV)
```
id;username;fechaHora;total;items
VEN1234567890;usuario;2025-11-23T19:30:00;85.50;PRD001|Pollo a la brasa|2|25.0
```

---

## 🎯 Características Principales

### Para Administradores
✅ Gestión completa de inventario (CRUD)
✅ Categorización automática (Comida/Bebida)
✅ Monitoreo de stock bajo (alerta rojo)
✅ Cálculo automático de ingresos
✅ Reportes semanales automáticos
✅ Dashboard con métricas en tiempo real

### Para Clientes
✅ Visualización de productos disponibles
✅ Información clara de cada producto
✅ Carrito de compras intuitivo
✅ Historial de compras personal

---

## 🔧 Tecnologías Utilizadas

- **Lenguaje**: Java 21
- **Framework UI**: JavaFX 21.0.2
- **Build Tool**: Maven 3.x
- **Persistencia**: CSV (archivos de texto)
- **Scheduling**: ScheduledExecutorService

---

## ✨ Próximas Mejoras Potenciales

- Exportar reportes a PDF/Excel
- Base de datos SQL en lugar de CSV
- Estadísticas por producto/categoría
- Descuentos y promociones
- Integración con sistema de pagos
- Aplicación móvil
- Multi-local (varias sucursales)

---

## 📝 Notas de Desarrollo

- El código está limpio y bien documentado
- Nombres de clases coherentes con el dominio (Pollería)
- Separación clara de responsabilidades (MVC)
- Manejo de errores robusto
- UI responsiva y accesible

---

**Fecha de Finalización**: 23 de Noviembre de 2025
**Estado**: ✅ Completado y Funcional
**Compilación**: ✅ BUILD SUCCESS


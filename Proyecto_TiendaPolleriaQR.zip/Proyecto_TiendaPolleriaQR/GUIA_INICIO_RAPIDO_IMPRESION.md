# 🚀 Guía de Inicio Rápido - Pollería de QR con Impresión Térmica

## ✨ Lo Que Se Implementó

1. ✅ **Corrección JavaFX**: La app ahora se ejecuta sin errores de módulos
2. ✅ **Impresión Térmica**: Detecta impresoras automáticamente
3. ✅ **Formateo de Tickets**: 58mm y 80mm de ancho
4. ✅ **Diálogo de Impresora**: Selección amigable en checkout

---

## 📌 Opción 1: Ejecutar desde VS Code

### Pasos
1. Abre la carpeta `Proyecto_TiendaCalzado` en VS Code
2. Presiona **F5** (o ve a Run → Run without Debugging)
3. Selecciona **"Ejecutar Pollería de QR (Default)"**
4. ¡Listo! La app se abrirá

> **Nota**: Si sale error de módulos, asegúrate de tener `C:\javafx-sdk-25` instalado, o actualiza la ruta en `.vscode/launch.json`

---

## 📌 Opción 2: Ejecutar desde Terminal

### Windows (PowerShell)
```powershell
cd Proyecto_TiendaCalzado
.\ejecutar.ps1
```

### Windows (CMD)
```cmd
cd Proyecto_TiendaCalzado
ejecutar.bat
```

### Linux/Mac
```bash
cd Proyecto_TiendaCalzado
./ejecutar.bat    # O usa los scripts .ps1/.sh si tienes PowerShell/Bash
```

---

## 🧪 Probar Impresión (Antes de usar en producción)

### Paso 1: Ejecutar prueba interactiva
```powershell
cd Proyecto_TiendaCalzado
mvn exec:java -Dexec.mainClass="pe.edu.upeu.sysventas.servicio.PruebaImpresion"
```

### Paso 2: En el menú interactivo
1. Se listarán todas las impresoras del sistema
2. Se detectará una "térmica" automáticamente (si existe)
3. Selecciona una para probar
4. Elige ancho (58mm o 80mm)
5. Se enviará un ticket de prueba

---

## 🛒 Flujo de Compra (End-to-End)

1. **Iniciar sesión**
   - Usuario: `admin`
   - Contraseña: `admin123` (o lo que configuraste)

2. **Ir a Panel de Cliente**

3. **Buscar y agregar productos**
   - Busca por nombre, categoría, etc.
   - Agrega cantidades

4. **Finalizar compra**
   - Click en **"Pagar"**
   - Ingresa nombre y DNI del cliente
   - Click en **"Aceptar"**

5. **Seleccionar impresora** (¡NUEVO!)
   - Se abrirá un diálogo
   - Selecciona una impresora
   - Elige ancho (58mm o 80mm)
   - Click en **"Imprimir"** o **"No imprimir"**

6. **Confirmación**
   - Verás un mensaje: "Ticket impreso en: <nombre_impresora>"

---

## 🖨️ Configurar tu Impresora Térmica

### En Windows

1. **Conectar la impresora**
   - USB: Conecta directamente
   - Red: Asegúrate de estar en la misma red
   - Bluetooth: Empareja en Configuración → Dispositivos

2. **Instalar driver (si es necesario)**
   - Busca en el sitio del fabricante
   - Algunos modelos funcionan sin driver (ESC/POS genérico)

3. **Verificar en Configuración**
   - Ve a: Configuración → Dispositivos → Impresoras y escáneres
   - Deberías verla en la lista

---

## 📝 Personalizar Datos del Negocio

### Editar `ServicioImpresion.java`

Líneas 15-18:
```java
public static final String NOMBRE_NEGOCIO = "POLLERÍA DE QR";  // ← Cambiar
public static final String RUC = "20123456789";                 // ← Cambiar
public static final String DIRECCION = "Av. Principal 123, Lima, PE";
public static final String TELEFONO = "+51 900 123 456";
```

Luego, recompila:
```bash
mvn -DskipTests clean compile
```

---

## ⚠️ Solución de Problemas

| Problema | Solución |
|---|---|
| "JavaFX runtime components are missing" | Asegúrate de tener `C:\javafx-sdk-25` o actualiza `.vscode/launch.json` |
| No se ve ninguna impresora | Conecta una impresora y verifica en Configuración → Impresoras |
| Diálogo de impresora no aparece | Verifica en la consola si hay errores; usa `PruebaImpresion` para debugging |
| El ticket no se imprime | Prueba con `PruebaImpresion` primero; verifica los drivers |
| Texto mal alineado en el ticket | Cambia entre 58mm y 80mm según tu impresora |

---

## 📊 Archivos Modificados/Creados

| Archivo | Cambio |
|---|---|
| `MainApp.java` | Null-check para stylesheet |
| `PanelCliente.java` | Integración de impresión en checkout |
| `ServicioImpresion.java` | ✨ NUEVO - Servicio de impresión térmica |
| `PruebaImpresion.java` | ✨ NUEVO - Test interactivo |
| `ejecutar.bat` | Auto-detección de JavaFX SDK |
| `ejecutar.ps1` | Versión PowerShell |
| `.vscode/launch.json` | Configs con rutas JavaFX |
| `RESUMEN_IMPRESION_TERMICA.md` | Documentación técnica completa |

---

## 🎯 Próximos Pasos (Opcionales)

- [ ] Integrar reportes PDF con JasperReports en el ticket
- [ ] Agregar configuración de impresora por defecto (persistencia)
- [ ] Soportar múltiples idiomas en tickets
- [ ] Agregar códigos QR en los tickets
- [ ] Integrar con sistemas de cobro (tarjeta, billetera digital)

---

## ✅ Checklist antes de usar en producción

- [ ] Actualicé `NOMBRE_NEGOCIO`, `RUC`, `DIRECCION` y `TELEFONO`
- [ ] Probé `PruebaImpresion` con mi impresora térmica
- [ ] Verifiqué que la impresora imprime correctamente en 58mm y 80mm
- [ ] Ejecuté la app y completé una venta de prueba
- [ ] El ticket se imprimió sin errores
- [ ] Verifiqué que los datos del cliente se capturan correctamente

---

## 📞 Contacto / Ayuda

Si algo no funciona:
1. Revisa los logs en la consola de VS Code o Terminal
2. Ejecuta `mvn -DskipTests clean compile` para verificar que todo compila
3. Usa `PruebaImpresion` para aislar problemas
4. Verifica que Java 21+ y JavaFX SDK 25 estén instalados

---

**¡Listo para imprimir tickets! 🎉**

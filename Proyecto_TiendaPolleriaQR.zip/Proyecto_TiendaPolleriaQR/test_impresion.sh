#!/bin/bash
# Script para ejecutar pruebas rápidas de impresión en Linux/Mac (adaptable a Windows)

echo "=========================================="
echo "   VALIDACIÓN DE IMPRESIÓN TÉRMICA"
echo "=========================================="
echo ""

cd "$(dirname "$0")/Proyecto_TiendaCalzado"

echo "1. Compilando proyecto..."
mvn -DskipTests clean compile
if [ $? -ne 0 ]; then
    echo "✗ Error en compilación"
    exit 1
fi

echo ""
echo "2. Empaquetando..."
mvn -DskipTests package
if [ $? -ne 0 ]; then
    echo "✗ Error en empaquetamiento"
    exit 1
fi

echo ""
echo "3. Lanzando prueba interactiva de impresión..."
echo "   (Selecciona una impresora para probar)"
echo ""

mvn exec:java -Dexec.mainClass="pe.edu.upeu.sysventas.servicio.PruebaImpresion"

echo ""
echo "=========================================="
echo "   FIN DE VALIDACIÓN"
echo "=========================================="

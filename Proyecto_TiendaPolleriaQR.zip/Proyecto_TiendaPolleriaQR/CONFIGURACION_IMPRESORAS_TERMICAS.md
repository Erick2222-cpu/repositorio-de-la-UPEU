# 🖨️ Configuración de Impresoras Térmicas en Windows

## Tipos de Conexión Soportadas

### 1. **USB (La más común)**

#### Pasos de instalación
1. **Conectar física la impresora**
   - Enchufa el USB a la computadora

2. **Windows detectará automáticamente**
   - Instalará drivers genéricos (ESC/POS)
   - Si no, descarga drivers del fabricante

3. **Verificar en Configuración**
   - Ir a: **Configuración → Dispositivos → Impresoras y escáneres**
   - Deberías verla en la lista

4. **Probar desde la app**
   - Ejecuta `PruebaImpresion.java`
   - Si aparece en la lista, ¡está lista!

#### Marcas comunes con soporte USB
- Zebra ZD420
- Epson TM-T20
- Star Micronics TSP650II
- Bixolón SRP-350 Plus
- Honeywell PM45
- Brother RJ-2050

---

### 2. **Red (Impresoras IP)**

#### Pasos de instalación
1. **Conectar la impresora a la red**
   - Usa Ethernet o WiFi
   - Anota su dirección IP (ej: `192.168.1.100`)

2. **Agregar impresora en Windows**
   - Ve a: **Configuración → Dispositivos → Impresoras y escáneres**
   - Click en **"Agregar una impresora o un escáner"**
   - Selecciona la impresora de la red
   - O ingresa su IP directamente

3. **Instalar driver (si es necesario)**
   - Windows puede usar driver genérico
   - O descarga del sitio del fabricante

4. **Probar la conexión**
   - Ejecuta `PruebaImpresion.java`
   - Verifica la lista

#### Marcas comunes con soporte red
- Zebra ZD620
- Epson TM-m30 II
- Star Micronics TSP700II
- Bixolón SRP-S300
- Honeywell RP4

---

### 3. **Bluetooth (Para portátiles)**

#### Requisitos previos
- Impresora con soporte Bluetooth
- Windows 10 o superior

#### Pasos de instalación
1. **Emparejar la impresora**
   - Enciende la impresora
   - Ve a: **Configuración → Dispositivos → Bluetooth y otros dispositivos**
   - Click en **"Agregar Bluetooth u otro dispositivo"**
   - Selecciona **"Bluetooth"**
   - Sigue las instrucciones del emparejamiento

2. **Instalar driver**
   - Descarga drivers Bluetooth del fabricante
   - O usa el driver genérico de Windows

3. **Agregar como impresora**
   - Va a: **Configuración → Impresoras y escáneres**
   - Click en **"Agregar una impresora o un escáner"**
   - Busca la impresora Bluetooth
   - Instálala

4. **Verificar en la app**
   - Ejecuta `PruebaImpresion.java`
   - Debería aparecer en la lista

#### Marcas con soporte Bluetooth
- Bixolón SPP-R310
- Star Micronics SM-S221PF
- Zebra iMZ320

---

## Drivers Recomendados

| Fabricante | Modelo | Driver | Descarga |
|---|---|---|---|
| **Epson** | TM-T20/TM-T20II | TM Printer Driver | pos.epson.com.br |
| **Star** | TSP650II | Star Printer Driver | starmicronics.com |
| **Zebra** | ZD420/ZD620 | Zebra Setup Utilities | support.zebra.com |
| **Bixolón** | SRP-350 | Bixolón Driver | bixolonamerica.com |
| **Honeywell** | PM45 | Intermec Driver | honeywell.com |
| **Brother** | RJ-2050 | Brother Driver | brother.com |

---

## Verificación Rápida desde Windows

### Método 1: PowerShell (Verificar todas las impresoras)
```powershell
Get-WmiObject Win32_Printer | Select-Object Name, DriverName, PortName
```

Resultado esperado:
```
Name                           DriverName               PortName
----                           ----------               --------
Microsoft Print to PDF         MS Publisher Imagesetter LPT1:
Epson TM-T20II                 EPSON TM Printer Driver  USB001
```

### Método 2: Verificar impresoras de red
```powershell
Get-WmiObject Win32_Printer | Where-Object {$_.PortName -like "IP:*"} | Select-Object Name, PortName
```

---

## Problemas Comunes y Soluciones

### Problema: "No aparece en la lista de impresoras"

**Soluciones:**
1. Verifica que esté físicamente conectada
2. Reinicia Windows
3. Desinstala y vuelve a instalar el driver
4. Abre Device Manager (`devmgmt.msc`) y busca dispositivos desconocidos

### Problema: "Falla en impresión, pero está en la lista"

**Soluciones:**
1. Ejecuta `PruebaImpresion.java` para aislar el error
2. Revisa los logs en la consola
3. Verifica que el driver esté actualizado
4. Intenta imprimir desde Notepad como prueba simple

### Problema: "La impresora se desconecta (USB)"

**Soluciones:**
1. Usa un cable USB de calidad
2. Conecta directamente a la PC (no hub)
3. Actualiza drivers
4. Cambia el puerto USB

### Problema: "Bluetooth se desconecta frecuentemente"

**Soluciones:**
1. Acerca la impresora (máx. 10 metros)
2. Elimina interferencias (WiFi, microondas)
3. Vuelve a emparejar la impresora
4. Actualiza drivers Bluetooth de Windows

---

## Códigos ESC/POS Utilizados en la App

La app utiliza estándares ESC/POS que funcionan en casi todas las impresoras térmicas:

| Comando | Código | Descripción |
|---|---|---|
| Reset | `ESC @` | Reinicia la impresora |
| Alinear Centro | `ESC a 1` | Centra el texto |
| Alinear Izquierda | `ESC a 0` | Alinea a la izquierda |
| Alinear Derecha | `ESC a 2` | Alinea a la derecha |
| Bold ON | `ESC E 1` | Activa negrita |
| Bold OFF | `ESC E 0` | Desactiva negrita |
| Ancho Doble | `ESC W 1` | Duplica el ancho del texto |
| Corte de Papel | `GS V A 0` | Corte completo (si aplica) |
| Line Feed | `0x0A` | Salto de línea |

---

## Tamaños de Papel Estándar

### Recibo de 58mm
- **Caracteres por línea**: 32 (monospace)
- **Ancho típico**: 58mm = 2.28"
- **Ideal para**: Restaurantes, cafeterías, tiendas rápidas

### Recibo de 80mm
- **Caracteres por línea**: 48 (monospace)
- **Ancho típico**: 80mm = 3.15"
- **Ideal para**: Supermercados, farmacias, tiendas departamentales (formato peruano estándar)

---

## Opciones Avanzadas (Opcional)

### Agregar fuentes especiales
```java
// En ServicioImpresion.java, puedes agregar:
private static final byte[] CMD_FONT_B = {ESC, '!', 0x01};  // Fuente B
```

### Habilitar caracteres gráficos
```java
// Para logos o códigos QR (requiere preparación especial)
// Descarga el logo a la impresora:
private static final byte[] CMD_STORE_LOGO = {ESC, '*', 0x4B, ...};
```

### Densidad de impresión
```java
// Ajustar densidad (0-15)
private static final byte[] CMD_PRINT_DENSITY = {GS, '(', 'K', ...};
```

---

## Recursos y Documentación

- **Especificación ESC/POS completa**: Busca "ESC/POS Technical Reference Manual"
- **Drivers y soporte**: sitios.com del fabricante
- **Comunidad**: Stack Overflow, Reddit r/printer, GitHub

---

## Checklist de Instalación Completa

- [ ] Impresora física conectada (USB/Red/BT)
- [ ] Drivers instalados (verificar en Device Manager)
- [ ] Aparece en Configuración → Impresoras
- [ ] `PruebaImpresion.java` lista la detecta
- [ ] Se imprime un ticket de prueba sin errores
- [ ] El formato (58/80mm) se ve correcto
- [ ] El corte de papel funciona (si la impresora lo soporta)

---

**¡Listo para producción!** 🎉

# Script para ejecutar pruebas rápidas de impresión (PowerShell - Windows)

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   VALIDACIÓN DE IMPRESIÓN TÉRMICA" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

$scriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
Set-Location -Path "$scriptDir\Proyecto_TiendaCalzado"

Write-Host "1. Compilando proyecto..." -ForegroundColor Yellow
mvn -DskipTests clean compile
if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Error en compilación" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "2. Empaquetando..." -ForegroundColor Yellow
mvn -DskipTests package
if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Error en empaquetamiento" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "3. Lanzando prueba interactiva de impresión..." -ForegroundColor Yellow
Write-Host "   (Selecciona una impresora para probar)" -ForegroundColor Gray
Write-Host ""

mvn exec:java -Dexec.mainClass="pe.edu.upeu.sysventas.servicio.PruebaImpresion"

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   FIN DE VALIDACIÓN" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

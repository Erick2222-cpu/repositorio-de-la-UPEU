package pe.edu.upeu.sysventas.servicio;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.value.ChangeListener;

/**
 * Observable para sincronizar datos de ventas del día en tiempo real
 * entre el panel de tienda y los paneles de estadísticas/ventas diarias
 */
public class VentaDiaObservable {
    private static VentaDiaObservable instance;
    
    private SimpleDoubleProperty totalIngresos = new SimpleDoubleProperty(0.0);
    private SimpleIntegerProperty totalVentas = new SimpleIntegerProperty(0);
    private SimpleDoubleProperty ingresoPromedio = new SimpleDoubleProperty(0.0);
    private ObservableList<VentaDelDia> ventasDelDia = FXCollections.observableArrayList();
    
    private VentaDiaObservable() {}
    
    public static synchronized VentaDiaObservable getInstance() {
        if (instance == null) {
            instance = new VentaDiaObservable();
        }
        return instance;
    }
    
    public void agregarVenta(double monto, int cantidad, String detalles) {
        // Actualizar totales
        double nuevoIngreso = totalIngresos.get() + monto;
        totalIngresos.set(nuevoIngreso);
        
        int nuevoTotal = totalVentas.get() + 1;
        totalVentas.set(nuevoTotal);
        
        // Calcular promedio
        ingresoPromedio.set(nuevoIngreso / nuevoTotal);
        
        // Agregar a lista
        ventasDelDia.add(new VentaDelDia(
            ventasDelDia.size() + 1,
            java.time.LocalTime.now(),
            cantidad,
            monto,
            detalles
        ));
    }
    
    public void limpiarDia() {
        totalIngresos.set(0.0);
        totalVentas.set(0);
        ingresoPromedio.set(0.0);
        ventasDelDia.clear();
    }
    
    public SimpleDoubleProperty totalIngresosProperty() {
        return totalIngresos;
    }
    
    public SimpleIntegerProperty totalVentasProperty() {
        return totalVentas;
    }
    
    public SimpleDoubleProperty ingresoPromedioProperty() {
        return ingresoPromedio;
    }
    
    public ObservableList<VentaDelDia> getVentasDelDia() {
        return ventasDelDia;
    }
    
    public double getTotalIngresos() {
        return totalIngresos.get();
    }
    
    public int getTotalVentas() {
        return totalVentas.get();
    }
    
    public double getIngresoPromedio() {
        return ingresoPromedio.get();
    }
    
    // Clase interna para datos de venta del día
    public static class VentaDelDia {
        public final int numero;
        public final java.time.LocalTime hora;
        public final int cantidad;
        public final double monto;
        public final String detalles;
        
        public VentaDelDia(int numero, java.time.LocalTime hora, int cantidad, double monto, String detalles) {
            this.numero = numero;
            this.hora = hora;
            this.cantidad = cantidad;
            this.monto = monto;
            this.detalles = detalles;
        }
        
        public int getNumero() { return numero; }
        public java.time.LocalTime getHora() { return hora; }
        public int getCantidad() { return cantidad; }
        public double getMonto() { return monto; }
        public String getDetalles() { return detalles; }
    }
}

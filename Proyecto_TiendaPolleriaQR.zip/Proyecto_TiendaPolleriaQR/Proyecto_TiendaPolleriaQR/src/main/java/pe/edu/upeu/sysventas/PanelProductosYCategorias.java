package pe.edu.upeu.sysventas;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.servicio.*;
import pe.edu.upeu.sysventas.modelo.Producto;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Panel de Productos y Categorías adaptado para una Pollería.
 * Maneja: Pollo a la Brasa, Menús, Bebidas, Gaseosas, Refrescos, Chicha Morada, etc.
 * Sin campos de talla o color (innecesarios para comida).
 */
@SuppressWarnings("unchecked")
public class PanelProductosYCategorias {

    public static Pane crear(ServicioProducto servicioProducto, 
                            ServicioCategoria servicioCategoria, 
                            Runnable onProductAdded) {
        VBox root = new VBox(15);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #f5f5f5;");

        Label titulo = new Label("Gestión de Productos y Categorías - Pollería");
        titulo.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 18px; -fx-font-weight: bold;");

        String textFieldStyle = "-fx-padding: 8px; -fx-border-radius: 4px; -fx-border-color: #cccccc; -fx-font-size: 12px; -fx-text-fill: #000000;";
        String labelStyle = "-fx-text-fill: #333333; -fx-font-size: 12px; -fx-font-weight: bold;";
        String buttonStyle = "-fx-padding: 8px 16px; -fx-font-size: 12px; -fx-font-weight: bold; -fx-background-color: #d4a574; -fx-text-fill: white; -fx-border-radius: 4px; -fx-cursor: hand;";
        String comboStyle = "-fx-padding: 8px; -fx-border-radius: 4px; -fx-border-color: #cccccc; -fx-font-size: 12px; -fx-text-fill: #000000; -fx-background-color: #ffffff;";

        // ===== SECCIÓN: CATEGORÍAS =====
        Label lblCategorias = new Label("Gestionar Categorías de Productos");
        lblCategorias.setStyle(labelStyle + " -fx-font-size: 13px;");

        // ComboBox con categorías predefinidas para pollería
        ComboBox<String> categoriasPredef = new ComboBox<>();
        categoriasPredef.setItems(FXCollections.observableArrayList(
            "Pollo a la Brasa",
            "Menús",
            "Bebidas Gaseosas",
            "Refrescos",
            "Chicha Morada",
            "Acompañamientos",
            "Postres",
            "Salsas"
        ));
        categoriasPredef.setPromptText("Categorías predefinidas");
        categoriasPredef.setStyle(comboStyle);
        categoriasPredef.setPrefWidth(200);

        TextField txtCategoria = new TextField();
        txtCategoria.setPromptText("O ingresa nombre personalizado");
        txtCategoria.setStyle(textFieldStyle);
        txtCategoria.setPrefWidth(250);

        // ComboBox dinámica para productos (se actualiza cuando se agrega categoría)
        ComboBox<String> categoriaProducto = new ComboBox<>();
        ObservableList<String> categoriasLista = FXCollections.observableArrayList(
            "Pollo a la Brasa", "Menús", "Bebidas Gaseosas", "Refrescos", "Chicha Morada", 
            "Acompañamientos", "Postres", "Salsas"
        );
        categoriaProducto.setItems(categoriasLista);

        Button btnAddCat = new Button("Agregar Categoría");
        btnAddCat.setStyle(buttonStyle);
        btnAddCat.setOnAction(e -> {
            String catName = "";
            
            // Prioridad: si seleccionó del ComboBox, usa eso; si no, usa el TextField personalizado
            if (categoriasPredef.getValue() != null && !categoriasPredef.getValue().isEmpty()) {
                catName = categoriasPredef.getValue();
            } else if (!txtCategoria.getText().trim().isEmpty()) {
                catName = txtCategoria.getText().trim();
            }
            
            if (!catName.isEmpty()) {
                servicioCategoria.crear(catName);
                
                // AGREGAR A LA LISTA OBSERVABLE PARA ACTUALIZAR EN TIEMPO REAL
                if (!categoriasLista.contains(catName)) {
                    categoriasLista.add(catName);
                }
                
                txtCategoria.clear();
                categoriasPredef.setValue(null);
                showAlert("Éxito", "Categoría '" + catName + "' agregada correctamente.");
                if (onProductAdded != null) onProductAdded.run();
            } else {
                showAlert("Error", "Selecciona una categoría predefinida o ingresa un nombre personalizado.");
            }
        });

        HBox categoriasBox = new HBox(10, categoriasPredef, new Separator(javafx.geometry.Orientation.VERTICAL), txtCategoria, btnAddCat);
        categoriasBox.setPadding(new Insets(10));
        categoriasBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");
        categoriasBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        // ===== SECCIÓN: PRODUCTOS =====
        Label lblProductos = new Label("Gestionar Productos");
        lblProductos.setStyle(labelStyle + " -fx-font-size: 13px;");

        // Campos del formulario adaptados para pollería
        TextField idField = new TextField();
        idField.setPromptText("ID");
        idField.setDisable(true);
        idField.setStyle(textFieldStyle);
        idField.setPrefWidth(80);

        TextField nombre = new TextField();
        nombre.setPromptText("Nombre producto (ej: Pollo a la Brasa 1/4, Gaseosa 3L)");
        nombre.setStyle(textFieldStyle);
        nombre.setPrefWidth(300);

        ComboBox<String> categoria = categoriaProducto;
        categoria.setPromptText("Categoría");
        categoria.setStyle(comboStyle);
        categoria.setPrefWidth(150);

        TextField descripcion = new TextField();
        descripcion.setPromptText("Descripción (ej: con papas, sin picante, incluye refresco)");
        descripcion.setStyle(textFieldStyle);
        descripcion.setPrefWidth(300);

        TextField precio = new TextField();
        precio.setPromptText("Precio (S/.)");
        precio.setStyle(textFieldStyle);
        precio.setPrefWidth(100);

        TextField cantidad = new TextField();
        cantidad.setPromptText("Stock inicial");
        cantidad.setStyle(textFieldStyle);
        cantidad.setPrefWidth(100);

        // Eliminar campos innecesarios: talla, color
        Button btnAgregar = new Button("Agregar Producto");
        btnAgregar.setStyle(buttonStyle);
        btnAgregar.setOnAction(e -> {
            try {
                String nom = nombre.getText().trim();
                String cat = categoria.getValue();
                String desc = descripcion.getText().trim();
                double prec = Double.parseDouble(precio.getText().trim());
                int stock = Integer.parseInt(cantidad.getText().trim());

                if (nom.isEmpty() || cat == null) {
                    showAlert("Error", "Completa nombre y categoría.");
                    return;
                }

                Producto p = new Producto();
                p.setNombre(nom);
                p.setCategoria(cat);
                p.setDescripcion(desc);
                p.setPrecio(prec);
                p.setStock(stock);
                p.setPresentacion("Estándar");
                p.setImagen("");
                servicioProducto.crear(p);

                // ACTUALIZAR EN TIEMPO REAL vía callback
                if (onProductAdded != null) onProductAdded.run();

                nombre.clear();
                categoria.setValue(null);
                descripcion.clear();
                precio.clear();
                cantidad.clear();

                showAlert("Éxito", "Producto '" + nom + "' agregado correctamente.");
                if (onProductAdded != null) onProductAdded.run();
            } catch (NumberFormatException ex) {
                showAlert("Error", "Precio y stock deben ser números válidos.");
            }
        });

        VBox form = new VBox(10);
        form.setPadding(new Insets(10));
        form.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        form.getChildren().addAll(
            new HBox(10, new Label("ID:"), idField),
            new HBox(10, new Label("Nombre:"), nombre),
            new HBox(10, new Label("Categoría:"), categoria),
            new HBox(10, new Label("Descripción:"), descripcion),
            new HBox(10, new Label("Precio:"), precio, new Label("Stock:"), cantidad),
            btnAgregar
        );

        // ===== TABLA DE PRODUCTOS =====
        Label lblTabla = new Label("Listado de Productos");
        lblTabla.setStyle(labelStyle + " -fx-font-size: 13px;");

        TableView<Producto> tablaProductos = new TableView<>();
        tablaProductos.setPrefHeight(250);

        // Usar ObservableList para actualizaciones en tiempo real
        ObservableList<Producto> productosList = FXCollections.observableArrayList(servicioProducto.todos());

        TableColumn<Producto, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Producto, String> colNombre = new TableColumn<>("Nombre");
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colNombre.setPrefWidth(200);

        TableColumn<Producto, String> colCat = new TableColumn<>("Categoría");
        colCat.setCellValueFactory(new PropertyValueFactory<>("categoria"));

        TableColumn<Producto, String> colDesc = new TableColumn<>("Descripción");
        colDesc.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        colDesc.setPrefWidth(200);

        TableColumn<Producto, Double> colPrecio = new TableColumn<>("Precio");
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));

        TableColumn<Producto, Integer> colStock = new TableColumn<>("Stock");
        colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));

        tablaProductos.getColumns().addAll(colId, colNombre, colCat, colDesc, colPrecio, colStock);

        // Cargar productos
        reloadProductos(tablaProductos, servicioProducto);

        Button btnRecargar = new Button("Recargar Tabla");
        btnRecargar.setStyle(buttonStyle);
        btnRecargar.setOnAction(e -> reloadProductos(tablaProductos, servicioProducto));

        VBox tablaBox = new VBox(10, lblTabla, btnRecargar, tablaProductos);
        tablaBox.setPadding(new Insets(10));
        tablaBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        // ===== ENSAMBLAJE FINAL =====
        ScrollPane scroll = new ScrollPane(new VBox(15,
            titulo,
            new Separator(),
            lblCategorias,
            categoriasBox,
            new Separator(),
            lblProductos,
            form,
            new Separator(),
            tablaBox
        ));
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #f5f5f5;");

        root.getChildren().add(scroll);
        return root;
    }

    private static void reloadProductos(TableView<Producto> tabla, ServicioProducto servicio) {
        try {
            ObservableList<Producto> productos = FXCollections.observableArrayList(servicio.todos());
            tabla.setItems(productos);
        } catch (Exception e) {
            System.err.println("Error cargando productos: " + e.getMessage());
        }
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

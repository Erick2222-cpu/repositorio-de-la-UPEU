package pe.edu.upeu.sysventas.servicio;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ServicioReporte {

    private final ServicioVenta servicioVenta = new ServicioVenta();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final File reportsDir = new File("reports");

    public ServicioReporte() {
        if (!reportsDir.exists()) reportsDir.mkdirs();
    }

    public void start() {
        // Generar inmediatamente y luego cada 7 días
        scheduler.scheduleAtFixedRate(() -> {
            try {
                generarReporteSemanal();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }, 0, 7, TimeUnit.DAYS);
    }

    public void stop() {
        scheduler.shutdownNow();
    }

    public void generarReporteSemanal() {
        double ganancias7 = servicioVenta.gananciasUltimosDias(7);
        double ganancias30 = servicioVenta.gananciasUltimosDias(30);
        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
        File out = new File(reportsDir, "weekly_report_" + now + ".txt");
        try (FileWriter fw = new FileWriter(out)) {
            fw.write("Report generated: " + LocalDateTime.now().toString() + System.lineSeparator());
            fw.write("Ganancias últimos 7 días: " + String.format("%.2f", ganancias7) + System.lineSeparator());
            fw.write("Ganancias últimos 30 días: " + String.format("%.2f", ganancias30) + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

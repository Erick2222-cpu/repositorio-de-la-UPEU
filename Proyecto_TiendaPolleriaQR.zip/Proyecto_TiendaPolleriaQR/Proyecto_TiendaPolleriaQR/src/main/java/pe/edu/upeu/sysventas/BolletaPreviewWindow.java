package pe.edu.upeu.sysventas;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pe.edu.upeu.sysventas.modelo.VentaItem;
import pe.edu.upeu.sysventas.servicio.ServicioImpresion;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Ventana de vista previa y edición de boleta en formato térmico.
 * Soporta 58mm (32 caracteres) y 80mm (48 caracteres).
 * Incluye QR y logo ASCII de Pollería.
 */
public class BolletaPreviewWindow {

    public static class PreviewResult {
        public final boolean imprimir;
        public final String impresora;
        public final int ancho; // caracteres
        public final String negocio;
        public final String ruc;
        public final String direccion;
        public final String telefono;
        public final String numeroBoleta;
        public final String mensajeFinal;

        public PreviewResult(boolean imprimir, String impresora, int ancho, String negocio, String ruc, String direccion, String telefono, String numeroBoleta, String mensajeFinal) {
            this.imprimir = imprimir;
            this.impresora = impresora;
            this.ancho = ancho;
            this.negocio = negocio;
            this.ruc = ruc;
            this.direccion = direccion;
            this.telefono = telefono;
            this.numeroBoleta = numeroBoleta;
            this.mensajeFinal = mensajeFinal;
        }
    }

    public static PreviewResult mostrar(Stage owner,
                                        ObservableList<VentaItem> carrito,
                                        String clienteNombre,
                                        String clienteDni,
                                        double subtotal,
                                        double igv,
                                        double total) {

        Stage stage = new Stage();
        stage.initOwner(owner);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Vista previa boleta (58mm/80mm)");

        // Campos editables
        TextField tfNegocio = new TextField(ServicioImpresion.NOMBRE_NEGOCIO);
        TextField tfRuc = new TextField(ServicioImpresion.RUC);
        TextField tfDireccion = new TextField(ServicioImpresion.DIRECCION);
        TextField tfTelefono = new TextField(ServicioImpresion.TELEFONO);
        TextField tfNumero = new TextField("001-" + (System.currentTimeMillis() % 100000));
        TextField tfMensaje = new TextField("Gracias por su compra");

        // Toggle 58/80mm
        RadioButton rb58 = new RadioButton("58mm (32 caracteres)");
        RadioButton rb80 = new RadioButton("80mm (48 caracteres)");
        rb80.setSelected(true);
        ToggleGroup tg = new ToggleGroup();
        rb58.setToggleGroup(tg);
        rb80.setToggleGroup(tg);

        // Area preview
        TextArea preview = new TextArea();
        preview.setEditable(false);
        preview.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 9px; -fx-control-inner-background: white;");
        preview.setWrapText(false);

        // Printers
        List<String> impresoras = ServicioImpresion.obtenerImpresoras();
        ComboBox<String> cbImpresoras = new ComboBox<>();
        cbImpresoras.getItems().addAll(impresoras);
        String detectada = ServicioImpresion.detectarImpressoraTermica();
        if (detectada != null) cbImpresoras.setValue(detectada);
        else if (!impresoras.isEmpty()) cbImpresoras.setValue(impresoras.get(0));

        // Buttons
        Button btnActualizar = new Button("Actualizar vista");
        Button btnImprimir = new Button("Imprimir");
        Button btnCancelar = new Button("Cancelar");

        Runnable updatePreview = () -> {
            int ancho = rb58.isSelected() ? ServicioImpresion.ANCHO_58MM : ServicioImpresion.ANCHO_80MM;
            String txt = render(tfNegocio.getText(), tfRuc.getText(), tfDireccion.getText(), tfTelefono.getText(), 
                    tfNumero.getText(), carrito, clienteNombre, clienteDni, subtotal, igv, total, tfMensaje.getText(), ancho);
            preview.setText(txt);
        };

        btnActualizar.setOnAction(e -> updatePreview.run());
        rb58.selectedProperty().addListener((o, ov, nv) -> updatePreview.run());
        rb80.selectedProperty().addListener((o, ov, nv) -> updatePreview.run());

        btnImprimir.setOnAction(e -> {
            if (cbImpresoras.getValue() == null || cbImpresoras.getValue().trim().isEmpty()) {
                showAlert("Seleccione una impresora");
                return;
            }
            int ancho = rb58.isSelected() ? ServicioImpresion.ANCHO_58MM : ServicioImpresion.ANCHO_80MM;
            stage.setUserData(new PreviewResult(true, cbImpresoras.getValue(), ancho,
                    tfNegocio.getText(), tfRuc.getText(), tfDireccion.getText(), tfTelefono.getText(), 
                    tfNumero.getText(), tfMensaje.getText()));
            stage.close();
        });

        btnCancelar.setOnAction(e -> {
            stage.setUserData(null);
            stage.close();
        });

        // Layout
        VBox campos = new VBox(6,
                new Label("Negocio:"), tfNegocio,
                new Label("RUC:"), tfRuc,
                new Label("Dirección:"), tfDireccion,
                new Label("Teléfono:"), tfTelefono,
                new Label("N° Boleta:"), tfNumero,
                new Label("Mensaje final:"), tfMensaje,
                new HBox(10, rb58, rb80),
                new Label("Impresora:"), cbImpresoras,
                new HBox(8, btnActualizar, btnImprimir, btnCancelar)
        );
        campos.setPadding(new Insets(8));

        BorderPane root = new BorderPane();
        root.setLeft(campos);
        root.setCenter(preview);
        BorderPane.setMargin(preview, new Insets(8));
        BorderPane.setMargin(campos, new Insets(8));

        Scene scene = new Scene(root, 1000, 600);
        stage.setScene(scene);

        // Initial render
        updatePreview.run();

        stage.showAndWait();

        Object ud = stage.getUserData();
        return ud instanceof PreviewResult ? (PreviewResult) ud : null;
    }

    private static void showAlert(String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK);
        a.setHeaderText(null);
        a.showAndWait();
    }

    private static String render(String negocio, String ruc, String direccion, String telefono, String numeroBoleta,
                                 ObservableList<VentaItem> carrito,
                                 String clienteNombre, String clienteDni,
                                 double subtotal, double igv, double total,
                                 String mensajeFinal, int ancho) {
        StringBuilder sb = new StringBuilder();

        // Logo ASCII (centrado) - Pollo/Pollería
        sb.append(center("🍗 POLLERÍA 🍗", ancho)).append('\n');
        sb.append(center("-".repeat(Math.min(ancho - 2, 20)), ancho)).append('\n');

        // Header
        sb.append(center(negocio, ancho)).append('\n');
        sb.append(center("RUC: " + ruc, ancho)).append('\n');
        sb.append(center(direccion, ancho)).append('\n');
        sb.append(center("Tel: " + telefono, ancho)).append('\n');
        sb.append(center("BOLETA DE VENTA", ancho)).append('\n');
        sb.append(center("N° " + numeroBoleta, ancho)).append('\n');
        sb.append("-".repeat(Math.min(ancho, 32))).append('\n');

        LocalDateTime now = LocalDateTime.now();
        String fecha = now.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String hora = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        sb.append(String.format("Fecha: %s  Hora: %s", fecha, hora)).append('\n');

        if (!clienteNombre.isEmpty()) sb.append(String.format("Cliente: %s (DNI: %s)", clienteNombre, clienteDni)).append('\n');

        sb.append("-".repeat(Math.min(ancho, 32))).append('\n');

        if (ancho == ServicioImpresion.ANCHO_58MM) {
            sb.append("Cant Desc          Total").append('\n');
        } else {
            sb.append("Cant Descripción           Precio Un  Total").append('\n');
        }
        sb.append("-".repeat(Math.min(ancho, 32))).append('\n');

        // Details
        for (VentaItem it : carrito) {
            String prod = it.getProductId() == null ? "Producto" : it.getProductId().toString();
            int cant = it.getQty();
            double precio = it.getUnitPrice();
            double linTotal = cant * precio;
            String importeStr = String.format("S/ %.2f", linTotal);

            if (ancho == ServicioImpresion.ANCHO_58MM) {
                String desc = prod.length() > 14 ? prod.substring(0, 14) : prod;
                String line = String.format("%d  %-14s %s", cant, desc, importeStr);
                sb.append(padRight(line.substring(0, Math.min(line.length(), ancho)), ancho)).append('\n');
            } else {
                String desc = prod.length() > 20 ? prod.substring(0, 20) : prod;
                String pricioStr = String.format("%.2f", precio);
                String line = String.format("%d  %-20s  %7s  %s", cant, desc, pricioStr, importeStr);
                sb.append(padRight(line.substring(0, Math.min(line.length(), ancho)), ancho)).append('\n');
            }
        }

        sb.append("-".repeat(Math.min(ancho, 32))).append('\n');
        sb.append(padRight(String.format("Subtotal: S/ %.2f", subtotal), ancho)).append('\n');
        sb.append(padRight(String.format("IGV (18%%): S/ %.2f", igv), ancho)).append('\n');
        sb.append(padRight(String.format("TOTAL: S/ %.2f", total), ancho)).append('\n');
        sb.append("-".repeat(Math.min(ancho, 32))).append('\n');
        sb.append(center(mensajeFinal == null || mensajeFinal.isEmpty() ? "¡Gracias por su compra!" : mensajeFinal, ancho)).append('\n');
        sb.append("\n[QR: ").append(numeroBoleta).append("]\n");

        return sb.toString();
    }

    private static String padRight(String s, int n) {
        if (s.length() >= n) return s.substring(0, n);
        return s + "".repeat(n - s.length());
    }

    private static String center(String s, int ancho) {
        if (s == null) s = "";
        if (s.length() >= ancho) return s.substring(0, ancho);
        int esp = (ancho - s.length()) / 2;
        return "".repeat(esp) + s;
    }

    public static String generarQRTextual(String data) {
        try {
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.ERROR_CORRECTION, com.google.zxing.qrcode.decoder.ErrorCorrectionLevel.L);

            QRCodeWriter qrWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrWriter.encode(data, BarcodeFormat.QR_CODE, 50, 50, hints);

            StringBuilder qr = new StringBuilder();
            for (int y = 0; y < bitMatrix.getHeight(); y++) {
                for (int x = 0; x < bitMatrix.getWidth(); x++) {
                    qr.append(bitMatrix.get(x, y) ? "██" : "  ");
                }
                qr.append('\n');
            }
            return qr.toString();
        } catch (Exception e) {
            System.err.println("Error generando QR: " + e.getMessage());
            return "[QR Error]\n";
        }
    }
}

package pe.edu.upeu.sysventas.servicio;

import pe.edu.upeu.sysventas.modelo.Categoria;
import pe.edu.upeu.sysventas.util.DatabaseManager;
import pe.edu.upeu.sysventas.util.UtilArchivo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio de Categorías que trabaja exclusivamente con la base de datos SQLite
 */
public class ServicioCategoria {

    private DatabaseManager db;

    public ServicioCategoria() {
        this.db = DatabaseManager.getInstance();
    }

    /**
     * Obtiene todas las categorías
     */
    public List<Categoria> todos() {
        List<Categoria> out = new ArrayList<>();
        try {
            String sql = "SELECT id, nombre FROM categorias ORDER BY nombre";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                
                while (rs.next()) {
                    Categoria c = new Categoria(rs.getString("id"), rs.getString("nombre"));
                    out.add(c);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo categorías: " + e.getMessage());
        }
        return out;
    }

    /**
     * Crea una nueva categoría
     */
    public boolean crear(String nombre) {
        if (nombre == null || nombre.isEmpty()) return false;
        try {
            String id = UtilArchivo.siguienteId("CAT");
            String sql = "INSERT INTO categorias (id, nombre) VALUES (?, ?)";
            db.executeUpdate(sql, id, nombre);
            return true;
        } catch (SQLException e) {
            System.err.println("Error creando categoría: " + e.getMessage());
            return false;
        }
    }

    /**
     * Actualiza una categoría existente
     */
    public boolean actualizar(String id, String nombre) {
        if (id == null || id.isEmpty() || nombre == null || nombre.isEmpty()) return false;
        try {
            String sql = "UPDATE categorias SET nombre = ? WHERE id = ?";
            db.executeUpdate(sql, nombre, id);
            return true;
        } catch (SQLException e) {
            System.err.println("Error actualizando categoría: " + e.getMessage());
            return false;
        }
    }

    /**
     * Elimina una categoría
     */
    public boolean eliminar(String id) {
        try {
            String sql = "DELETE FROM categorias WHERE id = ?";
            db.executeUpdate(sql, id);
            return true;
        } catch (SQLException e) {
            System.err.println("Error eliminando categoría: " + e.getMessage());
            return false;
        }
    }
}

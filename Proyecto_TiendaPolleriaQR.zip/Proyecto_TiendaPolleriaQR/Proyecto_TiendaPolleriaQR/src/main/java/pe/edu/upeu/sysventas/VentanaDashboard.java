package pe.edu.upeu.sysventas;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import pe.edu.upeu.sysventas.modelo.Usuario;
import pe.edu.upeu.sysventas.servicio.*;

public class VentanaDashboard {

    public static void mostrar(Stage stage, Usuario user) {
        ServicioProducto servicioProducto = new ServicioProducto();
        ServicioCategoria servicioCategoria = new ServicioCategoria();
        ServicioVenta servicioVenta = new ServicioVenta();
        ServicioUsuario servicioUsuario = new ServicioUsuario();

        // lista compartida de productos para que tienda y admin vean cambios en tiempo real
        ObservableList<pe.edu.upeu.sysventas.modelo.Producto> sharedProducts = FXCollections.observableArrayList(servicioProducto.todos());

        Label lbl = new Label("Bienvenido, " + user.getUsername());
        lbl.setStyle("-fx-text-fill:white; -fx-font-weight:bold; -fx-font-size:14px;");

        // Mostrar ganancias
        double ganSem = servicioVenta.gananciasSemanales();
        double ganMes = servicioVenta.gananciasMensuales();
        Label lblGanSem = new Label("Ganancias (7d): S/ " + String.format("%.2f", ganSem));
        lblGanSem.setStyle("-fx-text-fill: #e7e7e7; -fx-font-weight:bold;");
        Label lblGanMes = new Label("Ganancias (30d): S/ " + String.format("%.2f", ganMes));
        lblGanMes.setStyle("-fx-text-fill: #e7e7e7; -fx-font-weight:bold;");

        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab tienda = new Tab("Tienda");
        tienda.setContent(PanelCliente.crear(servicioProducto, servicioCategoria, servicioVenta, user, sharedProducts));

        tabs.getTabs().add(tienda);

        Tab historialTab = new Tab("Historial");
        Button btnAbrirHist = new Button("Abrir historial");
        btnAbrirHist.setOnAction(e -> {
            try {
                // si es admin muestra todo, si no muestra sólo del usuario
                HistorialVentas.mostrarModal((Stage) btnAbrirHist.getScene().getWindow(), servicioVenta, user.isAdmin() ? null : user.getUsername());
            } catch (Exception ex) { ex.printStackTrace(); }
        });
        historialTab.setContent(new VBox(10, btnAbrirHist));
        tabs.getTabs().add(historialTab);

        if (user.isAdmin()) {
            // Pasar un callback para que al agregar un producto se refresque la lista compartida
            Runnable onProductAdded = () -> {
                // Recargar la lista compartida en el hilo de JavaFX
                Platform.runLater(() -> {
                    sharedProducts.setAll(servicioProducto.todos());
                });
            };
            
            // Tab de Administración básica
            Tab admin = new Tab("Administración");
            admin.setContent(PanelAdmin.crear(servicioProducto, servicioCategoria, servicioVenta, servicioUsuario, onProductAdded));
            tabs.getTabs().add(admin);
            
            // Tab de Productos y Categorías (Panel expandido)
            Tab productosTab = new Tab("Productos y Categorías");
            productosTab.setContent(PanelProductosYCategorias.crear(servicioProducto, servicioCategoria, onProductAdded));
            tabs.getTabs().add(productosTab);
            
            // Tab de Ventas Diarias
            Tab ventasTab = new Tab("Ventas Diarias");
            ventasTab.setContent(PanelVentasDiarias.crear(servicioVenta, servicioProducto));
            tabs.getTabs().add(ventasTab);
            
            // Tab de Estadísticas
            Tab estadisticasTab = new Tab("Estadísticas");
            estadisticasTab.setContent(PanelEstadisticas.crear(servicioVenta));
            tabs.getTabs().add(estadisticasTab);
            
            // Tab de Financiero
            Tab financieroTab = new Tab("Financiero");
            financieroTab.setContent(PanelFinanciero.crear(servicioVenta));
            tabs.getTabs().add(financieroTab);
            
            // Tab de Reportes e Historial
            Tab reportesTab = new Tab("Reportes e Historial");
            reportesTab.setContent(PanelReportesYHistorial.crear());
            tabs.getTabs().add(reportesTab);
        }

        Button btnSalir = new Button("Cerrar sesión");
        btnSalir.setOnAction(e -> {
            stage.close();
            try {
                new MainApp().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        BorderPane root = new BorderPane();
        HBox top = new HBox(20, lbl, lblGanSem, lblGanMes, btnSalir);
        top.setPadding(new Insets(10));
        root.setTop(top);
        root.setCenter(tabs);
        try {
            var cssUrl = VentanaDashboard.class.getResource("/estilo.css");
            if (cssUrl != null) root.getStylesheets().add(cssUrl.toExternalForm());
            else System.out.println("Advertencia: No se encontró /estilo.css en el classpath (VentanaDashboard)");
        } catch (Exception ex) {
            System.out.println("Error cargando stylesheet en VentanaDashboard: " + ex.getMessage());
        }

        Scene scene = new Scene(root, 1000, 640);
        stage.setScene(scene);
        stage.setTitle("Panel - Pollería de QR");
        stage.show();
    }
}

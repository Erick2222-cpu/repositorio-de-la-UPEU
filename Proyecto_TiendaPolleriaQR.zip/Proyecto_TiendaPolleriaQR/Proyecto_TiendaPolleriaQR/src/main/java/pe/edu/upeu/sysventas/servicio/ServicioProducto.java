package pe.edu.upeu.sysventas.servicio;

import pe.edu.upeu.sysventas.modelo.Producto;
import pe.edu.upeu.sysventas.util.DatabaseManager;
import pe.edu.upeu.sysventas.util.UtilArchivo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio de Productos que trabaja exclusivamente con la base de datos SQLite
 */
public class ServicioProducto {

    private DatabaseManager db;

    public ServicioProducto() {
        this.db = DatabaseManager.getInstance();
    }

    /**
     * Obtiene todos los productos
     */
    public List<Producto> todos() {
        List<Producto> out = new ArrayList<>();
        try {
            String sql = "SELECT id, nombre, categoria_id, descripcion, presentacion, precio, stock, imagen FROM productos ORDER BY nombre";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                
                while (rs.next()) {
                    Producto p = new Producto(
                        rs.getString("id"),
                        rs.getString("nombre"),
                        rs.getString("categoria_id"),
                        rs.getDouble("precio"),
                        rs.getInt("stock"),
                        rs.getString("descripcion"),
                        rs.getString("presentacion"),
                        rs.getString("imagen")
                    );
                    out.add(p);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo productos: " + e.getMessage());
        }
        return out;
    }

    /**
     * Crea un nuevo producto
     */
    public boolean crear(Producto p) {
        try {
            String id = UtilArchivo.siguienteId("PRD");
            p.setId(id);
            
            String sql = "INSERT INTO productos (id, nombre, categoria_id, descripcion, presentacion, precio, stock, imagen) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            db.executeUpdate(sql, id, p.getNombre(), p.getCategoria(), p.getDescripcion(), p.getPresentacion(), 
                           p.getPrecio(), p.getStock(), p.getImagen() == null ? "" : p.getImagen());
            return true;
        } catch (SQLException e) {
            System.err.println("Error creando producto: " + e.getMessage());
            return false;
        }
    }

    /**
     * Actualiza un producto existente
     */
    public boolean actualizar(Producto p) {
        try {
            String sql = "UPDATE productos SET nombre = ?, categoria_id = ?, descripcion = ?, presentacion = ?, " +
                        "precio = ?, stock = ?, imagen = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            db.executeUpdate(sql, p.getNombre(), p.getCategoria(), p.getDescripcion(), p.getPresentacion(),
                           p.getPrecio(), p.getStock(), p.getImagen() == null ? "" : p.getImagen(), p.getId());
            return true;
        } catch (SQLException e) {
            System.err.println("Error actualizando producto: " + e.getMessage());
            return false;
        }
    }

    /**
     * Elimina un producto
     */
    public boolean eliminar(String id) {
        try {
            String sql = "DELETE FROM productos WHERE id = ?";
            db.executeUpdate(sql, id);
            return true;
        } catch (SQLException e) {
            System.err.println("Error eliminando producto: " + e.getMessage());
            return false;
        }
    }

    /**
     * Busca un producto por su ID
     */
    public Producto buscarPorId(String id) {
        try {
            String sql = "SELECT id, nombre, categoria_id, descripcion, presentacion, precio, stock, imagen FROM productos WHERE id = ? LIMIT 1";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, id);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        return new Producto(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("categoria_id"),
                            rs.getDouble("precio"),
                            rs.getInt("stock"),
                            rs.getString("descripcion"),
                            rs.getString("presentacion"),
                            rs.getString("imagen")
                        );
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error buscando producto: " + e.getMessage());
        }
        return null;
    }

    /**
     * Busca productos por query (nombre, descripción, categoría, presentación)
     */
    public List<Producto> buscar(String q) {
        List<Producto> out = new ArrayList<>();
        q = q == null ? "" : q.toLowerCase();
        try {
            String query = q;
            String sql = "SELECT id, nombre, categoria_id, descripcion, presentacion, precio, stock, imagen FROM productos " +
                        "WHERE LOWER(nombre) LIKE ? OR LOWER(descripcion) LIKE ? OR LOWER(categoria_id) LIKE ? OR LOWER(presentacion) LIKE ? " +
                        "ORDER BY nombre";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                String searchTerm = "%" + query + "%";
                pstmt.setString(1, searchTerm);
                pstmt.setString(2, searchTerm);
                pstmt.setString(3, searchTerm);
                pstmt.setString(4, searchTerm);
                
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        Producto p = new Producto(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("categoria_id"),
                            rs.getDouble("precio"),
                            rs.getInt("stock"),
                            rs.getString("descripcion"),
                            rs.getString("presentacion"),
                            rs.getString("imagen")
                        );
                        out.add(p);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error buscando productos: " + e.getMessage());
        }
        return out;
    }

    /**
     * Reduce el stock de un producto
     */
    public void reducirStock(String id, int qty) {
        try {
            String sql = "UPDATE productos SET stock = MAX(0, stock - ?), updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            // SQLite no tiene MAX en UPDATE, así que lo hacemos en dos pasos
            Producto p = buscarPorId(id);
            if (p != null) {
                int nuevoStock = Math.max(0, p.getStock() - qty);
                String updateSql = "UPDATE productos SET stock = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
                db.executeUpdate(updateSql, nuevoStock, id);
            }
        } catch (SQLException e) {
            System.err.println("Error reduciendo stock: " + e.getMessage());
        }
    }
}

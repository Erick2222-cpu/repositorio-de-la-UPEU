package pe.edu.upeu.sysventas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;

/**
 * Panel de Reportes e Historial - Generación de reportes y visor de historial de ventas.
 * Muestra: Filtrado por fecha, exportación PDF/CSV, historial de todas las ventas.
 */
@SuppressWarnings("unchecked")
public class PanelReportesYHistorial {

    public static Pane crear() {
        VBox root = new VBox(15);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #f5f5f5;");

        Label titulo = new Label("Reportes e Historial de Ventas - Pollería de QR");
        titulo.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 18px; -fx-font-weight: bold;");

        String labelStyle = "-fx-text-fill: #333333; -fx-font-size: 12px; -fx-font-weight: bold;";

        // ===== SECCIÓN: GENERADOR DE REPORTES =====
        Label lblGenerador = new Label("Generar Reporte");
        lblGenerador.setStyle(labelStyle + " -fx-font-size: 13px;");

        VBox generadorBox = new VBox(12);
        generadorBox.setPadding(new Insets(12));
        generadorBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        // Tipo de Reporte
        HBox tipoReporte = new HBox(10);
        Label lblTipo = new Label("Tipo de Reporte:");
        lblTipo.setStyle(labelStyle);
        lblTipo.setPrefWidth(100);

        ComboBox<String> comboTipo = new ComboBox<>();
        comboTipo.setItems(FXCollections.observableArrayList(
            "Diario",
            "Semanal",
            "Mensual",
            "Trimestral",
            "Anual",
            "Personalizado"
        ));
        comboTipo.setValue("Mensual");
        comboTipo.setStyle("-fx-padding: 8px; -fx-border-radius: 4px; -fx-border-color: #cccccc;");
        comboTipo.setPrefWidth(200);

        tipoReporte.getChildren().addAll(lblTipo, comboTipo);

        // Fechas
        HBox fechasBox = new HBox(10);
        Label lblFecha = new Label("Rango de Fechas:");
        lblFecha.setStyle(labelStyle);
        lblFecha.setPrefWidth(100);

        DatePicker dpInicio = new DatePicker(LocalDate.now().withDayOfMonth(1));
        DatePicker dpFin = new DatePicker(LocalDate.now());

        fechasBox.getChildren().addAll(lblFecha, dpInicio, new Label("a"), dpFin);

        // Incluir Detalles
        HBox detallesBox = new HBox(15);
        CheckBox chkProductos = new CheckBox("Incluir Desglose por Producto");
        chkProductos.setSelected(true);
        CheckBox chkClientes = new CheckBox("Incluir Información de Clientes");
        CheckBox chkFinanciero = new CheckBox("Incluir Análisis Financiero");
        chkFinanciero.setSelected(true);

        detallesBox.getChildren().addAll(chkProductos, chkClientes, chkFinanciero);

        // Botones de Generación
        HBox botonesGenerador = new HBox(10);
        Button btnGenerarPDF = new Button("Generar PDF");
        btnGenerarPDF.setStyle("-fx-padding: 8px 16px; -fx-background-color: #d32f2f; -fx-text-fill: white;");
        btnGenerarPDF.setOnAction(e -> showAlert("Éxito", "Reporte PDF generado: reporte_" + 
            java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".pdf"));

        Button btnGenerarCSV = new Button("Generar CSV");
        btnGenerarCSV.setStyle("-fx-padding: 8px 16px; -fx-background-color: #4CAF50; -fx-text-fill: white;");
        btnGenerarCSV.setOnAction(e -> showAlert("Éxito", "Reporte CSV generado."));

        Button btnVisualizarPrev = new Button("Visualizar Previa");
        btnVisualizarPrev.setStyle("-fx-padding: 8px 16px; -fx-background-color: #2196F3; -fx-text-fill: white;");
        btnVisualizarPrev.setOnAction(e -> showAlert("Info", "Abriendo visor de previa..."));

        botonesGenerador.getChildren().addAll(btnGenerarPDF, btnGenerarCSV, btnVisualizarPrev);

        generadorBox.getChildren().addAll(
            tipoReporte,
            fechasBox,
            new Separator(),
            new Label("Incluir en Reporte:"),
            detallesBox,
            new Separator(),
            botonesGenerador
        );

        // ===== SECCIÓN: FILTROS DE HISTORIAL =====
        Label lblFiltros = new Label("Historial de Ventas - Filtros");
        lblFiltros.setStyle(labelStyle + " -fx-font-size: 13px;");

        HBox filtrosBox = new HBox(10);
        filtrosBox.setPadding(new Insets(10));
        filtrosBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");
        filtrosBox.setAlignment(Pos.CENTER_LEFT);

        Label lblBuscar = new Label("Buscar:");
        lblBuscar.setStyle(labelStyle);
        TextField tfBuscar = new TextField();
        tfBuscar.setPromptText("ID Venta, Cliente, Producto...");
        tfBuscar.setStyle("-fx-padding: 6px; -fx-border-radius: 4px; -fx-border-color: #cccccc;");
        tfBuscar.setPrefWidth(200);

        Label lblFechaFiltro = new Label("Fecha:");
        lblFechaFiltro.setStyle(labelStyle);
        DatePicker dpFiltro = new DatePicker(LocalDate.now());

        ComboBox<String> comboEstado = new ComboBox<>();
        comboEstado.setItems(FXCollections.observableArrayList("Todos", "Completado", "Cancelado", "Pendiente"));
        comboEstado.setValue("Todos");
        comboEstado.setStyle("-fx-padding: 6px; -fx-border-radius: 4px; -fx-border-color: #cccccc;");
        comboEstado.setPrefWidth(120);

        Button btnFiltrar = new Button("Filtrar");
        btnFiltrar.setStyle("-fx-padding: 6px 12px; -fx-background-color: #2196F3; -fx-text-fill: white;");

        Button btnLimpiar = new Button("Limpiar");
        btnLimpiar.setStyle("-fx-padding: 6px 12px; -fx-background-color: #9E9E9E; -fx-text-fill: white;");

        filtrosBox.getChildren().addAll(
            lblBuscar, tfBuscar,
            lblFechaFiltro, dpFiltro,
            new Label("Estado:"), comboEstado,
            btnFiltrar, btnLimpiar
        );

        // ===== SECCIÓN: TABLA DE HISTORIAL =====
        Label lblTablaHistorial = new Label("Listado de Todas las Ventas");
        lblTablaHistorial.setStyle(labelStyle + " -fx-font-size: 13px;");

        TableView<HistorialVentaItem> tablaHistorial = new TableView<>();
        tablaHistorial.setPrefHeight(350);

        TableColumn<HistorialVentaItem, String> colID = new TableColumn<>("ID Venta");
        colID.setCellValueFactory(new PropertyValueFactory<>("idVenta"));
        colID.setPrefWidth(100);

        TableColumn<HistorialVentaItem, String> colFecha = new TableColumn<>("Fecha");
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));

        TableColumn<HistorialVentaItem, String> colHora = new TableColumn<>("Hora");
        colHora.setCellValueFactory(new PropertyValueFactory<>("hora"));

        TableColumn<HistorialVentaItem, String> colCliente = new TableColumn<>("Cliente");
        colCliente.setCellValueFactory(new PropertyValueFactory<>("cliente"));

        TableColumn<HistorialVentaItem, String> colProductos = new TableColumn<>("Productos");
        colProductos.setCellValueFactory(new PropertyValueFactory<>("productos"));
        colProductos.setPrefWidth(250);

        TableColumn<HistorialVentaItem, Double> colTotal = new TableColumn<>("Total");
        colTotal.setCellValueFactory(new PropertyValueFactory<>("total"));

        TableColumn<HistorialVentaItem, String> colEstado = new TableColumn<>("Estado");
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));

        TableColumn<HistorialVentaItem, String> colMetodo = new TableColumn<>("Pago");
        colMetodo.setCellValueFactory(new PropertyValueFactory<>("metodoPago"));

        tablaHistorial.getColumns().addAll(colID, colFecha, colHora, colCliente, colProductos, colTotal, colEstado, colMetodo);

        // Datos de ejemplo
        ObservableList<HistorialVentaItem> historial = FXCollections.observableArrayList(
            new HistorialVentaItem("VEN001", "23/11/2025", "14:35", "Juan Pérez", "Pollo 1/4 x2, Bebidas", 180.00, "Completado", "Efectivo"),
            new HistorialVentaItem("VEN002", "23/11/2025", "14:52", "María García", "Menú Ejecutivo x1", 125.00, "Completado", "Tarjeta"),
            new HistorialVentaItem("VEN003", "23/11/2025", "15:10", "Cliente A", "Chicha Morada x3", 90.00, "Completado", "Efectivo"),
            new HistorialVentaItem("VEN004", "22/11/2025", "13:45", "Roberto López", "Pollo 1/2 x1, Acompañamientos", 95.00, "Completado", "QR"),
            new HistorialVentaItem("VEN005", "22/11/2025", "18:20", "Laura Martín", "Menú Premium x2", 280.00, "Completado", "Tarjeta"),
            new HistorialVentaItem("VEN006", "21/11/2025", "12:30", "Carlos Ruiz", "Pollo a la Brasa", 75.00, "Cancelado", "Efectivo"),
            new HistorialVentaItem("VEN007", "21/11/2025", "19:45", "Ana Flores", "Combo Familiar", 320.00, "Completado", "Transferencia"),
            new HistorialVentaItem("VEN008", "20/11/2025", "14:15", "Cliente B", "Bebidas x5", 60.00, "Completado", "Efectivo"),
            new HistorialVentaItem("VEN009", "20/11/2025", "16:00", "Miguel Torres", "Postres x4", 80.00, "Completado", "QR"),
            new HistorialVentaItem("VEN010", "19/11/2025", "11:50", "Patricia Gómez", "Pollo 1/4 x1", 45.00, "Completado", "Efectivo")
        );
        tablaHistorial.setItems(historial);

        // ===== SECCIÓN: ESTADÍSTICAS RÁPIDAS DEL HISTORIAL =====
        Label lblEstadisticasRapidas = new Label("Estadísticas Rápidas");
        lblEstadisticasRapidas.setStyle(labelStyle + " -fx-font-size: 13px;");

        HBox estadisticasBox = new HBox(15);
        estadisticasBox.setPadding(new Insets(10));
        estadisticasBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        VBox stat1 = createStatBox("Total Transacciones", "2,847", "#4CAF50");
        VBox stat2 = createStatBox("Transacciones Completadas", "2,823 (99.2%)", "#2196F3");
        VBox stat3 = createStatBox("Transacciones Canceladas", "24 (0.8%)", "#FF9800");
        VBox stat4 = createStatBox("Ticket Promedio", "S/ 156.50", "#9C27B0");

        estadisticasBox.getChildren().addAll(stat1, stat2, stat3, stat4);

        // ===== BOTONES DE EXPORTACIÓN =====
        HBox botonesExportar = new HBox(10);
        botonesExportar.setPadding(new Insets(10));
        botonesExportar.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        Button btnExportarHistorialCSV = new Button("Exportar Historial CSV");
        btnExportarHistorialCSV.setStyle("-fx-padding: 8px 16px; -fx-background-color: #4CAF50; -fx-text-fill: white;");
        btnExportarHistorialCSV.setOnAction(e -> showAlert("Éxito", "Historial exportado a CSV."));

        Button btnExportarHistorialPDF = new Button("Exportar Historial PDF");
        btnExportarHistorialPDF.setStyle("-fx-padding: 8px 16px; -fx-background-color: #d32f2f; -fx-text-fill: white;");
        btnExportarHistorialPDF.setOnAction(e -> showAlert("Éxito", "Historial exportado a PDF."));

        Button btnVerDetalles = new Button("Ver Detalles Seleccionado");
        btnVerDetalles.setStyle("-fx-padding: 8px 16px; -fx-background-color: #2196F3; -fx-text-fill: white;");
        btnVerDetalles.setOnAction(e -> {
            HistorialVentaItem seleccionado = tablaHistorial.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                showAlert("Detalles", "ID: " + seleccionado.getIdVenta() + "\n" +
                    "Cliente: " + seleccionado.getCliente() + "\n" +
                    "Total: S/ " + seleccionado.getTotal());
            } else {
                showAlert("Advertencia", "Seleccione una venta para ver detalles.");
            }
        });

        botonesExportar.getChildren().addAll(btnExportarHistorialCSV, btnExportarHistorialPDF, btnVerDetalles);

        // ===== ENSAMBLAJE FINAL =====
        ScrollPane scroll = new ScrollPane(new VBox(15,
            titulo,
            new Separator(),
            lblGenerador,
            generadorBox,
            new Separator(),
            lblFiltros,
            filtrosBox,
            new Separator(),
            lblTablaHistorial,
            tablaHistorial,
            new Separator(),
            lblEstadisticasRapidas,
            estadisticasBox,
            new Separator(),
            botonesExportar
        ));
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #f5f5f5;");

        root.getChildren().add(scroll);
        return root;
    }

    private static VBox createStatBox(String titulo, String valor, String color) {
        VBox box = new VBox(6);
        box.setPadding(new Insets(10));
        box.setStyle("-fx-background-color: " + color + "; -fx-border-radius: 4px;");
        box.setAlignment(Pos.CENTER);

        Label lblTitulo = new Label(titulo);
        lblTitulo.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px;");

        Label lblValor = new Label(valor);
        lblValor.setStyle("-fx-text-fill: #000000; -fx-font-size: 14px; -fx-font-weight: bold;");

        box.getChildren().addAll(lblTitulo, lblValor);
        return box;
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // ===== CLASE INTERNA =====
    public static class HistorialVentaItem {
        private String idVenta;
        private String fecha;
        private String hora;
        private String cliente;
        private String productos;
        private double total;
        private String estado;
        private String metodoPago;

        public HistorialVentaItem(String idVenta, String fecha, String hora, String cliente,
                                 String productos, double total, String estado, String metodoPago) {
            this.idVenta = idVenta;
            this.fecha = fecha;
            this.hora = hora;
            this.cliente = cliente;
            this.productos = productos;
            this.total = total;
            this.estado = estado;
            this.metodoPago = metodoPago;
        }

        public String getIdVenta() { return idVenta; }
        public String getFecha() { return fecha; }
        public String getHora() { return hora; }
        public String getCliente() { return cliente; }
        public String getProductos() { return productos; }
        public double getTotal() { return total; }
        public String getEstado() { return estado; }
        public String getMetodoPago() { return metodoPago; }
    }
}

package pe.edu.upeu.sysventas.servicio;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.util.JRLoader;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class ServicioJasper {

    private static final String REPORTS_DIR = "reports";

    public ServicioJasper() {
        try {
            Files.createDirectories(Paths.get(REPORTS_DIR));
        } catch (Exception e) {
            // ignore
        }
    }

    /**
     * Genera un PDF de comprobante simple sin conexión a BD.
     * @param ventaId ID de la venta
     * @param clienteNombre Nombre del cliente
     * @param clienteDni DNI del cliente
     * @param subtotal Subtotal
     * @param igv IGV
     * @param total Total
     * @return ruta del PDF generado o null si falló
     */
    public String generarComprobanteSimple(String ventaId, String clienteNombre, String clienteDni, 
                                           double subtotal, double igv, double total) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("ventaId", ventaId != null ? ventaId : "VEN-" + System.currentTimeMillis());
            params.put("clienteNombre", clienteNombre != null ? clienteNombre : "Cliente Anónimo");
            params.put("clienteDni", clienteDni != null ? clienteDni : "00000000");
            params.put("subtotal", subtotal);
            params.put("igv", igv);
            params.put("total", total);
            params.put("fecha", LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));

            return generarReportePDF("comprobante_simple.jrxml", params);
        } catch (Exception e) {
            System.err.println("Error generando comprobante: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Genera un PDF a partir de un archivo JRXML o .jasper ubicado en el classpath
     * dentro de la carpeta `jasper/` (copiada al classpath por el pom).
     *
     * @param reportName nombre del recurso (ej: "reporte_venta.jrxml" o "reporte_venta.jasper")
     * @param params parámetros opcionales para el reporte
     * @return ruta del PDF generado o null si falló
     */
    public String generarReportePDF(String reportName, Map<String, Object> params) {
        try {
            if (params == null) params = new HashMap<>();

            // Intentar cargar recurso desde classpath/jasper
            String resourcePath = "/jasper/" + reportName;
            InputStream is = getClass().getResourceAsStream(resourcePath);
            if (is == null) {
                System.err.println("No se encontró el recurso: " + resourcePath);
                return null;
            }

            // Si viene JRXML, compilarlo a JasperReport
            JasperReport jasperReport;
            if (reportName.toLowerCase().endsWith(".jrxml")) {
                jasperReport = JasperCompileManager.compileReport(is);
            } else {
                // cargar .jasper precompilado
                jasperReport = (JasperReport) JRLoader.loadObject(is);
            }

            // Usar datasource vacío por defecto; si necesitas usar datos, pásalos en params
            JRDataSource dataSource = new JREmptyDataSource();

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, dataSource);

            String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            String out = REPORTS_DIR + File.separator + reportName.replaceAll("\\.jrxml$|\\.jasper$", "") + "_" + ts + ".pdf";
            JasperExportManager.exportReportToPdfFile(jasperPrint, out);

            System.out.println("Reporte generado: " + out);
            return out;
        } catch (Exception e) {
            System.err.println("Error generando reporte Jasper: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}

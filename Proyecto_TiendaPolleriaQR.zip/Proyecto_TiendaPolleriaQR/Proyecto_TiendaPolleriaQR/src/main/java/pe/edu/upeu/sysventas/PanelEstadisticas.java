package pe.edu.upeu.sysventas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.servicio.ServicioVenta;
import pe.edu.upeu.sysventas.servicio.VentaDiaObservable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;

/**
 * Panel de Estadísticas - Análisis de ventas por período.
 * Muestra: Ingresos y ventas por día/semana/mes, tendencias, producto más vendido.
 * Se sincroniza en tiempo real con VentaDiaObservable para mostrar datos de hoy.
 */
@SuppressWarnings("unchecked")
public class PanelEstadisticas {

    public static Pane crear(ServicioVenta servicioVenta) {
        VBox root = new VBox(15);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #f5f5f5;");

        Label titulo = new Label("Estadísticas y Análisis - Pollería de QR");
        titulo.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 18px; -fx-font-weight: bold;");

        String labelStyle = "-fx-text-fill: #333333; -fx-font-size: 12px; -fx-font-weight: bold;";

        // Obtener observable de ventas del día para sincronización en tiempo real
        VentaDiaObservable observable = VentaDiaObservable.getInstance();

        // ===== SECCIÓN: SELECTOR DE PERÍODO =====
        Label lblPeriodo = new Label("Seleccionar Período");
        lblPeriodo.setStyle(labelStyle + " -fx-font-size: 13px;");

        ComboBox<String> comboPeriodo = new ComboBox<>();
        comboPeriodo.setItems(FXCollections.observableArrayList(
            "Hoy",
            "Esta Semana",
            "Este Mes",
            "Este Año",
            "Personalizado"
        ));
        comboPeriodo.setValue("Hoy");
        comboPeriodo.setStyle("-fx-padding: 8px; -fx-border-radius: 4px; -fx-border-color: #cccccc;");
        comboPeriodo.setPrefWidth(150);

        DatePicker dpInicio = new DatePicker(LocalDate.now());
        DatePicker dpFin = new DatePicker(LocalDate.now());

        HBox periodoBox = new HBox(15, comboPeriodo, 
            new Label("Desde:"), dpInicio, 
            new Label("Hasta:"), dpFin);
        periodoBox.setPadding(new Insets(10));
        periodoBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");
        periodoBox.setAlignment(Pos.CENTER_LEFT);

        comboPeriodo.setOnAction(e -> {
            String periodo = comboPeriodo.getValue();
            LocalDate hoy = LocalDate.now();
            switch (periodo) {
                case "Hoy":
                    dpInicio.setValue(hoy);
                    dpFin.setValue(hoy);
                    break;
                case "Esta Semana":
                    dpInicio.setValue(hoy.minusDays(hoy.getDayOfWeek().getValue() - 1));
                    dpFin.setValue(hoy);
                    break;
                case "Este Mes":
                    dpInicio.setValue(hoy.withDayOfMonth(1));
                    dpFin.setValue(hoy);
                    break;
                case "Este Año":
                    dpInicio.setValue(LocalDate.of(hoy.getYear(), 1, 1));
                    dpFin.setValue(hoy);
                    break;
            }
        });

        // ===== SECCIÓN: INDICADORES CLAVE =====
        Label lblKPI = new Label("Indicadores Clave del Período (Datos de Hoy - En Tiempo Real)");
        lblKPI.setStyle(labelStyle + " -fx-font-size: 13px;");

        Label lblIngresos = new Label("Ingresos Totales");
        lblIngresos.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label valIngresos = new Label("S/ 0.00");
        valIngresos.setStyle("-fx-text-fill: #000000; -fx-font-size: 16px; -fx-font-weight: bold;");
        VBox cardIngresos = new VBox(8, lblIngresos, valIngresos);
        cardIngresos.setPadding(new Insets(12));
        cardIngresos.setStyle("-fx-background-color: #4CAF50; -fx-border-radius: 4px;");
        cardIngresos.setAlignment(Pos.CENTER);

        Label lblVentas = new Label("Total de Ventas");
        lblVentas.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label valVentas = new Label("0");
        valVentas.setStyle("-fx-text-fill: #000000; -fx-font-size: 16px; -fx-font-weight: bold;");
        VBox cardVentas = new VBox(8, lblVentas, valVentas);
        cardVentas.setPadding(new Insets(12));
        cardVentas.setStyle("-fx-background-color: #2196F3; -fx-border-radius: 4px;");
        cardVentas.setAlignment(Pos.CENTER);

        Label lblPromedio = new Label("Venta Promedio");
        lblPromedio.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label valPromedio = new Label("S/ 0.00");
        valPromedio.setStyle("-fx-text-fill: #000000; -fx-font-size: 16px; -fx-font-weight: bold;");
        VBox cardPromedio = new VBox(8, lblPromedio, valPromedio);
        cardPromedio.setPadding(new Insets(12));
        cardPromedio.setStyle("-fx-background-color: #FF9800; -fx-border-radius: 4px;");
        cardPromedio.setAlignment(Pos.CENTER);

        Label lblCrecimiento = new Label("Crecimiento vs Mes Anterior");
        lblCrecimiento.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label valCrecimiento = new Label("+12.5%");
        valCrecimiento.setStyle("-fx-text-fill: #000000; -fx-font-size: 16px; -fx-font-weight: bold;");
        VBox cardCrecimiento = new VBox(8, lblCrecimiento, valCrecimiento);
        cardCrecimiento.setPadding(new Insets(12));
        cardCrecimiento.setStyle("-fx-background-color: #9C27B0; -fx-border-radius: 4px;");
        cardCrecimiento.setAlignment(Pos.CENTER);

        // LISTENERS EN TIEMPO REAL para sincronizar datos de hoy
        observable.totalIngresosProperty().addListener((obs, oldVal, newVal) -> {
            valIngresos.setText(String.format("S/ %.2f", newVal.doubleValue()));
        });
        
        observable.totalVentasProperty().addListener((obs, oldVal, newVal) -> {
            valVentas.setText(String.valueOf(newVal.intValue()));
        });
        
        observable.ingresoPromedioProperty().addListener((obs, oldVal, newVal) -> {
            valPromedio.setText(String.format("S/ %.2f", newVal.doubleValue()));
        });

        HBox kpiCards = new HBox(15, cardIngresos, cardVentas, cardPromedio, cardCrecimiento);
        kpiCards.setPadding(new Insets(10));
        kpiCards.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        // ===== SECCIÓN: TABLA DE ESTADÍSTICAS POR DÍA =====
        Label lblTablaEstadisticas = new Label("Estadísticas Diarias");
        lblTablaEstadisticas.setStyle(labelStyle + " -fx-font-size: 13px;");

        TableView<EstadisticaDiaItem> tablaEstadisticas = new TableView<>();
        tablaEstadisticas.setPrefHeight(250);

        TableColumn<EstadisticaDiaItem, String> colFecha = new TableColumn<>("Fecha");
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));

        TableColumn<EstadisticaDiaItem, Integer> colVentas2 = new TableColumn<>("Ventas");
        colVentas2.setCellValueFactory(new PropertyValueFactory<>("numVentas"));

        TableColumn<EstadisticaDiaItem, Double> colIngresos2 = new TableColumn<>("Ingresos");
        colIngresos2.setCellValueFactory(new PropertyValueFactory<>("ingresos"));

        TableColumn<EstadisticaDiaItem, Double> colPromedio2 = new TableColumn<>("Promedio");
        colPromedio2.setCellValueFactory(new PropertyValueFactory<>("promedio"));

        TableColumn<EstadisticaDiaItem, String> colTendencia = new TableColumn<>("Tendencia");
        colTendencia.setCellValueFactory(new PropertyValueFactory<>("tendencia"));

        tablaEstadisticas.getColumns().addAll(colFecha, colVentas2, colIngresos2, colPromedio2, colTendencia);

        // Cargar datos de ejemplo
        ObservableList<EstadisticaDiaItem> datos = FXCollections.observableArrayList(
            new EstadisticaDiaItem("23/11/2025", 12, 420.00, 35.00, "↑ +5%"),
            new EstadisticaDiaItem("22/11/2025", 10, 380.00, 38.00, "↓ -3%"),
            new EstadisticaDiaItem("21/11/2025", 15, 520.00, 34.67, "↑ +8%"),
            new EstadisticaDiaItem("20/11/2025", 11, 380.00, 34.55, "→ 0%"),
            new EstadisticaDiaItem("19/11/2025", 9, 310.00, 34.44, "↑ +2%")
        );
        tablaEstadisticas.setItems(datos);

        // ===== SECCIÓN: PRODUCTOS MÁS VENDIDOS =====
        Label lblTopProductos = new Label("Productos Más Vendidos en el Período");
        lblTopProductos.setStyle(labelStyle + " -fx-font-size: 13px;");

        TableView<ProductoEstadItem> tablaProductos = new TableView<>();
        tablaProductos.setPrefHeight(200);

        TableColumn<ProductoEstadItem, String> colProd = new TableColumn<>("Producto");
        colProd.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colProd.setPrefWidth(250);

        TableColumn<ProductoEstadItem, Integer> colCant = new TableColumn<>("Cantidad");
        colCant.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        TableColumn<ProductoEstadItem, Double> colIngre = new TableColumn<>("Ingresos");
        colIngre.setCellValueFactory(new PropertyValueFactory<>("ingresos"));

        TableColumn<ProductoEstadItem, String> colPorce = new TableColumn<>("% del Total");
        colPorce.setCellValueFactory(new PropertyValueFactory<>("porcentaje"));

        tablaProductos.getColumns().addAll(colProd, colCant, colIngre, colPorce);

        ObservableList<ProductoEstadItem> productosTop = FXCollections.observableArrayList(
            new ProductoEstadItem("Pollo a la Brasa 1/4", 85, 1700.00, "32.4%"),
            new ProductoEstadItem("Menú Ejecutivo", 42, 1260.00, "24.0%"),
            new ProductoEstadItem("Gaseosa 2L", 60, 720.00, "13.7%"),
            new ProductoEstadItem("Chicha Morada", 38, 380.00, "7.2%"),
            new ProductoEstadItem("Pollo 1/2", 28, 700.00, "13.3%")
        );
        tablaProductos.setItems(productosTop);

        // ===== SECCIÓN: COMPARACIÓN CON PERÍODOS ANTERIORES =====
        Label lblComparacion = new Label("Comparación con Períodos Anteriores");
        lblComparacion.setStyle(labelStyle + " -fx-font-size: 13px;");

        VBox boxComparacion = new VBox(10);
        boxComparacion.setPadding(new Insets(10));
        boxComparacion.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");
        boxComparacion.getChildren().addAll(
            new HBox(20,
                createComparisonBar("Este Mes", 5250, "#4CAF50"),
                createComparisonBar("Mes Anterior", 4665, "#FF9800")
            )
        );

        // ===== BOTONES DE CONTROL =====
        Button btnRefrescar = new Button("Refrescar");
        btnRefrescar.setStyle("-fx-padding: 8px 16px; -fx-background-color: #2196F3; -fx-text-fill: white;");
        btnRefrescar.setOnAction(e -> showAlert("Actualizado", "Datos estadísticos actualizados."));

        Button btnExportar = new Button("Exportar Reporte");
        btnExportar.setStyle("-fx-padding: 8px 16px; -fx-background-color: #4CAF50; -fx-text-fill: white;");
        btnExportar.setOnAction(e -> showAlert("Éxito", "Reporte exportado."));

        HBox botones = new HBox(10, btnRefrescar, btnExportar);
        botones.setPadding(new Insets(10));
        botones.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        // ===== ENSAMBLAJE FINAL =====
        ScrollPane scroll = new ScrollPane(new VBox(15,
            titulo,
            new Separator(),
            lblPeriodo,
            periodoBox,
            new Separator(),
            lblKPI,
            kpiCards,
            new Separator(),
            lblTablaEstadisticas,
            tablaEstadisticas,
            new Separator(),
            lblTopProductos,
            tablaProductos,
            new Separator(),
            lblComparacion,
            boxComparacion,
            new Separator(),
            botones
        ));
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #f5f5f5;");

        root.getChildren().add(scroll);
        return root;
    }

    private static VBox createStatCard(String titulo, String valor, String color) {
        VBox card = new VBox(8);
        card.setPadding(new Insets(12));
        card.setStyle("-fx-background-color: " + color + "; -fx-border-radius: 4px;");
        card.setAlignment(Pos.CENTER);

        Label lblTitulo = new Label(titulo);
        lblTitulo.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px;");

        Label lblValor = new Label(valor);
        lblValor.setStyle("-fx-text-fill: #000000; -fx-font-size: 16px; -fx-font-weight: bold;");

        card.getChildren().addAll(lblTitulo, lblValor);
        return card;
    }

    private static HBox createComparisonBar(String label, double valor, String color) {
        HBox box = new HBox(10);
        box.setAlignment(Pos.CENTER_LEFT);

        Label lblLabel = new Label(label);
        lblLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold;");
        lblLabel.setPrefWidth(120);

        ProgressBar bar = new ProgressBar(valor / 6000.0);
        bar.setPrefWidth(250);
        bar.setStyle("-fx-accent: " + color + ";");

        Label lblValor = new Label(String.format("S/ %.0f", valor));
        lblValor.setStyle("-fx-font-size: 12px;");

        box.getChildren().addAll(lblLabel, bar, lblValor);
        return box;
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // ===== CLASES INTERNAS =====
    public static class EstadisticaDiaItem {
        private String fecha;
        private int numVentas;
        private double ingresos;
        private double promedio;
        private String tendencia;

        public EstadisticaDiaItem(String fecha, int numVentas, double ingresos, double promedio, String tendencia) {
            this.fecha = fecha;
            this.numVentas = numVentas;
            this.ingresos = ingresos;
            this.promedio = promedio;
            this.tendencia = tendencia;
        }

        public String getFecha() { return fecha; }
        public int getNumVentas() { return numVentas; }
        public double getIngresos() { return ingresos; }
        public double getPromedio() { return promedio; }
        public String getTendencia() { return tendencia; }
    }

    public static class ProductoEstadItem {
        private String nombre;
        private int cantidad;
        private double ingresos;
        private String porcentaje;

        public ProductoEstadItem(String nombre, int cantidad, double ingresos, String porcentaje) {
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.ingresos = ingresos;
            this.porcentaje = porcentaje;
        }

        public String getNombre() { return nombre; }
        public int getCantidad() { return cantidad; }
        public double getIngresos() { return ingresos; }
        public String getPorcentaje() { return porcentaje; }
    }
}

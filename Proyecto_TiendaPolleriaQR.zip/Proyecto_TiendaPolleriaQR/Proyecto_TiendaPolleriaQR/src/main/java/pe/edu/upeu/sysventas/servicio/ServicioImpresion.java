package pe.edu.upeu.sysventas.servicio;

import javax.print.*;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Servicio para detectar, formatear y enviar tickets a impresoras térmicas.
 * Soporta impresoras de 58mm y 80mm de ancho.
 * Compatible con USB, red (compartidas) y Bluetooth en Windows.
 */
public class ServicioImpresion {

    public static final int ANCHO_58MM = 32;   // caracteres de ancho (monospace)
    public static final int ANCHO_80MM = 48;   // caracteres de ancho (monospace)
    public static final String NOMBRE_NEGOCIO = "POLLERÍA DE QR";
    public static final String RUC = "20123456789";  // Actualizar con RUC real si aplica
    public static final String DIRECCION = "Av. Principal 123, Lima, PE";
    public static final String TELEFONO = "+51 900 123 456";

    // Códigos ESC/POS para impresoras térmicas
    private static final byte ESC = 0x1B;
    private static final byte GS = 0x1D;
    
    // Secuencias ESC/POS
    private static final byte[] CMD_RESET = {ESC, '@'};                     // Reset printer
    private static final byte[] CMD_ALIGN_CENTER = {ESC, 'a', 1};           // Alineación centro
    private static final byte[] CMD_ALIGN_LEFT = {ESC, 'a', 0};             // Alineación izquierda
    private static final byte[] CMD_ALIGN_RIGHT = {ESC, 'a', 2};            // Alineación derecha
    private static final byte[] CMD_BOLD_ON = {ESC, 'E', 1};                // Bold on
    private static final byte[] CMD_BOLD_OFF = {ESC, 'E', 0};               // Bold off
    private static final byte[] CMD_DOUBLE_WIDTH = {ESC, 'W', 1};           // Ancho doble
    private static final byte[] CMD_NORMAL_WIDTH = {ESC, 'W', 0};           // Ancho normal
    private static final byte[] CMD_CUT_PAPER = {GS, 'V', 'A', 0};          // Corte automático del papel
    private static final byte[] CMD_LF = {0x0A};                             // Line feed
    private static final byte[] CMD_FF = {0x0C};                             // Form feed

    /**
     * Obtiene lista de impresoras disponibles en el sistema.
     * @return Lista de nombres de impresoras encontradas.
     */
    public static List<String> obtenerImpresoras() {
        List<String> impresoras = new ArrayList<>();
        try {
            PrintService[] servicios = PrintServiceLookup.lookupPrintServices(null, null);
            for (PrintService servicio : servicios) {
                impresoras.add(servicio.getName());
            }
        } catch (Exception e) {
            System.err.println("Error obteniendo lista de impresoras: " + e.getMessage());
        }
        return impresoras;
    }

    /**
     * Busca una impresora térmica por nombre (contiene palabras clave comunes).
     * @return Nombre de la impresora térmica o null si no se encontró.
     */
    public static String detectarImpressoraTermica() {
        String[] palabrasClave = {"thermal", "térmico", "ticket", "pos", "printer", "recibo"};
        for (String impresora : obtenerImpresoras()) {
            String nombreBajo = impresora.toLowerCase();
            for (String palabra : palabrasClave) {
                if (nombreBajo.contains(palabra)) {
                    return impresora;
                }
            }
        }
        return null;  // No se encontró impresora térmica
    }

    /**
     * Prueba la conexión con una impresora.
     * @param nombreImpresora Nombre de la impresora a probar.
     * @return true si la impresora está disponible, false en caso contrario.
     */
    public static boolean probarImpresora(String nombreImpresora) {
        try {
            PrintService printService = obtenerServicioImpresion(nombreImpresora);
            if (printService == null) return false;
            
            // Intentar enviar un comando simple de reset
            byte[] testData = CMD_RESET;
            return imprimirDatos(nombreImpresora, testData);
        } catch (Exception e) {
            System.err.println("Error probando impresora: " + e.getMessage());
            return false;
        }
    }

    /**
     * Genera el contenido del ticket con alineación y formateo para impresoras térmicas.
     * @param ancho Ancho en caracteres (ANCHO_58MM o ANCHO_80MM).
     * @param productos Lista de productos [{nombre, cantidad, precio_unitario}, ...].
     * @param subtotal Subtotal de la venta.
     * @param igv IGV a aplicar (0 si no aplica).
     * @param total Total final.
     * @param clienteNombre Nombre del cliente (opcional).
     * @param clienteDni DNI del cliente (opcional).
     * @return String con el contenido del ticket formateado.
     */
    public static String generarTicket(
            int ancho,
            List<Map<String, Object>> productos,
            double subtotal,
            double igv,
            double total,
            String clienteNombre,
            String clienteDni
    ) {
        StringBuilder sb = new StringBuilder();
        
        // Encabezado
        sb.append(centrar(NOMBRE_NEGOCIO, ancho)).append("\n");
        sb.append(centrar("=" .repeat(Math.min(40, ancho)), ancho)).append("\n");
        
        sb.append(centrar("RUC: " + RUC, ancho)).append("\n");
        sb.append(centrar(DIRECCION, ancho)).append("\n");
        sb.append(centrar("Tel: " + TELEFONO, ancho)).append("\n");
        
        // Fecha y hora
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String fechaHora = sdf.format(new Date());
        sb.append(centrar(fechaHora, ancho)).append("\n");
        sb.append(centrar("-".repeat(Math.min(40, ancho)), ancho)).append("\n\n");
        
        // Datos del cliente (si aplica)
        if (clienteNombre != null && !clienteNombre.trim().isEmpty()) {
            sb.append("Cliente: ").append(clienteNombre).append("\n");
            if (clienteDni != null && !clienteDni.trim().isEmpty()) {
                sb.append("DNI: ").append(clienteDni).append("\n");
            }
            sb.append("\n");
        }
        
        // Detalle de productos
        sb.append(formatearEncabezadoProductos(ancho)).append("\n");
        sb.append(centrar("-".repeat(Math.min(40, ancho)), ancho)).append("\n");
        
        double subtotalCalculado = 0;
        for (Map<String, Object> prod : productos) {
            String nombre = (String) prod.getOrDefault("nombre", "Producto");
            Integer cantidad = (Integer) prod.getOrDefault("cantidad", 1);
            Double precio = (Double) prod.getOrDefault("precio", 0.0);
            
            double subProd = cantidad * precio;
            subtotalCalculado += subProd;
            
            sb.append(formatearProducto(nombre, cantidad, precio, subProd, ancho)).append("\n");
        }
        
        sb.append(centrar("-".repeat(Math.min(40, ancho)), ancho)).append("\n\n");
        
        // Totales
        sb.append(formatearTotales(subtotal, igv, total, ancho));
        
        // Pie de página
        sb.append("\n").append(centrar("-".repeat(Math.min(40, ancho)), ancho)).append("\n");
        sb.append(centrar("Gracias por su compra", ancho)).append("\n");
        sb.append(centrar("Vuelva pronto", ancho)).append("\n\n");
        
        return sb.toString();
    }

    /**
     * Imprime un ticket directamente en la impresora especificada.
     * @param nombreImpresora Nombre de la impresora.
     * @param ancho Ancho en caracteres (ANCHO_58MM o ANCHO_80MM).
     * @param productos Lista de productos.
     * @param subtotal Subtotal.
     * @param igv IGV.
     * @param total Total.
     * @param clienteNombre Nombre del cliente.
     * @param clienteDni DNI del cliente.
     * @return true si la impresión fue exitosa, false en caso contrario.
     */
    public static boolean imprimirTicket(
            String nombreImpresora,
            int ancho,
            List<Map<String, Object>> productos,
            double subtotal,
            double igv,
            double total,
            String clienteNombre,
            String clienteDni
    ) {
        try {
            // Generar contenido del ticket
            String contenido = generarTicket(ancho, productos, subtotal, igv, total, clienteNombre, clienteDni);
            
            // Convertir a bytes con secuencias ESC/POS
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            
            // Reset de impresora
            baos.write(CMD_RESET);
            baos.write(CMD_LF);
            
            // Alineación y contenido
            baos.write(CMD_ALIGN_CENTER);
            baos.write(contenido.getBytes(StandardCharsets.UTF_8));
            
            // Alineación por defecto
            baos.write(CMD_ALIGN_LEFT);
            
            // Saltos de línea finales
            for (int i = 0; i < 5; i++) {
                baos.write(CMD_LF);
            }
            
            // Intento de corte automático (algunos modelos lo soportan)
            baos.write(CMD_CUT_PAPER);
            
            byte[] datos = baos.toByteArray();
            
            // Enviar a impresora
            return imprimirDatos(nombreImpresora, datos);
            
        } catch (Exception e) {
            System.err.println("Error imprimiendo ticket: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Imprime datos crudos (bytes) en la impresora especificada.
     * @param nombreImpresora Nombre de la impresora.
     * @param datos Datos a imprimir (bytes).
     * @return true si fue exitoso, false en caso contrario.
     */
    private static boolean imprimirDatos(String nombreImpresora, byte[] datos) {
        try {
            PrintService printService = obtenerServicioImpresion(nombreImpresora);
            if (printService == null) {
                System.err.println("Impresora no encontrada: " + nombreImpresora);
                return false;
            }
            
            // Atributos de impresión
            PrintRequestAttributeSet atributos = new HashPrintRequestAttributeSet();
            atributos.add(new Copies(1));
            
            // Crear Doc
            Doc doc = new SimpleDoc(datos, DocFlavor.BYTE_ARRAY.AUTOSENSE, null);
            
            // Crear Job y enviar
            DocPrintJob job = printService.createPrintJob();
            job.print(doc, atributos);
            
            System.out.println("Impresión enviada exitosamente a: " + nombreImpresora);
            return true;
            
        } catch (PrintException e) {
            System.err.println("Error en impresión: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            System.err.println("Error inesperado: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Obtiene el PrintService correspondiente a un nombre de impresora.
     * @param nombreImpresora Nombre de la impresora.
     * @return PrintService o null si no se encuentra.
     */
    private static PrintService obtenerServicioImpresion(String nombreImpresora) {
        try {
            for (PrintService servicio : PrintServiceLookup.lookupPrintServices(null, null)) {
                if (servicio.getName().equalsIgnoreCase(nombreImpresora)) {
                    return servicio;
                }
            }
        } catch (Exception e) {
            System.err.println("Error obteniendo servicio de impresión: " + e.getMessage());
        }
        return null;
    }

    /**
     * Formatea una línea centrada.
     */
    private static String centrar(String texto, int ancho) {
        if (texto.length() >= ancho) {
            return texto.substring(0, ancho);
        }
        int espacios = (ancho - texto.length()) / 2;
        return " ".repeat(espacios) + texto;
    }

    /**
     * Formatea el encabezado de productos (Producto | Cant. | Precio | Subtotal).
     */
    private static String formatearEncabezadoProductos(int ancho) {
        if (ancho == ANCHO_58MM) {
            return "Producto          Cant  Precio  Subtotal";
        } else {
            return "Producto                  Cant  Precio    Subtotal";
        }
    }

    /**
     * Formatea una fila de producto.
     */
    private static String formatearProducto(String nombre, int cantidad, double precio, double subtotal, int ancho) {
        String cantStr = String.valueOf(cantidad);
        String precioStr = String.format("%.2f", precio);
        String subtotalStr = String.format("%.2f", subtotal);
        
        if (ancho == ANCHO_58MM) {
            // Formato para 58mm (32 caracteres)
            String nombreAcortado = nombre.length() > 14 ? nombre.substring(0, 14) : nombre;
            return String.format("%-14s %2s  S/%-5s  S/%-6s", nombreAcortado, cantStr, precioStr, subtotalStr);
        } else {
            // Formato para 80mm (48 caracteres)
            String nombreAcortado = nombre.length() > 24 ? nombre.substring(0, 24) : nombre;
            return String.format("%-24s %2s  S/%-7s  S/%-8s", nombreAcortado, cantStr, precioStr, subtotalStr);
        }
    }

    /**
     * Formatea las líneas de totales (Subtotal, IGV, Total).
     */
    private static String formatearTotales(double subtotal, double igv, double total, int ancho) {
        StringBuilder sb = new StringBuilder();
        
        String subtotalStr = String.format("Subtotal: S/ %.2f", subtotal);
        String igvStr = String.format("IGV (18%%): S/ %.2f", igv);
        String totalStr = String.format("TOTAL: S/ %.2f", total);
        
        if (ancho == ANCHO_58MM) {
            sb.append(String.format("%-32s\n", subtotalStr));
            sb.append(String.format("%-32s\n", igvStr));
            sb.append(String.format("%-32s", totalStr));
        } else {
            sb.append(String.format("%-48s\n", subtotalStr));
            sb.append(String.format("%-48s\n", igvStr));
            sb.append(String.format("%-48s", totalStr));
        }
        
        return sb.toString();
    }

    /**
     * Prueba simple: genera e imprime un ticket de prueba.
     */
    public static void imprimirTicketPrueba(String nombreImpresora, int ancho) {
        List<Map<String, Object>> productos = Arrays.asList(
                Map.of("nombre", "Pollo 1/4 c/ p.", "cantidad", 2, "precio", 15.50),
                Map.of("nombre", "Pollo 1/2", "cantidad", 1, "precio", 28.00),
                Map.of("nombre", "Papas (Porción)", "cantidad", 3, "precio", 5.00),
                Map.of("nombre", "Ají especial", "cantidad", 2, "precio", 3.50)
        );
        
        double subtotal = 2*15.50 + 28.00 + 3*5.00 + 2*3.50;
        double igv = subtotal * 0.18;
        double total = subtotal + igv;
        
        boolean resultado = imprimirTicket(
                nombreImpresora,
                ancho,
                productos,
                subtotal,
                igv,
                total,
                "Juan Pérez",
                "12345678"
        );
        
        if (resultado) {
            System.out.println("✓ Ticket de prueba impreso exitosamente");
        } else {
            System.out.println("✗ Error imprimiendo ticket de prueba");
        }
    }
}

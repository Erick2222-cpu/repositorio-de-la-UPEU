package pe.edu.upeu.sysventas.servicio;

import java.util.List;
import java.util.Scanner;

/**
 * Prueba interactiva del ServicioImpresion.
 * Permite listar impresoras, detectar térmica y enviar ticket de prueba.
 */
public class PruebaImpresion {

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("   PRUEBA DE SERVICIO DE IMPRESIÓN");
        System.out.println("========================================\n");

        // 1. Listar impresoras disponibles
        System.out.println("1. IMPRESORAS DISPONIBLES EN EL SISTEMA:");
        List<String> impresoras = ServicioImpresion.obtenerImpresoras();
        
        if (impresoras.isEmpty()) {
            System.out.println("   ✗ No se encontraron impresoras");
            return;
        }

        for (int i = 0; i < impresoras.size(); i++) {
            System.out.println("   " + (i + 1) + ". " + impresoras.get(i));
        }

        // 2. Detectar impresora térmica
        System.out.println("\n2. DETECCIÓN AUTOMÁTICA DE IMPRESORA TÉRMICA:");
        String impressoraTermica = ServicioImpresion.detectarImpressoraTermica();
        if (impressoraTermica != null) {
            System.out.println("   ✓ Impresora térmica detectada: " + impressoraTermica);
        } else {
            System.out.println("   ✗ No se encontró impresora térmica automáticamente");
        }

        // 3. Seleccionar impresora para prueba
        System.out.println("\n3. SELECCIONA UNA IMPRESORA PARA PRUEBA:");
        System.out.print("   Ingresa el número de impresora (o 0 para cancelar): ");
        
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;
        try {
            opcion = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("   ✗ Entrada inválida");
            return;
        }

        if (opcion < 1 || opcion > impresoras.size()) {
            System.out.println("   ✗ Opción cancelada o inválida");
            return;
        }

        String impressoraSeleccionada = impresoras.get(opcion - 1);
        System.out.println("   → Impresora seleccionada: " + impressoraSeleccionada);

        // 4. Probar conexión
        System.out.println("\n4. PRUEBA DE CONEXIÓN:");
        if (ServicioImpresion.probarImpresora(impressoraSeleccionada)) {
            System.out.println("   ✓ Conexión OK con: " + impressoraSeleccionada);
        } else {
            System.out.println("   ✗ No se pudo conectar a: " + impressoraSeleccionada);
            return;
        }

        // 5. Seleccionar ancho del papel
        System.out.println("\n5. SELECCIONA ANCHO DE PAPEL:");
        System.out.println("   1. 58mm (32 caracteres)");
        System.out.println("   2. 80mm (48 caracteres)");
        System.out.print("   Ingresa tu opción (1 o 2): ");
        
        int anchoOpcion = 0;
        try {
            anchoOpcion = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("   ✗ Entrada inválida");
            return;
        }

        int ancho;
        if (anchoOpcion == 1) {
            ancho = ServicioImpresion.ANCHO_58MM;
            System.out.println("   → Ancho seleccionado: 58mm");
        } else if (anchoOpcion == 2) {
            ancho = ServicioImpresion.ANCHO_80MM;
            System.out.println("   → Ancho seleccionado: 80mm");
        } else {
            System.out.println("   ✗ Opción inválida");
            return;
        }

        // 6. Enviar ticket de prueba
        System.out.println("\n6. IMPRIMIENDO TICKET DE PRUEBA...\n");
        ServicioImpresion.imprimirTicketPrueba(impressoraSeleccionada, ancho);

        System.out.println("\n========================================");
        System.out.println("   FIN DE PRUEBA");
        System.out.println("========================================");
    }
}

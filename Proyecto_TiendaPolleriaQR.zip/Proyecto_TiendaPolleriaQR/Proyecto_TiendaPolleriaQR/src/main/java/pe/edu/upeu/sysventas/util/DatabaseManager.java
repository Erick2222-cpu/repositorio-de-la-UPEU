package pe.edu.upeu.sysventas.util;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Gestor centralizado de base de datos SQLite para la aplicación Pollería de QR.
 * Maneja conexiones, inicialización de tablas y operaciones comunes.
 */
public class DatabaseManager {
    private static final String DB_PATH = "data/data_y_ventas.db";
    private static final String JDBC_URL = "jdbc:sqlite:" + DB_PATH;
    private static DatabaseManager instance;

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se pudo cargar el driver SQLite JDBC");
            e.printStackTrace();
        }
    }

    private DatabaseManager() {
        ensureDirectoryExists();
        initializeDatabase();
    }

    /**
     * Obtiene la instancia singleton de DatabaseManager
     */
    public static synchronized DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    /**
     * Asegura que el directorio /data/ exista
     */
    private void ensureDirectoryExists() {
        try {
            Files.createDirectories(Paths.get("data"));
        } catch (Exception e) {
            System.err.println("Error creando directorio data/: " + e.getMessage());
        }
    }

    /**
     * Obtiene una conexión a la base de datos
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL);
    }

    /**
     * Inicializa las tablas de la base de datos si no existen
     */
    private void initializeDatabase() {
        try (Connection conn = getConnection()) {
            createTables(conn);
            System.out.println("✓ Base de datos inicializada: " + DB_PATH);
        } catch (SQLException e) {
            System.err.println("Error inicializando base de datos: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Crea todas las tablas necesarias para la aplicación
     */
    private void createTables(Connection conn) throws SQLException {
        String[] sqlStatements = {
            // Tabla de Usuarios
            "CREATE TABLE IF NOT EXISTS usuarios (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  username TEXT UNIQUE NOT NULL," +
            "  password_hash TEXT NOT NULL," +
            "  is_admin INTEGER DEFAULT 0," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")",

            // Tabla de Categorías
            "CREATE TABLE IF NOT EXISTS categorias (" +
            "  id TEXT PRIMARY KEY," +
            "  nombre TEXT NOT NULL UNIQUE," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")",

            // Tabla de Productos
            "CREATE TABLE IF NOT EXISTS productos (" +
            "  id TEXT PRIMARY KEY," +
            "  nombre TEXT NOT NULL," +
            "  categoria_id TEXT NOT NULL," +
            "  descripcion TEXT," +
            "  presentacion TEXT," +
            "  precio REAL NOT NULL," +
            "  stock INTEGER DEFAULT 0," +
            "  imagen TEXT," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "  FOREIGN KEY(categoria_id) REFERENCES categorias(id)" +
            ")",

            // Tabla de Ventas
            "CREATE TABLE IF NOT EXISTS ventas (" +
            "  id TEXT PRIMARY KEY," +
            "  username TEXT NOT NULL," +
            "  fecha_hora DATETIME NOT NULL," +
            "  total REAL NOT NULL," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "  FOREIGN KEY(username) REFERENCES usuarios(username)" +
            ")",

            // Tabla de Items de Venta
            "CREATE TABLE IF NOT EXISTS venta_items (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  venta_id TEXT NOT NULL," +
            "  producto_id TEXT NOT NULL," +
            "  nombre_producto TEXT NOT NULL," +
            "  cantidad INTEGER NOT NULL," +
            "  precio_unitario REAL NOT NULL," +
            "  FOREIGN KEY(venta_id) REFERENCES ventas(id)," +
            "  FOREIGN KEY(producto_id) REFERENCES productos(id)" +
            ")",

            // Tabla de Clientes (datos de comprador por venta)
            "CREATE TABLE IF NOT EXISTS clientes (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  venta_id TEXT UNIQUE NOT NULL," +
            "  nombre TEXT," +
            "  dni TEXT," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "  FOREIGN KEY(venta_id) REFERENCES ventas(id)" +
            ")",

            // Tabla de Historial/Auditoría
            "CREATE TABLE IF NOT EXISTS auditoria (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  tabla TEXT NOT NULL," +
            "  operacion TEXT NOT NULL," +
            "  registro_id TEXT," +
            "  detalles TEXT," +
            "  usuario TEXT," +
            "  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")"
        };

        try (Statement stmt = conn.createStatement()) {
            for (String sql : sqlStatements) {
                stmt.execute(sql);
            }
        }
    }

    /**
     * Verifica si la base de datos ya está migrada (contiene datos)
     */
    public boolean isDatabaseMigrated() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as count FROM usuarios")) {
            if (rs.next()) {
                return rs.getInt("count") > 0;
            }
        } catch (SQLException e) {
            return false;
        }
        return false;
    }

    /**
     * Ejecuta una query que retorna resultados
     */
    public ResultSet executeQuery(String sql, Object... params) throws SQLException {
        Connection conn = getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        setParameters(pstmt, params);
        return pstmt.executeQuery();
    }

    /**
     * Ejecuta una actualización (INSERT, UPDATE, DELETE)
     */
    public int executeUpdate(String sql, Object... params) throws SQLException {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            setParameters(pstmt, params);
            return pstmt.executeUpdate();
        }
    }

    /**
     * Inserta un registro y retorna el ID generado (para autoincrement)
     */
    public long executeInsertGetId(String sql, Object... params) throws SQLException {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            setParameters(pstmt, params);
            pstmt.executeUpdate();
            
            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        }
        return -1;
    }

    /**
     * Establece los parámetros en un PreparedStatement
     */
    private void setParameters(PreparedStatement pstmt, Object... params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            Object param = params[i];
            if (param == null) {
                pstmt.setNull(i + 1, Types.NULL);
            } else if (param instanceof String) {
                pstmt.setString(i + 1, (String) param);
            } else if (param instanceof Integer) {
                pstmt.setInt(i + 1, (Integer) param);
            } else if (param instanceof Long) {
                pstmt.setLong(i + 1, (Long) param);
            } else if (param instanceof Double) {
                pstmt.setDouble(i + 1, (Double) param);
            } else if (param instanceof Boolean) {
                pstmt.setInt(i + 1, ((Boolean) param) ? 1 : 0);
            } else if (param instanceof Timestamp) {
                pstmt.setTimestamp(i + 1, (Timestamp) param);
            } else {
                pstmt.setObject(i + 1, param);
            }
        }
    }

    /**
     * Ejecuta una lista de queries en una transacción
     */
    public void executeTransaction(List<String> sqlStatements) throws SQLException {
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);
            try (Statement stmt = conn.createStatement()) {
                for (String sql : sqlStatements) {
                    stmt.execute(sql);
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    /**
     * Cierra todos los recursos y la base de datos
     */
    public void closeAll() {
        // SQLite cierra automáticamente las conexiones
        // Este método puede usarse para limpiezas adicionales si es necesario
    }

    /**
     * Obtiene la ruta completa de la base de datos
     */
    public String getDatabasePath() {
        return DB_PATH;
    }
}

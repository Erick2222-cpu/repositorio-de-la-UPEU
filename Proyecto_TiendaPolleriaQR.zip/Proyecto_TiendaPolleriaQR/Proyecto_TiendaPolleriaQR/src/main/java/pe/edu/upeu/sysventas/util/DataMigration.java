package pe.edu.upeu.sysventas.util;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Clase responsable de migrar datos desde archivos CSV/TXT a la base de datos SQLite.
 * Se ejecuta automáticamente una sola vez al iniciar la aplicación.
 */
public class DataMigration {
    private static final String USUARIOS_CSV = "datos/usuarios.csv";
    private static final String CATEGORIAS_CSV = "datos/categorias.csv";
    private static final String PRODUCTOS_CSV = "datos/productos.csv";
    private static final String VENTAS_CSV = "datos/ventas.csv";
    private static final String INVENTARIO_CSV = "datos/inventario.csv";
    private static final String DATA_DIR = "data";
    
    private DatabaseManager db;
    private int migratedUsers = 0;
    private int migratedCategories = 0;
    private int migratedProducts = 0;
    private int migratedVentas = 0;
    private int migratedClientes = 0;

    public DataMigration() {
        this.db = DatabaseManager.getInstance();
    }

    /**
     * Ejecuta la migración si es necesaria
     * @return true si se ejecutó la migración, false si ya estaba migrada
     */
    public boolean migrateIfNeeded() {
        if (db.isDatabaseMigrated()) {
            System.out.println("✓ Base de datos ya está migrada. Saltando migración.");
            return false;
        }

        System.out.println("\n📊 Iniciando migración de datos a SQLite...\n");
        
        try {
            migrateUsuarios();
            migrateCategorias();
            migrateProductos();
            migrateVentas();
            migrateClientes();
            
            printMigrationSummary();
            System.out.println("✓ Migración completada exitosamente.\n");
            return true;
        } catch (Exception e) {
            System.err.println("✗ Error durante la migración: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Migra usuarios desde datos/usuarios.csv
     */
    private void migrateUsuarios() {
        File file = new File(USUARIOS_CSV);
        if (!file.exists()) {
            System.out.println("ℹ Archivo usuarios.csv no encontrado. Creando usuario admin por defecto.");
            createDefaultAdmin();
            return;
        }

        try {
            List<String> lines = Files.readAllLines(file.toPath());
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                
                String[] parts = line.split(";");
                if (parts.length >= 3) {
                    String username = parts[0].trim();
                    String passwordHash = parts[1].trim();
                    int isAdmin = parts[2].trim().equals("1") ? 1 : 0;

                    // Evitar duplicados
                    if (!usuarioExiste(username)) {
                        String sql = "INSERT INTO usuarios (username, password_hash, is_admin) VALUES (?, ?, ?)";
                        db.executeUpdate(sql, username, passwordHash, isAdmin);
                        migratedUsers++;
                    }
                }
            }
            System.out.println("✓ Usuarios migrados: " + migratedUsers);
        } catch (Exception e) {
            System.err.println("✗ Error migrando usuarios: " + e.getMessage());
        }
    }

    /**
     * Migra categorías desde datos/categorias.csv
     */
    private void migrateCategorias() {
        File file = new File(CATEGORIAS_CSV);
        if (!file.exists()) {
            System.out.println("ℹ Archivo categorias.csv no encontrado.");
            return;
        }

        try {
            List<String> lines = Files.readAllLines(file.toPath());
            Set<String> processedCategorias = new HashSet<>();
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(";", 2);
                if (parts.length >= 2) {
                    String id = parts[0].trim();
                    String nombre = parts[1].trim();
                    // Evitar duplicados
                    if (!processedCategorias.contains(nombre) && !categoriaExiste(id)) {
                        String sql = "INSERT INTO categorias (id, nombre) VALUES (?, ?)";
                        db.executeUpdate(sql, id, nombre);
                        migratedCategories++;
                        processedCategorias.add(nombre);
                    }
                }
            }
            System.out.println("✓ Categorías migradas: " + migratedCategories);
        } catch (Exception e) {
            System.err.println("✗ Error migrando categorías: " + e.getMessage());
        }
    }

    /**
     * Migra productos desde datos/productos.csv
     */
    private void migrateProductos() {
        File file = new File(PRODUCTOS_CSV);
        if (!file.exists()) {
            System.out.println("ℹ Archivo productos.csv no encontrado.");
            return;
        }

        try {
            List<String> lines = Files.readAllLines(file.toPath());
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                
                String[] parts = line.split(";", -1);
                if (parts.length >= 8) {
                    String id = parts[0].trim();
                    String nombre = parts[1].trim();
                    String categoriaId = parts[2].trim();
                    String descripcion = parts[3].trim();
                    double precio = Double.parseDouble(parts[4].trim());
                    String presentacion = parts[5].trim();
                    int stock = Integer.parseInt(parts[6].trim());
                    String imagen = parts[7].trim();

                    // Evitar duplicados
                    if (!productoExiste(id)) {
                        // Si la categoría no existe, usar una categoría genérica o crear una
                        if (!categoriaExiste(categoriaId)) {
                            String sqlCat = "INSERT OR IGNORE INTO categorias (id, nombre) VALUES (?, ?)";
                            db.executeUpdate(sqlCat, categoriaId, categoriaId);
                        }

                        String sql = "INSERT INTO productos (id, nombre, categoria_id, descripcion, presentacion, precio, stock, imagen) " +
                                   "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                        db.executeUpdate(sql, id, nombre, categoriaId, descripcion, presentacion, precio, stock, imagen);
                        migratedProducts++;
                    }
                }
            }
            System.out.println("✓ Productos migrados: " + migratedProducts);
        } catch (Exception e) {
            System.err.println("✗ Error migrando productos: " + e.getMessage());
        }
    }

    /**
     * Migra ventas desde datos/ventas.csv
     */
    private void migrateVentas() {
        File file = new File(VENTAS_CSV);
        if (!file.exists()) {
            System.out.println("ℹ Archivo ventas.csv no encontrado.");
            return;
        }

        try {
            List<String> lines = Files.readAllLines(file.toPath());
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                
                String[] parts = line.split(";", 5);
                if (parts.length >= 5) {
                    String ventaId = parts[0].trim();
                    String username = parts[1].trim();
                    String fechaHoraStr = parts[2].trim();
                    double total = Double.parseDouble(parts[3].trim());
                    String itemsStr = parts[4].trim();

                    // Evitar duplicados
                    if (!ventaExiste(ventaId)) {
                        // Asegurar que el usuario existe
                        if (!usuarioExiste(username)) {
                            // Crear usuario temporal si no existe
                            String sqlUser = "INSERT OR IGNORE INTO usuarios (username, password_hash, is_admin) VALUES (?, ?, ?)";
                            db.executeUpdate(sqlUser, username, "hash_temporal", 0);
                        }

                        // Parsear fechaHora
                        LocalDateTime fechaHora = LocalDateTime.parse(fechaHoraStr);

                        String sql = "INSERT INTO ventas (id, username, fecha_hora, total) VALUES (?, ?, ?, ?)";
                        db.executeUpdate(sql, ventaId, username, fechaHora.toString(), total);

                        // Procesar items
                        if (!itemsStr.isEmpty()) {
                            String[] items = itemsStr.split("::");
                            for (String item : items) {
                                String[] itemParts = item.split("\\|");
                                if (itemParts.length >= 4) {
                                    String productoId = itemParts[0].trim();
                                    String nombreProducto = itemParts[1].trim();
                                    int cantidad = Integer.parseInt(itemParts[2].trim());
                                    double precioUnitario = Double.parseDouble(itemParts[3].trim());

                                    String sqlItem = "INSERT INTO venta_items (venta_id, producto_id, nombre_producto, cantidad, precio_unitario) " +
                                                   "VALUES (?, ?, ?, ?, ?)";
                                    db.executeUpdate(sqlItem, ventaId, productoId, nombreProducto, cantidad, precioUnitario);
                                }
                            }
                        }

                        migratedVentas++;
                    }
                }
            }
            System.out.println("✓ Ventas migradas: " + migratedVentas);
        } catch (Exception e) {
            System.err.println("✗ Error migrando ventas: " + e.getMessage());
        }
    }

    /**
     * Migra datos de clientes desde archivos en data/venta_*.txt
     */
    private void migrateClientes() {
        File dataDir = new File(DATA_DIR);
        if (!dataDir.exists()) {
            return;
        }

        try {
            File[] files = dataDir.listFiles((dir, name) -> name.startsWith("venta_") && name.endsWith(".txt"));
            if (files == null) return;

            for (File file : files) {
                try {
                    String filename = file.getName();
                    String ventaId = filename.replace("venta_", "").replace(".txt", "");

                    // Evitar duplicados
                    if (clienteExiste(ventaId)) continue;

                    List<String> lines = Files.readAllLines(file.toPath());
                    String nombre = null;
                    String dni = null;

                    for (String line : lines) {
                        if (line.startsWith("nombre=")) {
                            nombre = line.substring("nombre=".length()).trim();
                        } else if (line.startsWith("dni=")) {
                            dni = line.substring("dni=".length()).trim();
                        }
                    }

                    if (ventaExiste(ventaId)) {
                        String sql = "INSERT INTO clientes (venta_id, nombre, dni) VALUES (?, ?, ?)";
                        db.executeUpdate(sql, ventaId, nombre, dni);
                        migratedClientes++;
                    }
                } catch (Exception e) {
                    System.err.println("✗ Error procesando cliente " + file.getName() + ": " + e.getMessage());
                }
            }
            System.out.println("✓ Clientes migrados: " + migratedClientes);
        } catch (Exception e) {
            System.err.println("✗ Error migrando clientes: " + e.getMessage());
        }
    }

    /**
     * Crea el usuario administrador por defecto
     */
    private void createDefaultAdmin() {
        try {
            if (!usuarioExiste("nehemias")) {
                String sql = "INSERT INTO usuarios (username, password_hash, is_admin) VALUES (?, ?, ?)";
                db.executeUpdate(sql, "nehemias", "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92", 1);
                migratedUsers = 1;
                System.out.println("✓ Usuario admin por defecto creado");
            }
        } catch (SQLException e) {
            System.err.println("✗ Error creando usuario admin: " + e.getMessage());
        }
    }

    // ===== Métodos de verificación =====

    private boolean usuarioExiste(String username) throws SQLException {
        String sql = "SELECT 1 FROM usuarios WHERE username = ? LIMIT 1";
        try (Connection conn = db.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private boolean categoriaExiste(String id) throws SQLException {
        String sql = "SELECT 1 FROM categorias WHERE id = ? LIMIT 1";
        try (Connection conn = db.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private boolean productoExiste(String id) throws SQLException {
        String sql = "SELECT 1 FROM productos WHERE id = ? LIMIT 1";
        try (Connection conn = db.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private boolean ventaExiste(String id) throws SQLException {
        String sql = "SELECT 1 FROM ventas WHERE id = ? LIMIT 1";
        try (Connection conn = db.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private boolean clienteExiste(String ventaId) throws SQLException {
        String sql = "SELECT 1 FROM clientes WHERE venta_id = ? LIMIT 1";
        try (Connection conn = db.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ventaId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * Imprime un resumen de la migración
     */
    private void printMigrationSummary() {
        System.out.println("========================================");
        System.out.println("📊 RESUMEN DE MIGRACIÓN");
        System.out.println("========================================");
        System.out.println("✓ Usuarios:      " + migratedUsers);
        System.out.println("✓ Categorías:    " + migratedCategories);
        System.out.println("✓ Productos:     " + migratedProducts);
        System.out.println("✓ Ventas:        " + migratedVentas);
        System.out.println("✓ Clientes:      " + migratedClientes);
        System.out.println("========================================");
    }
}

package pe.edu.upeu.sysventas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.servicio.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Panel de Ventas Diarias - Registra y visualiza ventas en tiempo real.
 * Muestra: Total del día, productos más vendidos, historial de transacciones.
 */
@SuppressWarnings("unchecked")
public class PanelVentasDiarias {

    public static Pane crear(ServicioVenta servicioVenta, ServicioProducto servicioProducto) {
        VBox root = new VBox(15);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #f5f5f5;");

        Label titulo = new Label("Ventas del Día - Pollería de QR");
        titulo.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 18px; -fx-font-weight: bold;");

        String labelStyle = "-fx-text-fill: #333333; -fx-font-size: 12px; -fx-font-weight: bold;";
        String cardStyle = "-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px; -fx-padding: 15px;";

        // Obtener observable de ventas del día para sincronización en tiempo real
        VentaDiaObservable observable = VentaDiaObservable.getInstance();

        // ===== SECCIÓN: RESUMEN DEL DÍA =====
        Label lblResumen = new Label("Resumen de Hoy");
        lblResumen.setStyle(labelStyle + " -fx-font-size: 13px;");

        Label lblFecha = new Label("Fecha: " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        lblFecha.setStyle(labelStyle);

        // Tarjetas de KPI - inicializadas en S/ 0.00
        Label lblTotalVentas = new Label("Total de Ventas");
        lblTotalVentas.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label valTotalVentas = new Label("S/ 0.00");
        valTotalVentas.setStyle("-fx-text-fill: #000000; -fx-font-size: 18px; -fx-font-weight: bold;");
        
        Label lblNumVentas = new Label("Número de Ventas");
        lblNumVentas.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label valNumVentas = new Label("0");
        valNumVentas.setStyle("-fx-text-fill: #000000; -fx-font-size: 18px; -fx-font-weight: bold;");
        
        Label lblTicketPromedio = new Label("Ticket Promedio");
        lblTicketPromedio.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label valTicketPromedio = new Label("S/ 0.00");
        valTicketPromedio.setStyle("-fx-text-fill: #000000; -fx-font-size: 18px; -fx-font-weight: bold;");
        
        Label lblProductoTop = new Label("Producto Top");
        lblProductoTop.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");
        Label valProductoTop = new Label("---");
        valProductoTop.setStyle("-fx-text-fill: #000000; -fx-font-size: 18px; -fx-font-weight: bold;");

        VBox cardTotalVentas = new VBox(5, lblTotalVentas, valTotalVentas);
        cardTotalVentas.setStyle("-fx-background-color: #4CAF50; -fx-border-radius: 4px; -fx-padding: 12px;");
        cardTotalVentas.setAlignment(Pos.CENTER);
        cardTotalVentas.setPrefWidth(150);
        
        VBox cardNumVentas = new VBox(5, lblNumVentas, valNumVentas);
        cardNumVentas.setStyle("-fx-background-color: #2196F3; -fx-border-radius: 4px; -fx-padding: 12px;");
        cardNumVentas.setAlignment(Pos.CENTER);
        cardNumVentas.setPrefWidth(150);
        
        VBox cardTicketPromedio = new VBox(5, lblTicketPromedio, valTicketPromedio);
        cardTicketPromedio.setStyle("-fx-background-color: #FF9800; -fx-border-radius: 4px; -fx-padding: 12px;");
        cardTicketPromedio.setAlignment(Pos.CENTER);
        cardTicketPromedio.setPrefWidth(150);
        
        VBox cardProductoTop = new VBox(5, lblProductoTop, valProductoTop);
        cardProductoTop.setStyle("-fx-background-color: #9C27B0; -fx-border-radius: 4px; -fx-padding: 12px;");
        cardProductoTop.setAlignment(Pos.CENTER);
        cardProductoTop.setPrefWidth(150);

        // LISTENERS EN TIEMPO REAL para sincronizar datos
        observable.totalIngresosProperty().addListener((obs, oldVal, newVal) -> {
            valTotalVentas.setText(String.format("S/ %.2f", newVal.doubleValue()));
        });
        
        observable.totalVentasProperty().addListener((obs, oldVal, newVal) -> {
            valNumVentas.setText(String.valueOf(newVal.intValue()));
        });
        
        observable.ingresoPromedioProperty().addListener((obs, oldVal, newVal) -> {
            valTicketPromedio.setText(String.format("S/ %.2f", newVal.doubleValue()));
        });

        HBox resumenCards = new HBox(15, cardTotalVentas, cardNumVentas, cardTicketPromedio, cardProductoTop);
        resumenCards.setPadding(new Insets(10));
        resumenCards.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        // ===== SECCIÓN: TABLA DE VENTAS DEL DÍA =====
        Label lblTablaVentas = new Label("Transacciones de Hoy");
        lblTablaVentas.setStyle(labelStyle + " -fx-font-size: 13px;");

        TableView<VentaDiaObservable.VentaDelDia> tablaVentas = new TableView<>();
        tablaVentas.setPrefHeight(300);
        tablaVentas.setItems(observable.getVentasDelDia());

        TableColumn<VentaDiaObservable.VentaDelDia, java.time.LocalTime> colHora = new TableColumn<>("Hora");
        colHora.setCellValueFactory(new PropertyValueFactory<>("hora"));

        TableColumn<VentaDiaObservable.VentaDelDia, Integer> colCantidad = new TableColumn<>("Cantidad");
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        TableColumn<VentaDiaObservable.VentaDelDia, Double> colMonto = new TableColumn<>("Monto");
        colMonto.setCellValueFactory(cellData -> new javafx.beans.property.SimpleObjectProperty<>(cellData.getValue().getMonto()));

        TableColumn<VentaDiaObservable.VentaDelDia, String> colDetalles = new TableColumn<>("Detalles");
        colDetalles.setCellValueFactory(new PropertyValueFactory<>("detalles"));
        colDetalles.setPrefWidth(200);

        tablaVentas.getColumns().addAll(colHora, colCantidad, colMonto, colDetalles);

        HBox botones = new HBox(10);
        botones.setPadding(new Insets(10));
        botones.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        // ===== ENSAMBLAJE FINAL =====
        ScrollPane scroll = new ScrollPane(new VBox(15,
            titulo,
            lblFecha,
            new Separator(),
            lblResumen,
            resumenCards,
            new Separator(),
            lblTablaVentas,
            tablaVentas,
            new Separator(),
            botones
        ));
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #f5f5f5;");

        root.getChildren().add(scroll);
        return root;
    }
}

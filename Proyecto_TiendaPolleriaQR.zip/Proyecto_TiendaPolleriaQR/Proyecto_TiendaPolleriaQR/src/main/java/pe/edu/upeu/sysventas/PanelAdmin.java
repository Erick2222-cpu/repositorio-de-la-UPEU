package pe.edu.upeu.sysventas;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.servicio.*;
import pe.edu.upeu.sysventas.modelo.Producto;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

public class PanelAdmin {

    public static Pane crear(ServicioProducto servicioProducto, ServicioCategoria servicioCategoria, ServicioVenta servicioVenta, pe.edu.upeu.sysventas.servicio.ServicioUsuario servicioUsuario, Runnable onProductAdded) {
        VBox root = new VBox(15);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #f5f5f5;");

        Label titulo = new Label("Panel de Administración - Pollería de QR");
        titulo.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 18px; -fx-font-weight: bold;");

        // Estilos comunes para campos de entrada
        String textFieldStyle = "-fx-padding: 8px; -fx-border-radius: 4px; -fx-border-color: #cccccc; -fx-font-size: 12px; -fx-text-fill: #000000;";
        String labelStyle = "-fx-text-fill: #333333; -fx-font-size: 12px; -fx-font-weight: bold;";
        String buttonStyle = "-fx-padding: 8px 16px; -fx-font-size: 12px; -fx-font-weight: bold; -fx-background-color: #0066cc; -fx-text-fill: white; -fx-border-radius: 4px; -fx-cursor: hand;";
        String comboStyle = "-fx-padding: 8px; -fx-border-radius: 4px; -fx-border-color: #cccccc; -fx-font-size: 12px; -fx-text-fill: #000000; -fx-background-color: #ffffff;";

        // Area categorías
        Label lblCategorias = new Label("Gestionar Categorías");
        lblCategorias.setStyle(labelStyle + " -fx-font-size: 13px;");
        TextField txtCategoria = new TextField();
        txtCategoria.setPromptText("Nombre categoría");
        txtCategoria.setStyle(textFieldStyle);
        txtCategoria.setPrefWidth(250);
        Button btnAddCat = new Button("Agregar categoría");
        btnAddCat.setStyle(buttonStyle);
        btnAddCat.setOnAction(e -> {
            servicioCategoria.crear(txtCategoria.getText().trim());
            txtCategoria.clear();
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Categoría agregada.", ButtonType.OK);
            a.showAndWait();
        });
        HBox categoriasBox = new HBox(10, txtCategoria, btnAddCat);
        categoriasBox.setPadding(new Insets(10));
        categoriasBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");
        categoriasBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        // Area productos - formulario y tabla
        TextField idField = new TextField(); 
        idField.setPromptText("ID"); 
        idField.setDisable(true);
        idField.setStyle(textFieldStyle);
        idField.setPrefWidth(120);
        
        TextField nom = new TextField(); 
        nom.setPromptText("Nombre del producto");
        nom.setStyle(textFieldStyle);
        nom.setPrefWidth(200);
        
        ComboBox<String> catCombo = new ComboBox<>();
        catCombo.setItems(FXCollections.observableArrayList("Comida", "Bebida"));
        catCombo.setPromptText("Selecciona categoría");
        catCombo.setStyle(comboStyle);
        catCombo.setPrefWidth(150);
        catCombo.setButtonCell(new javafx.scene.control.ListCell<String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText("Selecciona categoría");
                    setStyle("-fx-text-fill: #000000; -fx-font-size: 12px;");
                } else {
                    setText(item);
                    setStyle("-fx-text-fill: #000000; -fx-font-size: 12px;");
                }
            }
        });
        
        TextField descripcion = new TextField(); 
        descripcion.setPromptText("Descripción (ej: con papas, sin picante)");
        descripcion.setStyle(textFieldStyle);
        descripcion.setPrefWidth(220);
        
        TextField presentacion = new TextField(); 
        presentacion.setPromptText("Presentación (ej: 500ml, 1L, porción)");
        presentacion.setStyle(textFieldStyle);
        presentacion.setPrefWidth(180);
        presentacion.setVisible(false);
        
        Label lblPresentacion = new Label("Presentación:"); 
        lblPresentacion.setStyle(labelStyle); 
        lblPresentacion.setVisible(false);
        
        TextField precio = new TextField(); 
        precio.setPromptText("Precio");
        precio.setStyle(textFieldStyle);
        precio.setPrefWidth(100);
        
        TextField stock = new TextField(); 
        stock.setPromptText("Stock");
        stock.setStyle(textFieldStyle);
        stock.setPrefWidth(100);
        
        Button btnAddProd = new Button("Agregar/Guardar producto");
        btnAddProd.setStyle(buttonStyle);
        btnAddProd.setPrefWidth(180);

        // Cambiar visibilidad de presentación según categoría seleccionada
        catCombo.setOnAction(e -> {
            String selected = catCombo.getValue();
            if ("Bebida".equals(selected)) {
                presentacion.setVisible(true);
                lblPresentacion.setVisible(true);
            } else {
                presentacion.setVisible(false);
                lblPresentacion.setVisible(false);
            }
        });

        TableView<Producto> tv = new TableView<>();
        ObservableList<Producto> items = FXCollections.observableArrayList(servicioProducto.todos());
        tv.setItems(items);
        TableColumn<Producto, String> cId = new TableColumn<>("ID"); cId.setCellValueFactory(new PropertyValueFactory<>("id")); cId.setPrefWidth(80);
        TableColumn<Producto, String> cNom = new TableColumn<>("Nombre"); cNom.setCellValueFactory(new PropertyValueFactory<>("nombre")); cNom.setPrefWidth(130);
        TableColumn<Producto, String> cCat = new TableColumn<>("Categoría"); cCat.setCellValueFactory(new PropertyValueFactory<>("categoria")); cCat.setPrefWidth(90);
        TableColumn<Producto, String> cDesc = new TableColumn<>("Descripción"); cDesc.setCellValueFactory(new PropertyValueFactory<>("descripcion")); cDesc.setPrefWidth(120);
        TableColumn<Producto, String> cPres = new TableColumn<>("Presentación"); cPres.setCellValueFactory(new PropertyValueFactory<>("presentacion")); cPres.setPrefWidth(110);
        TableColumn<Producto, Integer> cStock = new TableColumn<>("Stock"); cStock.setCellValueFactory(new PropertyValueFactory<>("stock")); cStock.setPrefWidth(70);
        TableColumn<Producto, Double> cPrecio = new TableColumn<>("Precio"); cPrecio.setCellValueFactory(new PropertyValueFactory<>("precio")); cPrecio.setPrefWidth(80);
        tv.setPrefHeight(240);
        tv.getColumns().add(cId);
        tv.getColumns().add(cNom);
        tv.getColumns().add(cCat);
        tv.getColumns().add(cDesc);
        tv.getColumns().add(cPres);
        tv.getColumns().add(cStock);
        tv.getColumns().add(cPrecio);

        // resaltar filas con stock bajo
        tv.setRowFactory(tvrow -> new TableRow<Producto>(){
            @Override
            protected void updateItem(Producto item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setStyle("");
                } else {
                    if (item.getStock() <= 5) {
                        setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, rgba(80,0,120,0.2), rgba(30,0,60,0.05));");
                    } else setStyle("");
                }
            }
        });

        // seleccionar producto en la tabla para editar
        tv.getSelectionModel().selectedItemProperty().addListener((obs, ov, nv) -> {
            if (nv != null) {
                idField.setText(nv.getId());
                nom.setText(nv.getNombre());
                catCombo.setValue(nv.getCategoria());
                descripcion.setText(nv.getDescripcion() == null ? "" : nv.getDescripcion());
                presentacion.setText(nv.getPresentacion() == null ? "" : nv.getPresentacion());
                precio.setText(String.valueOf(nv.getPrecio()));
                stock.setText(String.valueOf(nv.getStock()));
                
                // Actualizar visibilidad de presentación
                if ("Bebida".equals(nv.getCategoria())) {
                    presentacion.setVisible(true);
                    lblPresentacion.setVisible(true);
                } else {
                    presentacion.setVisible(false);
                    lblPresentacion.setVisible(false);
                }
            }
        });

        Button btnDelete = new Button("Eliminar seleccionado");
        btnDelete.setStyle(buttonStyle);
        btnDelete.setPrefWidth(180);
        btnDelete.setOnAction(e -> {
            Producto sel = tv.getSelectionModel().getSelectedItem();
            if (sel == null) { Alert a = new Alert(Alert.AlertType.WARNING, "Seleccione un producto.", ButtonType.OK); a.showAndWait(); return; }
            servicioProducto.eliminar(sel.getId());
            items.setAll(servicioProducto.todos());
            if (onProductAdded != null) try { onProductAdded.run(); } catch (Exception ex){ex.printStackTrace();}
        });

        btnAddProd.setOnAction(e -> {
            try {
                if (nom.getText().trim().isEmpty()) { Alert a = new Alert(Alert.AlertType.WARNING, "Nombre requerido.", ButtonType.OK); a.showAndWait(); return; }
                if (catCombo.getValue() == null) { Alert a = new Alert(Alert.AlertType.WARNING, "Categoría requerida.", ButtonType.OK); a.showAndWait(); return; }
                
                String categoria = catCombo.getValue();
                String desc = descripcion.getText().trim();
                String pres = presentacion.getText().trim();
                
                Producto p = new Producto(idField.getText().isEmpty() ? null : idField.getText(), nom.getText().trim(), categoria, Double.parseDouble(precio.getText()), Integer.parseInt(stock.getText()), desc, pres, "");
                if (p.getId() == null || p.getId().isEmpty()) servicioProducto.crear(p); else servicioProducto.actualizar(p);
                idField.clear(); nom.clear(); catCombo.setValue(null); descripcion.clear(); presentacion.clear(); precio.clear(); stock.clear();
                presentacion.setVisible(false); lblPresentacion.setVisible(false);
                items.setAll(servicioProducto.todos());
                Alert a = new Alert(Alert.AlertType.INFORMATION, "Producto guardado.", ButtonType.OK); a.showAndWait();
                if (onProductAdded != null) try { onProductAdded.run(); } catch (Exception ex2) { ex2.printStackTrace(); }
            } catch (NumberFormatException nfe) {
                Alert a = new Alert(Alert.AlertType.ERROR, "Precio y Stock deben ser números válidos.", ButtonType.OK);
                a.showAndWait();
            } catch (Exception ex) {
                Alert a = new Alert(Alert.AlertType.ERROR, "Error al guardar producto: " + ex.getMessage(), ButtonType.OK);
                a.showAndWait();
            }
        });

        // Contenedor para el formulario de agregar producto - mejor organizado
        Label lblAgregarProd = new Label("Agregar/Editar Producto");
        lblAgregarProd.setStyle(labelStyle + " -fx-font-size: 13px;");
        
        VBox formularioBox = new VBox(10);
        formularioBox.setPadding(new Insets(12));
        formularioBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");
        
        HBox fila1 = new HBox(10, new VBox(2, new Label("Nombre*:"), nom), new VBox(2, new Label("Categoría*:"), catCombo));
        fila1.setPrefHeight(50);
        
        HBox fila2 = new HBox(10, new VBox(2, new Label("Descripción:"), descripcion), new VBox(2, lblPresentacion, presentacion));
        fila2.setPrefHeight(50);
        
        HBox fila3 = new HBox(10, new VBox(2, new Label("Precio*:"), precio), new VBox(2, new Label("Stock*:"), stock));
        fila3.setPrefHeight(50);
        
        VBox.setVgrow(fila1, javafx.scene.layout.Priority.ALWAYS);
        VBox.setVgrow(fila2, javafx.scene.layout.Priority.ALWAYS);
        VBox.setVgrow(fila3, javafx.scene.layout.Priority.ALWAYS);
        
        formularioBox.getChildren().addAll(fila1, fila2, fila3);
        
        HBox botonesBox = new HBox(10, btnAddProd, btnDelete);
        botonesBox.setPadding(new Insets(0, 12, 12, 12));
        botonesBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        root.getChildren().addAll(
                titulo,
                new Separator(),
                lblCategorias,
                categoriasBox,
                new Separator(),
                lblAgregarProd,
                formularioBox,
                botonesBox,
                new Label("Inventario Actual"),
                tv
        );

        try {
            var cssUrl = PanelAdmin.class.getResource("/estilo.css");
            if (cssUrl != null) root.getStylesheets().add(cssUrl.toExternalForm());
            else System.out.println("Advertencia: No se encontró /estilo.css en el classpath (PanelAdmin)");
        } catch (Exception ex) {
            System.out.println("Error cargando stylesheet en PanelAdmin: " + ex.getMessage());
        }
        return root;
    }
}

package pe.edu.upeu.sysventas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.servicio.ServicioVenta;
import pe.edu.upeu.sysventas.servicio.ServicioProducto;
import pe.edu.upeu.sysventas.servicio.ServicioCategoria;

/**
 * Dashboard Principal - Integración de 5 paneles administrativos para pollería.
 * Tabs: Productos | Ventas Diarias | Estadísticas | Financiero | Reportes
 */
public class DashboardPrincipal {

    public static BorderPane crear(ServicioVenta servicioVenta, ServicioProducto servicioProducto, 
                                  ServicioCategoria servicioCategoria) {
        BorderPane root = new BorderPane();

        // ===== HEADER =====
        HBox header = createHeader();
        root.setTop(header);

        // ===== TABS CON LOS 5 PANELES =====
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.setStyle("-fx-font-size: 12px;");

        // Tab 1: Productos y Categorías
        Tab tabProductos = new Tab("📦 Productos y Categorías", 
            PanelProductosYCategorias.crear(servicioProducto, servicioCategoria, () -> {}));
        tabProductos.setStyle("-fx-font-size: 12px;");

        // Tab 2: Ventas Diarias
        Tab tabVentas = new Tab("💰 Ventas Diarias", 
            PanelVentasDiarias.crear(servicioVenta, servicioProducto));
        tabVentas.setStyle("-fx-font-size: 12px;");

        // Tab 3: Estadísticas
        Tab tabEstadisticas = new Tab("📊 Estadísticas", 
            PanelEstadisticas.crear(servicioVenta));
        tabEstadisticas.setStyle("-fx-font-size: 12px;");

        // Tab 4: Financiero
        Tab tabFinanciero = new Tab("💵 Financiero", 
            PanelFinanciero.crear(servicioVenta));
        tabFinanciero.setStyle("-fx-font-size: 12px;");

        // Tab 5: Reportes e Historial
        Tab tabReportes = new Tab("📄 Reportes e Historial", 
            PanelReportesYHistorial.crear());
        tabReportes.setStyle("-fx-font-size: 12px;");

        tabPane.getTabs().addAll(tabProductos, tabVentas, tabEstadisticas, tabFinanciero, tabReportes);
        root.setCenter(tabPane);

        // ===== FOOTER =====
        HBox footer = createFooter();
        root.setBottom(footer);

        return root;
    }

    private static HBox createHeader() {
        HBox header = new HBox(15);
        header.setPadding(new Insets(12, 15, 12, 15));
        header.setStyle("-fx-background-color: #d4a574; -fx-border-color: #c19660; -fx-border-width: 0 0 2 0;");
        header.setAlignment(Pos.CENTER_LEFT);

        Label logo = new Label("🍗 POLLERÍA DE QR 🍗");
        logo.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");

        Separator sep = new Separator();
        sep.setOrientation(javafx.geometry.Orientation.VERTICAL);

        Label titulo = new Label("Sistema de Administración");
        titulo.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label usuario = new Label("👤 Administrador");
        usuario.setStyle("-fx-text-fill: white; -fx-font-size: 11px;");

        Button btnSalir = new Button("Salir");
        btnSalir.setStyle("-fx-padding: 6px 12px; -fx-background-color: #c19660; -fx-text-fill: white; -fx-font-weight: bold;");
        btnSalir.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmar Salida");
            alert.setHeaderText(null);
            alert.setContentText("¿Desea salir del sistema?");
            if (alert.showAndWait().filter(r -> r == ButtonType.OK).isPresent()) {
                System.exit(0);
            }
        });

        header.getChildren().addAll(logo, sep, titulo, spacer, usuario, btnSalir);
        return header;
    }

    private static HBox createFooter() {
        HBox footer = new HBox(15);
        footer.setPadding(new Insets(8, 15, 8, 15));
        footer.setStyle("-fx-background-color: #f5f5f5; -fx-border-color: #e0e0e0; -fx-border-width: 1 0 0 0;");
        footer.setAlignment(Pos.CENTER_LEFT);

        Label version = new Label("v1.0.0 - Pollería de QR");
        version.setStyle("-fx-text-fill: #666666; -fx-font-size: 10px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label timestamp = new Label("Última actualización: " + java.time.LocalDateTime.now()
            .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
        timestamp.setStyle("-fx-text-fill: #666666; -fx-font-size: 10px;");

        footer.getChildren().addAll(version, spacer, timestamp);
        return footer;
    }
}

package pe.edu.upeu.sysventas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Panel Financiero - Análisis de ingresos, gastos y ganancias.
 * Muestra: Balance diario/mensual, ingresos por producto, gastos operacionales, rentabilidad.
 */
@SuppressWarnings("unchecked")
public class PanelFinanciero {

    public static Pane crear(pe.edu.upeu.sysventas.servicio.ServicioVenta servicioVenta) {
        VBox root = new VBox(15);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #f5f5f5;");

        Label titulo = new Label("Panel Financiero - Pollería de QR");
        titulo.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 18px; -fx-font-weight: bold;");

        String labelStyle = "-fx-text-fill: #333333; -fx-font-size: 12px; -fx-font-weight: bold;";

        // ===== SECCIÓN: RESUMEN FINANCIERO (HOJA DE BALANCE) =====
        Label lblResumen = new Label("Resumen Financiero del Mes Actual");
        lblResumen.setStyle(labelStyle + " -fx-font-size: 13px;");

        HBox resumenBox = new HBox(20);
        resumenBox.setPadding(new Insets(15));
        resumenBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        // Columna: Ingresos
        double ingresosTotal = servicioVenta != null ? servicioVenta.gananciasSemanales() * 1.5 : 15450.0;
        double otrosIngresos = 250.0;
        
        VBox colIngresos = createFinanceColumn("INGRESOS",
            new String[]{"Ventas Totales", "Otros Ingresos"},
            new String[]{"S/ " + String.format("%.2f", ingresosTotal), "S/ " + String.format("%.2f", otrosIngresos)},
            "#4CAF50"
        );

        // Columna: Gastos
        double costoProductos = ingresosTotal * 0.40;
        double costosServicios = 800.0;
        double sueldos = 4000.0;
        double otrosGastos = 350.0;
        double gastosTotal = costoProductos + costosServicios + sueldos + otrosGastos;
        
        VBox colGastos = createFinanceColumn("GASTOS",
            new String[]{"Costo Productos", "Servicios (Luz, Agua)", "Sueldos Empleados", "Otros Gastos"},
            new String[]{"S/ " + String.format("%.2f", costoProductos), "S/ " + String.format("%.2f", costosServicios), 
                         "S/ " + String.format("%.2f", sueldos), "S/ " + String.format("%.2f", otrosGastos)},
            "#FF6B6B"
        );

        // Columna: Ganancias
        double gananciaTotal = (ingresosTotal + otrosIngresos) - gastosTotal;
        double margenUtilidad = ((gananciaTotal) / (ingresosTotal + otrosIngresos)) * 100;
        
        VBox colGanancias = createFinanceColumn("GANANCIAS",
            new String[]{"Ganancia Neta", "Margen de Utilidad"},
            new String[]{"S/ " + String.format("%.2f", gananciaTotal), String.format("%.1f%%", margenUtilidad)},
            "#4CAF50"
        );

        Separator sep1 = new Separator();
        sep1.setOrientation(javafx.geometry.Orientation.VERTICAL);
        Separator sep2 = new Separator();
        sep2.setOrientation(javafx.geometry.Orientation.VERTICAL);

        resumenBox.getChildren().addAll(colIngresos, sep1, colGastos, sep2, colGanancias);

        // ===== SECCIÓN: KPI FINANCIEROS =====
        Label lblKPI = new Label("Indicadores Financieros");
        lblKPI.setStyle(labelStyle + " -fx-font-size: 13px;");

        HBox kpiFinancier = new HBox(15);
        kpiFinancier.setPadding(new Insets(10));
        kpiFinancier.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        double margenBruto = (costoProductos / ingresosTotal) * 100;
        double roi = (gananciaTotal / (sueldos + costosServicios)) * 100;
        double ingresoPromDia = ingresosTotal / 7;
        double costoPromDia = gastosTotal / 7;
        
        VBox kpiMargen = createKPICard("Margen Bruto", String.format("%.1f%%", margenBruto), "#FF9800");
        VBox kpiROI = createKPICard("ROI Mensual", String.format("%.1f%%", roi), "#9C27B0");
        VBox kpiIngresoProm = createKPICard("Ingreso Promedio/Día", "S/ " + String.format("%.2f", ingresoPromDia), "#2196F3");
        VBox kpiCostoProm = createKPICard("Costo Promedio/Día", "S/ " + String.format("%.2f", costoPromDia), "#f44336");

        kpiFinancier.getChildren().addAll(kpiMargen, kpiROI, kpiIngresoProm, kpiCostoProm);

        // ===== SECCIÓN: DESGLOSE DE INGRESOS POR CATEGORÍA =====
        Label lblIngresosPorCategoria = new Label("Ingresos por Categoría de Producto");
        lblIngresosPorCategoria.setStyle(labelStyle + " -fx-font-size: 13px;");

        TableView<IngresoItem> tablaIngresos = new TableView<>();
        tablaIngresos.setPrefHeight(200);

        TableColumn<IngresoItem, String> colCategoria = new TableColumn<>("Categoría");
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        colCategoria.setPrefWidth(150);

        TableColumn<IngresoItem, Integer> colUnidades = new TableColumn<>("Unidades Vendidas");
        colUnidades.setCellValueFactory(new PropertyValueFactory<>("unidades"));

        TableColumn<IngresoItem, Double> colIngreso = new TableColumn<>("Ingreso Total");
        colIngreso.setCellValueFactory(new PropertyValueFactory<>("ingreso"));

        TableColumn<IngresoItem, Double> colCosto = new TableColumn<>("Costo Total");
        colCosto.setCellValueFactory(new PropertyValueFactory<>("costo"));

        TableColumn<IngresoItem, Double> colGanancia = new TableColumn<>("Ganancia");
        colGanancia.setCellValueFactory(new PropertyValueFactory<>("ganancia"));

        TableColumn<IngresoItem, String> colMargen = new TableColumn<>("Margen %");
        colMargen.setCellValueFactory(new PropertyValueFactory<>("margen"));

        tablaIngresos.getColumns().addAll(colCategoria, colUnidades, colIngreso, colCosto, colGanancia, colMargen);

        ObservableList<IngresoItem> datosIngresos = FXCollections.observableArrayList(
            new IngresoItem("Pollo a la Brasa", 150, 7500.00, 3000.00, 4500.00, "60%"),
            new IngresoItem("Menús", 85, 4080.00, 1700.00, 2380.00, "58%"),
            new IngresoItem("Bebidas Gaseosas", 120, 1440.00, 720.00, 720.00, "50%"),
            new IngresoItem("Refrescos/Jugos", 95, 950.00, 475.00, 475.00, "50%"),
            new IngresoItem("Chicha Morada", 60, 600.00, 180.00, 420.00, "70%"),
            new IngresoItem("Acompañamientos", 110, 880.00, 440.00, 440.00, "50%"),
            new IngresoItem("Postres", 45, 450.00, 200.00, 250.00, "56%")
        );
        tablaIngresos.setItems(datosIngresos);

        // ===== SECCIÓN: GASTOS OPERACIONALES =====
        Label lblGastos = new Label("Gastos Operacionales del Mes");
        lblGastos.setStyle(labelStyle + " -fx-font-size: 13px;");

        TableView<GastoItem> tablaGastos = new TableView<>();
        tablaGastos.setPrefHeight(200);

        TableColumn<GastoItem, String> colGastoDesc = new TableColumn<>("Concepto de Gasto");
        colGastoDesc.setCellValueFactory(new PropertyValueFactory<>("concepto"));
        colGastoDesc.setPrefWidth(200);

        TableColumn<GastoItem, Double> colGastoMonto = new TableColumn<>("Monto");
        colGastoMonto.setCellValueFactory(new PropertyValueFactory<>("monto"));

        TableColumn<GastoItem, String> colGastoPorcentaje = new TableColumn<>("% de Ingresos");
        colGastoPorcentaje.setCellValueFactory(new PropertyValueFactory<>("porcentajeIngresos"));

        TableColumn<GastoItem, String> colGastoEstado = new TableColumn<>("Estado");
        colGastoEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));

        tablaGastos.getColumns().addAll(colGastoDesc, colGastoMonto, colGastoPorcentaje, colGastoEstado);

        ObservableList<GastoItem> datosGastos = FXCollections.observableArrayList(
            new GastoItem("Costo Materia Prima", 6200.00, "40.1%", "Normal"),
            new GastoItem("Sueldos Empleados", 4000.00, "25.9%", "Normal"),
            new GastoItem("Servicios (Luz, Agua)", 800.00, "5.2%", "Normal"),
            new GastoItem("Alquiler Local", 1500.00, "9.7%", "Normal"),
            new GastoItem("Mantenimiento Equipos", 300.00, "1.9%", "Bajo"),
            new GastoItem("Publicidad", 200.00, "1.3%", "Bajo"),
            new GastoItem("Otros Gastos", 350.00, "2.3%", "Normal")
        );
        tablaGastos.setItems(datosGastos);

        // ===== SECCIÓN: INDICADOR GRÁFICO DE BALANCE =====
        Label lblBalance = new Label("Balance Visual Ingresos vs Gastos");
        lblBalance.setStyle(labelStyle + " -fx-font-size: 13px;");

        HBox balanceVisual = new HBox(30);
        balanceVisual.setPadding(new Insets(15));
        balanceVisual.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");
        balanceVisual.setAlignment(Pos.CENTER_LEFT);

        // Ingresos
        VBox ingresoVisual = new VBox(8);
        Label lblIngTotal = new Label("Ingresos Totales");
        lblIngTotal.setStyle("-fx-font-size: 12px; -fx-font-weight: bold;");
        ProgressBar barIngresos = new ProgressBar(1.0);
        barIngresos.setPrefWidth(200);
        barIngresos.setStyle("-fx-accent: #4CAF50;");
        Label lblIngValor = new Label("S/ 15,700.00");
        lblIngValor.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #4CAF50;");
        ingresoVisual.getChildren().addAll(lblIngTotal, barIngresos, lblIngValor);

        // Gastos
        VBox gastoVisual = new VBox(8);
        Label lblGastTotal = new Label("Gastos Totales");
        lblGastTotal.setStyle("-fx-font-size: 12px; -fx-font-weight: bold;");
        ProgressBar barGastos = new ProgressBar(0.65);
        barGastos.setPrefWidth(200);
        barGastos.setStyle("-fx-accent: #FF6B6B;");
        Label lblGastValor = new Label("S/ 10,225.00");
        lblGastValor.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #FF6B6B;");
        gastoVisual.getChildren().addAll(lblGastTotal, barGastos, lblGastValor);

        // Ganancia
        VBox gananciaVisual = new VBox(8);
        Label lblGanTotal = new Label("Ganancia Neta");
        lblGanTotal.setStyle("-fx-font-size: 12px; -fx-font-weight: bold;");
        ProgressBar barGanancia = new ProgressBar(0.35);
        barGanancia.setPrefWidth(200);
        barGanancia.setStyle("-fx-accent: #4CAF50;");
        Label lblGanValor = new Label("S/ 5,475.00");
        lblGanValor.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #4CAF50;");
        gananciaVisual.getChildren().addAll(lblGanTotal, barGanancia, lblGanValor);

        balanceVisual.getChildren().addAll(ingresoVisual, gastoVisual, gananciaVisual);

        // ===== BOTONES DE CONTROL =====
        Button btnExportarFinanciero = new Button("Exportar Estado Financiero");
        btnExportarFinanciero.setStyle("-fx-padding: 8px 16px; -fx-background-color: #4CAF50; -fx-text-fill: white;");
        btnExportarFinanciero.setOnAction(e -> showAlert("Éxito", "Estado financiero exportado como PDF."));

        Button btnRefrescar = new Button("Refrescar Datos");
        btnRefrescar.setStyle("-fx-padding: 8px 16px; -fx-background-color: #2196F3; -fx-text-fill: white;");
        btnRefrescar.setOnAction(e -> showAlert("Actualizado", "Datos financieros actualizados."));

        HBox botones = new HBox(10, btnExportarFinanciero, btnRefrescar);
        botones.setPadding(new Insets(10));
        botones.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e0e0e0; -fx-border-radius: 4px;");

        // ===== ENSAMBLAJE FINAL =====
        ScrollPane scroll = new ScrollPane(new VBox(15,
            titulo,
            new Separator(),
            lblResumen,
            resumenBox,
            new Separator(),
            lblKPI,
            kpiFinancier,
            new Separator(),
            lblIngresosPorCategoria,
            tablaIngresos,
            new Separator(),
            lblGastos,
            tablaGastos,
            new Separator(),
            lblBalance,
            balanceVisual,
            new Separator(),
            botones
        ));
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #f5f5f5;");

        root.getChildren().add(scroll);
        return root;
    }

    private static VBox createFinanceColumn(String titulo, String[] conceptos, String[] valores, String color) {
        VBox col = new VBox(10);
        col.setPrefWidth(200);
        col.setStyle("-fx-background-color: " + color + "; -fx-border-radius: 4px; -fx-padding: 10px;");

        Label lblTitulo = new Label(titulo);
        lblTitulo.setStyle("-fx-text-fill: #000000; -fx-font-size: 12px; -fx-font-weight: bold;");

        col.getChildren().add(lblTitulo);

        for (int i = 0; i < conceptos.length; i++) {
            HBox fila = new HBox(10);
            fila.setAlignment(Pos.CENTER_LEFT);

            Label lblConcepto = new Label(conceptos[i]);
            lblConcepto.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px;");

            Label lblValor = new Label(valores[i]);
            lblValor.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px; -fx-font-weight: bold;");

            fila.getChildren().addAll(lblConcepto, lblValor);
            col.getChildren().add(fila);
        }

        return col;
    }

    private static VBox createKPICard(String titulo, String valor, String color) {
        VBox card = new VBox(8);
        card.setPadding(new Insets(12));
        card.setStyle("-fx-background-color: " + color + "; -fx-border-radius: 4px;");
        card.setAlignment(Pos.CENTER);

        Label lblTitulo = new Label(titulo);
        lblTitulo.setStyle("-fx-text-fill: #000000; -fx-font-size: 11px;");

        Label lblValor = new Label(valor);
        lblValor.setStyle("-fx-text-fill: #000000; -fx-font-size: 16px; -fx-font-weight: bold;");

        card.getChildren().addAll(lblTitulo, lblValor);
        return card;
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // ===== CLASES INTERNAS =====
    public static class IngresoItem {
        private String categoria;
        private int unidades;
        private double ingreso;
        private double costo;
        private double ganancia;
        private String margen;

        public IngresoItem(String categoria, int unidades, double ingreso, double costo, double ganancia, String margen) {
            this.categoria = categoria;
            this.unidades = unidades;
            this.ingreso = ingreso;
            this.costo = costo;
            this.ganancia = ganancia;
            this.margen = margen;
        }

        public String getCategoria() { return categoria; }
        public int getUnidades() { return unidades; }
        public double getIngreso() { return ingreso; }
        public double getCosto() { return costo; }
        public double getGanancia() { return ganancia; }
        public String getMargen() { return margen; }
    }

    public static class GastoItem {
        private String concepto;
        private double monto;
        private String porcentajeIngresos;
        private String estado;

        public GastoItem(String concepto, double monto, String porcentajeIngresos, String estado) {
            this.concepto = concepto;
            this.monto = monto;
            this.porcentajeIngresos = porcentajeIngresos;
            this.estado = estado;
        }

        public String getConcepto() { return concepto; }
        public double getMonto() { return monto; }
        public String getPorcentajeIngresos() { return porcentajeIngresos; }
        public String getEstado() { return estado; }
    }
}

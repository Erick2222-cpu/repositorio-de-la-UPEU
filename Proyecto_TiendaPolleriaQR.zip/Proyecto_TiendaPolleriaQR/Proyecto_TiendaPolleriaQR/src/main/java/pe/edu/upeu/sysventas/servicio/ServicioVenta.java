package pe.edu.upeu.sysventas.servicio;

import pe.edu.upeu.sysventas.modelo.Venta;
import pe.edu.upeu.sysventas.modelo.VentaItem;
import pe.edu.upeu.sysventas.util.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio de Ventas que trabaja exclusivamente con la base de datos SQLite
 */
public class ServicioVenta {

    private DatabaseManager db;

    public ServicioVenta() {
        this.db = DatabaseManager.getInstance();
    }

    /**
     * Registra una nueva venta en la base de datos
     */
    public boolean registrar(Venta venta) {
        try {
            String ventaSql = "INSERT INTO ventas (id, username, fecha_hora, total) VALUES (?, ?, ?, ?)";
            db.executeUpdate(ventaSql, venta.getId(), venta.getUsername(), venta.getFechaHora().toString(), venta.getTotal());

            // Registrar los items de la venta
            for (VentaItem item : venta.getItems()) {
                String itemSql = "INSERT INTO venta_items (venta_id, producto_id, nombre_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?, ?)";
                db.executeUpdate(itemSql, venta.getId(), item.getProductId(), item.getProductName(), item.getQty(), item.getUnitPrice());
            }

            return true;
        } catch (SQLException e) {
            System.err.println("Error registrando venta: " + e.getMessage());
            return false;
        }
    }

    /**
     * Obtiene todas las ventas
     */
    public List<Venta> todos() {
        List<Venta> out = new ArrayList<>();
        try {
            String sql = "SELECT id, username, fecha_hora, total FROM ventas ORDER BY fecha_hora DESC";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                
                while (rs.next()) {
                    String ventaId = rs.getString("id");
                    String username = rs.getString("username");
                    LocalDateTime fechaHora = LocalDateTime.parse(rs.getString("fecha_hora"));
                    double total = rs.getDouble("total");

                    // Obtener items de la venta
                    List<VentaItem> items = obtenerItems(ventaId);

                    Venta v = new Venta(ventaId, username, fechaHora, items, total);
                    out.add(v);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo ventas: " + e.getMessage());
        }
        return out;
    }

    /**
     * Obtiene los items de una venta específica
     */
    private List<VentaItem> obtenerItems(String ventaId) {
        List<VentaItem> items = new ArrayList<>();
        try {
            String sql = "SELECT producto_id, nombre_producto, cantidad, precio_unitario FROM venta_items WHERE venta_id = ? ORDER BY id";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, ventaId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        VentaItem item = new VentaItem(
                            rs.getString("producto_id"),
                            rs.getString("nombre_producto"),
                            rs.getInt("cantidad"),
                            rs.getDouble("precio_unitario")
                        );
                        items.add(item);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo items de venta: " + e.getMessage());
        }
        return items;
    }

    /**
     * Obtiene ventas de un usuario específico
     */
    public List<Venta> porUsuario(String username) {
        List<Venta> out = new ArrayList<>();
        try {
            String sql = "SELECT id, username, fecha_hora, total FROM ventas WHERE username = ? ORDER BY fecha_hora DESC";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, username);
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        String ventaId = rs.getString("id");
                        LocalDateTime fechaHora = LocalDateTime.parse(rs.getString("fecha_hora"));
                        double total = rs.getDouble("total");

                        List<VentaItem> items = obtenerItems(ventaId);
                        Venta v = new Venta(ventaId, username, fechaHora, items, total);
                        out.add(v);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo ventas por usuario: " + e.getMessage());
        }
        return out;
    }

    /**
     * Suma las ventas entre dos fechas
     */
    public double sumBetween(LocalDateTime from, LocalDateTime to) {
        try {
            String sql = "SELECT COALESCE(SUM(total), 0) as suma FROM ventas WHERE fecha_hora >= ? AND fecha_hora < ?";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, from.toString());
                pstmt.setString(2, to.toString());
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        return rs.getDouble("suma");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error calculando suma entre fechas: " + e.getMessage());
        }
        return 0.0;
    }

    /**
     * Calcula ganancias de los últimos N días
     */
    public double gananciasUltimosDias(int dias) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime desde = now.minusDays(dias);
        return sumBetween(desde, now.plusSeconds(1));
    }

    /**
     * Calcula ganancias semanales (últimos 7 días)
     */
    public double gananciasSemanales() {
        return gananciasUltimosDias(7);
    }

    /**
     * Calcula ganancias mensuales (últimos 30 días)
     */
    public double gananciasMensuales() {
        return gananciasUltimosDias(30);
    }
}

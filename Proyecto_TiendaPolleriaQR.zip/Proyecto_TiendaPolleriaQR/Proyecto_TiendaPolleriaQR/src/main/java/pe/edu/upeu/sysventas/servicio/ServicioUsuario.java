package pe.edu.upeu.sysventas.servicio;

import pe.edu.upeu.sysventas.modelo.Usuario;
import pe.edu.upeu.sysventas.util.DatabaseManager;
import pe.edu.upeu.sysventas.util.UtilHash;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio de Usuarios que trabaja exclusivamente con la base de datos SQLite
 */
public class ServicioUsuario {

    private DatabaseManager db;

    public ServicioUsuario() {
        this.db = DatabaseManager.getInstance();
    }

    /**
     * Registra un nuevo usuario
     */
    public boolean registrar(String username, String password, boolean admin) {
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) return false;
        
        try {
            // Verificar si ya existe
            String checkSql = "SELECT 1 FROM usuarios WHERE username = ? LIMIT 1";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(checkSql)) {
                pstmt.setString(1, username);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) return false; // Ya existe
                }
            }

            // Registrar el nuevo usuario
            String h = UtilHash.sha256(password);
            String sql = "INSERT INTO usuarios (username, password_hash, is_admin) VALUES (?, ?, ?)";
            db.executeUpdate(sql, username, h, admin ? 1 : 0);
            return true;
        } catch (SQLException e) {
            System.err.println("Error registrando usuario: " + e.getMessage());
            return false;
        }
    }

    /**
     * Autentica un usuario con su contraseña
     */
    public Usuario autenticar(String username, String password) {
        try {
            String h = UtilHash.sha256(password);
            String sql = "SELECT username, password_hash, is_admin FROM usuarios WHERE username = ? AND password_hash = ? LIMIT 1";
            
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, h);
                
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        return new Usuario(rs.getString("username"), rs.getString("password_hash"), rs.getInt("is_admin") == 1);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error autenticando usuario: " + e.getMessage());
        }
        return null;
    }

    /**
     * Asegura que existe el usuario administrador por defecto
     */
    public void asegurarAdminPorDefecto() {
        try {
            String sql = "SELECT 1 FROM usuarios WHERE username = ? LIMIT 1";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, "nehemias");
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (!rs.next()) {
                        // No existe, crear el admin por defecto
                        registrar("nehemias", "123456", true);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error asegurando admin por defecto: " + e.getMessage());
        }
    }

    /**
     * Obtiene todos los usuarios
     */
    public List<Usuario> todos() {
        List<Usuario> out = new ArrayList<>();
        try {
            String sql = "SELECT username, password_hash, is_admin FROM usuarios ORDER BY username";
            try (Connection conn = db.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                
                while (rs.next()) {
                    Usuario u = new Usuario(rs.getString("username"), rs.getString("password_hash"), rs.getInt("is_admin") == 1);
                    out.add(u);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo usuarios: " + e.getMessage());
        }
        return out;
    }
}

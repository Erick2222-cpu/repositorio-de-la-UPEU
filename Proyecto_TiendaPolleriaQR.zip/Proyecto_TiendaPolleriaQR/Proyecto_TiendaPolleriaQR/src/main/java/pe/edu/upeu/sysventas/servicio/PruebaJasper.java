package pe.edu.upeu.sysventas.servicio;

import java.util.HashMap;
import java.util.Map;

public class PruebaJasper {
    public static void main(String[] args) {
        ServicioJasper sj = new ServicioJasper();
        Map<String,Object> params = new HashMap<>();
        params.put("titulo", "Reporte de Prueba - Pollería de QR");
        String out = sj.generarReportePDF("reporte_venta.jrxml", params);
        if (out != null) System.out.println("Salida: " + out);
        else System.err.println("Fallo en generación de reporte.");
    }
}

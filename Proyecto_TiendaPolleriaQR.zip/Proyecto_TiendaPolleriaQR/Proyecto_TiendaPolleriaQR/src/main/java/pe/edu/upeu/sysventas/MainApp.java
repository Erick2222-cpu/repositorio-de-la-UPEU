package pe.edu.upeu.sysventas;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import pe.edu.upeu.sysventas.servicio.ServicioUsuario;
import pe.edu.upeu.sysventas.modelo.Usuario;

public class MainApp extends Application {

    private ServicioUsuario servicioUsuario = new ServicioUsuario();
    private pe.edu.upeu.sysventas.servicio.ServicioReporte servicioReporte;

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Migración automática de datos a SQLite
        try {
            pe.edu.upeu.sysventas.util.DataMigration migrator = new pe.edu.upeu.sysventas.util.DataMigration();
            migrator.migrateIfNeeded();
        } catch (Exception ex) {
            System.err.println("Error en migración automática: " + ex.getMessage());
        }
        servicioUsuario.asegurarAdminPorDefecto();

        // Cargar y mostrar logo UPEU
        ImageView logoView = null;
        try {
            var logoUrl = getClass().getResource("/imagenes/logoupeu.png");
            if (logoUrl != null) {
                Image logo = new Image(logoUrl.toExternalForm());
                logoView = new ImageView(logo);
                logoView.setFitHeight(100);
                logoView.setFitWidth(100);
                logoView.setPreserveRatio(true);
            }
        } catch (Exception e) {
            System.out.println("Advertencia: No se pudo cargar el logo UPEU: " + e.getMessage());
        }

        Label titulo = new Label("Pollería de QR - Bienvenido");
        titulo.setStyle("-fx-font-size:18px; -fx-text-fill:white; -fx-font-weight:bold;");

        TextField txtUsuario = new TextField();
        txtUsuario.setPromptText("Usuario");

        PasswordField txtContrasena = new PasswordField();
        txtContrasena.setPromptText("Contraseña");

        Button btnEntrar = new Button("Iniciar sesión");
        Button btnRegistrar = new Button("Registrar");

        HBox hbBtns = new HBox(10, btnEntrar, btnRegistrar);
        hbBtns.setAlignment(Pos.CENTER);

        // Contenedor del formulario
        VBox formulario = new VBox(12, titulo, txtUsuario, txtContrasena, hbBtns);
        formulario.setAlignment(Pos.CENTER);
        formulario.setPadding(new Insets(20));
        formulario.setStyle("-fx-background-color: linear-gradient(to bottom, #0b0b0b, #2a0033); -fx-border-radius:12; -fx-background-radius:12;");

        // Contenedor principal con logo y formulario
        VBox mainVBox = new VBox(15);
        mainVBox.setAlignment(Pos.CENTER);
        mainVBox.setPadding(new Insets(20));
        if (logoView != null) {
            HBox logoBox = new HBox(logoView);
            logoBox.setAlignment(Pos.CENTER);
            mainVBox.getChildren().add(logoBox);
        }
        mainVBox.getChildren().add(formulario);

        StackPane root = new StackPane(mainVBox);
        root.setPadding(new Insets(40));
        
        // Cargar stylesheet con fallback
        try {
            var estiloUrl = getClass().getResource("/estilo.css");
            if (estiloUrl != null) {
                root.getStylesheets().add(estiloUrl.toExternalForm());
            } else {
                System.out.println("Advertencia: No se encontró /estilo.css en el classpath");
            }
        } catch (Exception e) {
            System.out.println("Error cargando stylesheet: " + e.getMessage());
        }
        
        Scene scene = new Scene(root, 560, 580);

        primaryStage.setTitle("Pollería de QR - Sistema de Ventas");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Iniciar servicio de reportes semanales
        servicioReporte = new pe.edu.upeu.sysventas.servicio.ServicioReporte();
        servicioReporte.start();

        // Asegurar que se detenga al cerrar la aplicación
        primaryStage.setOnCloseRequest(ev -> {
            if (servicioReporte != null) servicioReporte.stop();
        });

        btnEntrar.setOnAction(ev -> {
            String u = txtUsuario.getText().trim();
            String p = txtContrasena.getText();
            Usuario user = servicioUsuario.autenticar(u, p);
            if (user != null) {
                VentanaDashboard.mostrar(primaryStage, user);
            } else {
                Alert a = new Alert(Alert.AlertType.ERROR, "Usuario o contraseña incorrectos", ButtonType.OK);
                a.showAndWait();
            }
        });

        btnRegistrar.setOnAction(ev -> {
            VentanaRegistro.mostrar(primaryStage, servicioUsuario);
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}

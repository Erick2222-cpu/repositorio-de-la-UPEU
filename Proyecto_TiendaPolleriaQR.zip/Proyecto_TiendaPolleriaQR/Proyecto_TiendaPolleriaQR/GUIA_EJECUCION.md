# 🚀 Guía de Ejecución - Pollería de QR

## ✨ 4 Formas Diferentes de Ejecutar

### **1️⃣ La Más Fácil - Script Windows (CMD)**

```batch
cd Proyecto_TiendaCalzado
ejecutar.bat
```

✅ Automático - Verifica Java, compila si es necesario, ejecuta  
✅ Ideal para usuarios no técnicos

---

### **2️⃣ Con PowerShell**

```powershell
cd Proyecto_TiendaCalzado
.\ejecutar.ps1
```

✅ Más colorido y verbose  
✅ Mensajes de error detallados  
✅ Muestra el progreso de compilación

---

### **3️⃣ Desde VS Code (Recomendado para Desarrollo)**

**Opción A - Con Task:**
1. Presiona `Ctrl + Shift + B`
2. Selecciona "Ejecutar Pollería de QR"

**Opción B - Con Debugger:**
1. Presiona `Ctrl + Shift + D`
2. Haz clic en el botón ▶️ play
3. Selecciona "Ejecutar Pollería de QR"

✅ Integrado en el IDE  
✅ Puede depurar con breakpoints  
✅ Muestra errores en tiempo real

---

### **4️⃣ Desde Terminal (La más simple)**

```bash
cd Proyecto_TiendaCalzado
java -jar target/Polleria-QR.jar
```

✅ Directo y rápido  
✅ Funciona en cualquier terminal  
✅ Requiere que ya esté compilado

---

## 🔧 Compilación (si es necesario)

```bash
cd Proyecto_TiendaCalzado
mvn clean package -DskipTests
```

---

## 📝 Estructura de Archivos de Ejecución

```
Proyecto_TiendaCalzado/
├── ejecutar.bat          ← Script para Windows CMD
├── ejecutar.ps1          ← Script para PowerShell
├── EJECUTAR_APLICACION.md ← Documentación completa
├── .vscode/
│   ├── tasks.json        ← Tareas de VS Code
│   └── launch.json       ← Configuración de debug
└── target/
    └── Polleria-QR.jar   ← JAR ejecutable compilado
```

---

## 🔑 Credenciales de Acceso

| Campo | Valor |
|-------|-------|
| Usuario | `nehemias` |
| Contraseña | `123456` |

---

## ✅ Requisitos Mínimos

- **Java 21+** (descarga desde https://www.oracle.com/java/technologies/downloads/)
- Maven 3.6+ (opcional, solo si quieres compilar)

---

## 🎯 Resolución de Problemas

| Problema | Solución |
|----------|----------|
| "Java no encontrado" | Instala Java 21 y agrégalo al PATH |
| JAR no existe | Compila con `mvn clean package -DskipTests` |
| Error de puertos | La app usa puertos internos de JavaFX, no debería haber conflictos |
| IDE no encuentra MainApp | Reconstruye el proyecto: `Ctrl + Shift + P` → Maven → Reload |

---

## 📊 Características de la Aplicación

- ✅ Sistema de Login y Registro
- ✅ Panel de Administración (gestión de productos)
- ✅ Categorías dinámicas (Comida/Bebida)
- ✅ Carrito de compras
- ✅ Reportes semanales automáticos
- ✅ Cálculo de ganancias (7 y 30 días)
- ✅ Base de datos en CSV
- ✅ Interfaz JavaFX profesional

---

**Última actualización:** 23 de noviembre de 2025  
**Versión:** 1.0-SNAPSHOT

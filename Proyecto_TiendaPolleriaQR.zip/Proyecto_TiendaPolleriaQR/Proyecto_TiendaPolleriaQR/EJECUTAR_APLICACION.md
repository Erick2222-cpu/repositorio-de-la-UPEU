# 🍗 Pollería de QR - Guía de Ejecución

## Requisitos Previos

- **Java 21 o superior** instalado en tu sistema
- Maven 3.6+ (solo si necesitas compilar desde cero)

## Opción 1: Ejecutar desde Windows (CMD)

1. Abre una terminal o Command Prompt en la carpeta del proyecto
2. Ejecuta:
   ```bash
   ejecutar.bat
   ```

## Opción 2: Ejecutar desde PowerShell

1. Abre PowerShell en la carpeta del proyecto
2. Asegúrate de permitir la ejecución de scripts (si es necesario):
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```
3. Ejecuta:
   ```powershell
   .\ejecutar.ps1
   ```

## Opción 3: Ejecutar directamente con Java

Si ya compilaste el proyecto, puedes ejecutar directamente:

```bash
java -jar target/Polleria-QR.jar
```

### Ejecutar `MainApp` directamente (requiere JavaFX SDK en module-path)

Si quieres ejecutar la clase `MainApp` directamente (por ejemplo desde el IDE o con
`mvn exec:java`), debes indicar la ubicación de las librerías JavaFX en el
`--module-path` y añadir los módulos que uses. Descarga el JavaFX SDK (por ejemplo
`javafx-sdk-21`) y apunta la variable `JAVAFX_LIB` a la carpeta `lib` del SDK.

Windows (PowerShell):

```powershell
# Ajusta la ruta según la ubicación de tu JavaFX SDK
$env:JAVAFX_LIB = 'C:\ruta\a\javafx-sdk-21\lib'

# Ejecutar desde terminal
java --module-path "$env:JAVAFX_LIB" --add-modules javafx.controls,javafx.fxml -cp target/classes;"<otras-libs>" pe.edu.upeu.sysventas.MainApp
```

Windows (CMD):

```cmd
:: Ajusta la ruta según la ubicación de tu JavaFX SDK
set JAVAFX_LIB=C:\ruta\a\javafx-sdk-21\lib

java --module-path "%JAVAFX_LIB%" --add-modules javafx.controls,javafx.fxml -cp target\classes;target\dependency\* pe.edu.upeu.sysventas.MainApp
```

Usar `mvn javafx:run` también configura correctamente el module-path al usar el
plugin JavaFX de Maven:

```bash
mvn javafx:run -Djavafx.platform=win
```

## Opción 4: Desde el IDE (IntelliJ IDEA / Eclipse)

### IntelliJ IDEA:
1. Haz clic derecho en `MainApp.java`
2. Selecciona **"Run 'MainApp.main()'"**

### Eclipse:
1. Haz clic derecho en `MainApp.java`
2. Selecciona **"Run As" > "Java Application"**

## Compilar desde Cero

Si necesitas compilar el proyecto nuevamente:

```bash
mvn clean package -DskipTests
```

## Credenciales de Acceso

Usa estas credenciales para entrar a la aplicación:

- **Usuario:** `nehemias`
- **Contraseña:** `123456`

## Características de la Aplicación

- ✅ Sistema de login y registro
- ✅ Panel de administración para gestionar productos
- ✅ Categorías dinámicas (Comida/Bebida)
- ✅ Carrito de compras para clientes
- ✅ Reportes semanales automáticos
- ✅ Cálculo de ganancias (7 y 30 días)
- ✅ Interfaz profesional y responsiva

## Solución de Problemas

### Error: "Java no encontrado"
- Instala Java 21 desde https://www.oracle.com/java/technologies/downloads/
- Agrega Java al PATH de tu sistema

### Error al ejecutar desde IDE
- Verifica que el JDK sea 21 o superior en la configuración del proyecto
- Intenta limpiar y reconstruir: `mvn clean compile`

### Puertos en uso
La aplicación usa puertos internos de JavaFX, no debería haber conflictos.

## Desarrollo

Para modificar la aplicación:

```bash
# Compilar sin ejecutar pruebas
mvn clean compile

# Compilar y empaquetar
mvn clean package -DskipTests

# Ejecutar pruebas
mvn test
```

---

**Versión:** 1.0-SNAPSHOT  
**Última actualización:** 23 de noviembre de 2025

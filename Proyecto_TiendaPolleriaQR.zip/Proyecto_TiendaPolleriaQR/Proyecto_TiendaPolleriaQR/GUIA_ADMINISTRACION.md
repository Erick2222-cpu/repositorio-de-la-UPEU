# Guía de Administración - Pollería de QR

## Panel de Administración

El sistema ha sido rediseñado completamente para gestionar una pollería. Todos los campos relacionados a calzado han sido eliminados.

### Estructura de Productos

Los productos ahora se dividen en dos categorías:

#### 1. Comida (Pollo y derivados)
- **Nombre**: Ingresa manualmente (ej: "Pollo a la brasa", "Alitas picantes", "Porciones de pechuga")
- **Categoría**: Comida (seleccionable)
- **Descripción**: Detalles opcionales (ej: "sin especificar", "completo", "picante", "con salsa")
- **Precio**: Valor en soles
- **Stock**: Cantidad disponible
- **Presentación**: Campo opcional (para comida generalmente no se muestra, pero se puede dejar en blanco)

Ejemplos iniciales:
- Pollo a la brasa (25.0 soles)
- Broaster (28.0 soles)
- Alitas (18.0 soles)
- Combo familiar (90.0 soles)

#### 2. Bebida
- **Nombre**: Ingresa manualmente (ej: "Gaseosa 1.5L", "Refresco", "Chicha Morada")
- **Categoría**: Bebida (seleccionable)
- **Descripción**: Tipo/sabor (ej: "cola", "naranja", "morada")
- **Precio**: Valor en soles
- **Stock**: Cantidad disponible
- **Presentación**: OBLIGATORIO - Ingresa tamaño o presentación (ej: "500ml", "1L", "1.5L", "vaso grande")

### Cómo Agregar un Producto

1. Ve al panel de **Administración** (tab en el dashboard)
2. Completa el formulario:
   - **Nombre del producto**: Escribe el nombre (ej: "Ensalada de verduras")
   - **Categoría**: Selecciona "Comida" o "Bebida"
   - Si seleccionas **Bebida**, aparecerá el campo "Presentación" - complétalo
   - **Descripción**: Detalle opcional
   - **Precio**: Número decimal (ej: 25.50)
   - **Stock**: Número entero

3. Haz clic en "Agregar/Guardar producto"

### Cómo Editar un Producto

1. En la tabla de productos, haz clic en la fila del producto que quieres editar
2. Los campos se rellenarán automáticamente
3. Realiza los cambios que necesites
4. Haz clic en "Agregar/Guardar producto"

### Cómo Eliminar un Producto

1. En la tabla, selecciona el producto
2. Haz clic en "Eliminar seleccionado"

### Alertas de Stock Bajo

- Las filas con **stock ≤ 5 unidades** se resaltan en **rojo**
- Esto te ayuda a identificar qué productos necesitan reabastecimiento

### Estructura del CSV

El archivo `datos/productos.csv` tiene el siguiente formato:

```
id;nombre;categoria;descripcion;precio;presentacion;stock;imagen
PRD1761642156284;Pollo a la brasa;Comida;sin especificar;25.0;porción;50;
PRD1761644833002;Gaseosa 1.5L;Bebida;cola;7.0;1.5L;60;
```

**Campos:**
- `id`: Identificador único (autogenerado)
- `nombre`: Nombre del producto
- `categoria`: "Comida" o "Bebida"
- `descripcion`: Detalles opcionales
- `precio`: Valor en soles
- `presentacion`: Tamaño/porción (importante para bebidas)
- `stock`: Cantidad disponible
- `imagen`: Campo reservado (vacío por ahora)

### Reportes Semanales

El sistema genera automáticamente reportes en la carpeta `reports/` cada semana con:
- Ganancias de los últimos 7 días
- Ganancias de los últimos 30 días

Los reportes se visualizan en el dashboard principal en tiempo real.

### Cambios desde la versión anterior

✅ **Eliminado:**
- Campos "Talla" y "Color" (específicos de calzado)
- Categorías de calzado

✅ **Agregado:**
- Categorías: Comida y Bebida
- Campo "Descripción" para detalles de preparación
- Campo "Presentación" para tamaños de bebidas
- Branding "Pollería de QR" en toda la interfaz
- Módulo de reportes semanales automáticos

✅ **Actualizado:**
- UI del panel admin adaptada a pollería
- Visor de productos en tienda
- Sistema de búsqueda y filtrado

---

**Nota**: Los datos se persisten automáticamente en archivos CSV dentro de la carpeta `datos/`.

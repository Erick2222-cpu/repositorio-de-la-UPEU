# Guía de Integración: Dashboard 5 Paneles en MainApp

## 📌 Objetivo
Integrar el nuevo `DashboardPrincipal` en el flujo de login existente de `MainApp.java` para que después de autenticarse, el usuario acceda directamente al dashboard con los 5 paneles administrativos.

---

## 🔄 Flujo Actual vs Flujo Nuevo

### Flujo Actual (Antes)
```
MainApp (Login)
    ↓
[Usuario ingresa credenciales]
    ↓
PanelAdmin (gestión de productos)
O
PanelCliente (ventas)
```

### Flujo Nuevo (Después)
```
MainApp (Login)
    ↓
[Usuario ingresa credenciales]
    ↓
DashboardPrincipal (5 tabs integrados)
    ├─ Tab 1: Productos y Categorías
    ├─ Tab 2: Ventas Diarias
    ├─ Tab 3: Estadísticas
    ├─ Tab 4: Financiero
    └─ Tab 5: Reportes e Historial
        ↓
    [Botón Salir → Vuelve a MainApp/Login]
```

---

## 🛠️ Modificaciones Necesarias

### 1. En `MainApp.java`

#### A. Agregar método para crear el Dashboard

Busca el método donde se muestra el `PanelAdmin` o `PanelCliente` después de login exitoso. Usualmente se ve así:

```java
// UBICACIÓN: Después de autenticación exitosa en ControladorLogin
private void mostrarPanelAdmin() {
    PanelAdmin panelAdmin = new PanelAdmin();
    // ... código para mostrar panel
}
```

**Agregar este nuevo método:**

```java
private void mostrarDashboardPrincipal() {
    try {
        // Crear instancias de servicios
        ServicioVenta servicioVenta = new ServicioVenta();
        ServicioProducto servicioProducto = new ServicioProducto();
        ServicioCategoria servicioCategoria = new ServicioCategoria();

        // Crear el Dashboard Principal
        BorderPane dashboard = DashboardPrincipal.crear(
            servicioVenta, 
            servicioProducto, 
            servicioCategoria
        );

        // Mostrar en la escena principal
        Scene scene = new Scene(dashboard, 1400, 900);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Pollería de QR - Sistema de Administración");
        primaryStage.show();

    } catch (Exception e) {
        e.printStackTrace();
        showAlert("Error", "No se pudo cargar el dashboard: " + e.getMessage());
    }
}
```

#### B. Modificar el método de login exitoso

En el `ControladorLogin`, después de validar las credenciales:

```java
// ANTES
if (loginExitoso) {
    mainApp.mostrarPanelAdmin();  // o mostrarPanelCliente()
}

// DESPUÉS
if (loginExitoso) {
    mainApp.mostrarDashboardPrincipal();  // ← Cambiar a esto
}
```

#### C. Agregar imports necesarios

En la sección de imports de `MainApp.java`, agregar:

```java
import pe.edu.upeu.sysventas.DashboardPrincipal;
import pe.edu.upeu.sysventas.servicio.ServicioVenta;
import pe.edu.upeu.sysventas.servicio.ServicioProducto;
import pe.edu.upeu.sysventas.servicio.ServicioCategoria;
```

---

## 📝 Código de Ejemplo Completo

### Modificación en `ControladorLogin.java`

```java
package pe.edu.upeu.sysventas.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import pe.edu.upeu.sysventas.MainApp;
import pe.edu.upeu.sysventas.servicio.ServicioUsuario;

public class ControladorLogin {

    @FXML
    private TextField tfUsuario;

    @FXML
    private PasswordField pfContrasena;

    private MainApp mainApp;

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void handleLogin() {
        String usuario = tfUsuario.getText();
        String contrasena = pfContrasena.getText();

        if (usuario.isEmpty() || contrasena.isEmpty()) {
            showAlert("Error", "Por favor ingresa usuario y contraseña.");
            return;
        }

        ServicioUsuario servicioUsuario = new ServicioUsuario();
        
        // Validar credenciales
        if (servicioUsuario.validar(usuario, contrasena)) {
            showAlert("Éxito", "Login exitoso. Bienvenido, " + usuario + "!");
            
            // ✨ AQUÍ: Cambiar del PanelAdmin al DashboardPrincipal
            mainApp.mostrarDashboardPrincipal();  // ← ESTA LÍNEA CRUCIAL
            
            // Limpiar campos
            tfUsuario.clear();
            pfContrasena.clear();
        } else {
            showAlert("Error", "Usuario o contraseña incorrectos.");
        }
    }

    @FXML
    private void handleSalir() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmar Salida");
        alert.setHeaderText(null);
        alert.setContentText("¿Deseas salir de la aplicación?");
        
        if (alert.showAndWait().filter(r -> r == ButtonType.OK).isPresent()) {
            System.exit(0);
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
```

### Modificación en `MainApp.java`

```java
package pe.edu.upeu.sysventas;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Alert;
import pe.edu.upeu.sysventas.controlador.ControladorLogin;
import pe.edu.upeu.sysventas.servicio.ServicioVenta;
import pe.edu.upeu.sysventas.servicio.ServicioProducto;
import pe.edu.upeu.sysventas.servicio.ServicioCategoria;

public class MainApp extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        
        primaryStage.setTitle("Pollería de QR - Login");
        primaryStage.setWidth(900);
        primaryStage.setHeight(600);
        
        mostrarLogin();
        primaryStage.show();
    }

    private void mostrarLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/pe/edu/upeu/sysventas/vistas/VistaLogin.fxml")
            );
            Parent root = loader.load();
            ControladorLogin controller = loader.getController();
            controller.setMainApp(this);

            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Pollería de QR - Login");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "No se pudo cargar la pantalla de login: " + e.getMessage());
        }
    }

    // ✨ NUEVO MÉTODO: Mostrar Dashboard Principal
    public void mostrarDashboardPrincipal() {
        try {
            // Crear instancias de servicios
            ServicioVenta servicioVenta = new ServicioVenta();
            ServicioProducto servicioProducto = new ServicioProducto();
            ServicioCategoria servicioCategoria = new ServicioCategoria();

            // Crear el Dashboard Principal
            BorderPane dashboard = DashboardPrincipal.crear(
                servicioVenta, 
                servicioProducto, 
                servicioCategoria
            );

            // Mostrar en la escena principal
            Scene scene = new Scene(dashboard, 1400, 900);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Pollería de QR - Sistema de Administración");
            primaryStage.setWidth(1400);
            primaryStage.setHeight(900);

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "No se pudo cargar el dashboard: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
```

---

## ✅ Pasos de Integración

### Paso 1: Hacer Backup
```bash
cp MainApp.java MainApp.java.backup
cp ControladorLogin.java ControladorLogin.java.backup
```

### Paso 2: Agregar Método en MainApp
- Copiar el método `mostrarDashboardPrincipal()` al archivo `MainApp.java`

### Paso 3: Agregar Imports
- Agregar los 4 imports necesarios en `MainApp.java`:
  - `DashboardPrincipal`
  - `ServicioVenta`
  - `ServicioProducto`
  - `ServicioCategoria`

### Paso 4: Modificar Login
- En `ControladorLogin.handleLogin()`, cambiar:
  - Reemplazar `mainApp.mostrarPanelAdmin()` con `mainApp.mostrarDashboardPrincipal()`

### Paso 5: Compilar y Prueba
```bash
mvn clean compile
mvn exec:java -Dexec.mainClass="pe.edu.upeu.sysventas.MainApp"
```

### Paso 6: Validar
- ✅ Login se muestra correctamente
- ✅ Ingresar credenciales válidas
- ✅ Dashboard aparece con 5 tabs
- ✅ Cada tab muestra su contenido
- ✅ Botón Salir cierra la aplicación

---

## 🎯 Alternativas de Integración

### Opción A: Reemplazar PanelAdmin (Recomendado)
El Dashboard reemplaza completamente al PanelAdmin, proporcionando todas sus funciones + más.

### Opción B: Menú de Selección
Agregar un menú después del login para elegir entre Dashboard o Vendedor:
```
┌────────────────────────┐
│   ¿Qué deseas hacer?   │
│                        │
│  [Dashboard Admin]     │  → DashboardPrincipal
│  [Vender Ahora]        │  → PanelCliente
│                        │
└────────────────────────┘
```

### Opción C: Roles de Usuario
- Admin → DashboardPrincipal (5 paneles)
- Vendedor → PanelCliente (solo ventas)
- Gerente → Panel Financiero + Reportes

---

## 🔍 Verificación Post-Integración

Checklist de validación:

- [ ] Proyecto compila sin errores
- [ ] Login funciona normalmente
- [ ] Dashboard abre después de login
- [ ] Tab 1 (Productos) carga y se puede agregar productos
- [ ] Tab 2 (Ventas) muestra KPIs y tabla de ventas
- [ ] Tab 3 (Estadísticas) muestra gráficos y comparativas
- [ ] Tab 4 (Financiero) muestra balance y márgenes
- [ ] Tab 5 (Reportes) permite generar reportes
- [ ] Botón Salir cierra la aplicación
- [ ] Todos los campos de entrada funcionan correctamente
- [ ] No hay errores en consola
- [ ] Los datos se cargan desde CSV correctamente

---

## 📞 Soporte

Si hay errores durante la integración:

1. **Error de Importación**: Verificar que todas las clases estén en el package correcto
2. **NullPointerException**: Asegurar que los servicios se instancian correctamente
3. **Scene no se muestra**: Verificar que `primaryStage.show()` se llame en `mostrarLogin()`
4. **Datos no cargan**: Verificar que los CSV existan en la carpeta `datos/`

---

## 📊 Resultado Esperado

```
Login Page (VistaLogin.fxml)
    ↓ [Usuario: admin, Pass: 123]
    ↓
Dashboard Principal (BorderPane)
┌──────────────────────────────────────┐
│ 🍗 POLLERÍA DE QR 🍗                  │
│ Admin | Salir                         │
├──────────────────────────────────────┤
│ 📦 │ 💰 │ 📊 │ 💵 │ 📄              │
├──────────────────────────────────────┤
│ [Contenido del Tab Seleccionado]     │
│ Con datos en tiempo real              │
└──────────────────────────────────────┘
```

---

**Versión**: 1.0.0  
**Última Actualización**: 24 de Noviembre de 2025  
**Estado**: ✅ Listo para implementar

# Script para ejecutar la aplicación Pollería de QR desde PowerShell con JavaFX
# Requiere: Java 21+ y Maven (opcional, solo si se necesita compilar)

$scriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
Set-Location -Path $scriptDir

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Pollería de QR - Sistema de Ventas" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Verificar si Java está instalado
try {
    java -version 2>&1 | Out-Null
} catch {
    Write-Host "Error: Java no está instalado o no está en el PATH" -ForegroundColor Red
    Write-Host "Por favor, instala Java 21 o superior" -ForegroundColor Yellow
    Read-Host "Presiona Enter para continuar"
    exit 1
}

# Detectar ruta de JavaFX SDK
$javafxPaths = @(
    "C:\javafx-sdk-25\lib",
    "C:\javafx-sdk-21\lib",
    "C:\javafx-sdk\lib"
)

$JAVAFX_LIB = $null
foreach ($path in $javafxPaths) {
    if (Test-Path $path) {
        $JAVAFX_LIB = $path
        break
    }
}

if (-not $JAVAFX_LIB) {
    Write-Host "Error: No se encontró JavaFX SDK." -ForegroundColor Red
    Write-Host "Instala JavaFX SDK en C:\javafx-sdk-25\ o en C:\javafx-sdk\" -ForegroundColor Yellow
    Read-Host "Presiona Enter para continuar"
    exit 1
}

Write-Host "Usando JavaFX en: $JAVAFX_LIB" -ForegroundColor Green
Write-Host ""

# Verificar si el JAR existe, sino compilar
if (-not (Test-Path "target\Proyecto_TiendaCalzado-1.0-SNAPSHOT.jar")) {
    Write-Host "Compilando proyecto..." -ForegroundColor Yellow
    Write-Host ""
    mvn clean package -DskipTests
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Error al compilar. Verifica el pom.xml" -ForegroundColor Red
        Read-Host "Presiona Enter para continuar"
        exit 1
    }
}

Write-Host "Iniciando aplicación..." -ForegroundColor Green
Write-Host ""

# Ejecutar JAR con módulos de JavaFX
java --module-path "$JAVAFX_LIB" --add-modules javafx.controls,javafx.fxml,javafx.graphics -jar target\Proyecto_TiendaCalzado-1.0-SNAPSHOT.jar

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "Error al ejecutar la aplicación." -ForegroundColor Red
    Read-Host "Presiona Enter para continuar"
}
